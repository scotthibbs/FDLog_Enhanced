Program README: 

	This program is 42 years old in 2026!! And it keeps on going..

	Alan K Biocca W6AKB (Formerly WB6ZQZ) Wrote this in 1984 using small c 
	and it was titled "WB6ZQZ's Field Day Logging Program". In 2002, Mr Biocca 
	rewrote the program in Python and renamed it FDLog. That year, FDLog was 
	released as open source with the GNU License. The original FDLog is still in 
	use by the High Sierra Field Day Group and maintained by Mr Biocca at www.fdlog.info. 

	My name is Scott Hibbs KD4SIR. I found FDLog on the Internet and started using it
	for Field Day 2012. In love with it, I immediately started learning Python. After
	using FDLog for Field Day 2013, the South Central Indiana Communications Support
	Group (SCICSG - we pronounce it scuzzy) wanted to know their individual scores and 
	wanted a quick way to see "who" was on which bands. When our upgrades were not 
	acted on by Mr Biocca, I decided to modify the program for ourselves for 2014. 
	I have enhanced the original program with a lot of enhancements and occasionally I 
	have and will pick up some of Mr Biocca's new ideas too.  

	We hope you fall in love with the program (like we have) and can help us improve it. 
	Send suggestions, help, pull request, ideas to Scott Hibbs at gmail.com
	
	Please look in the Releaselog.txt file to see a list of our Enhancements!
