#!/usr/bin/python3
# Added by Art Miller KC7SDA May/5/2017
# tkinter errors in linux are fixed by running "sudo apt-get install python3-tk" - Scott Hibbs KD4SIR 01Dec2023

import tkinter
import os
import time
import sys
import re
import _thread
import threading
import socket
import hashlib
import random
import sqlite3
import argparse
import subprocess
import platform
import struct
import pandas as pd
import plotly.express as px
from tkinter import END, Toplevel, Frame, Label, Entry, Button, \
    W, EW, E, NSEW, NS, StringVar, Radiobutton, Tk, Menu, Menubutton, Text, Scrollbar, \
    Checkbutton, IntVar, Listbox, SUNKEN

# Callsign parser with country lookup support
from parser import CallSignParser, InvalidCallSignError, CallSignParserError

# CW Keying support - graceful fallback if pyserial not installed
try:
    from cw_keying import (
        PYSERIAL_AVAILABLE, CWConfig, CWController, CWMacroManager,
        CWSettingsDialog, CWMacroEditorDialog, list_serial_ports, MORSE_CODE
    )
    CW_AVAILABLE = PYSERIAL_AVAILABLE
except ImportError:
    CW_AVAILABLE = False
    CWConfig = None
    CWController = None

# Voice Keying support - graceful fallback if pyttsx3 not installed
try:
    from voice_keying import (
        PYTTSX3_AVAILABLE, VoiceConfig, VoiceKeyer, VoiceMacroManager,
        VoiceSettingsDialog, VoiceMacroEditorDialog
    )
    VOICE_AVAILABLE = PYTTSX3_AVAILABLE
except ImportError:
    VOICE_AVAILABLE = False
    VoiceConfig = None
    VoiceKeyer = None

# WSJT-X Integration support
try:
    from wsjtx_integration import (
        WSJTXConfig, WSJTXListener, WSJTXSettingsDialog
    )
    WSJTX_AVAILABLE = True
except ImportError:
    WSJTX_AVAILABLE = False

# JS8Call Integration support
try:
    from wsjtx_integration import (
        JS8CallConfig, JS8CallListener, JS8CallSettingsDialog
    )
    JS8CALL_AVAILABLE = True
except ImportError:
    JS8CALL_AVAILABLE = False

# fldigi Integration support
try:
    from fldigi_integration import (
        FldigiConfig, FldigiPoller, FldigiSettingsDialog, BAND_FREQ_MAP
    )
    FLDIGI_AVAILABLE = True
except ImportError:
    FLDIGI_AVAILABLE = False

# N3FJP Integration support
try:
    from n3fjp_integration import (
        N3FJPConfig, N3FJPClient, N3FJPServer, N3FJPSettingsDialog,
        BAND_FREQ_MAP as N3FJP_BAND_FREQ_MAP
    )
    N3FJP_AVAILABLE = True
except ImportError:
    N3FJP_AVAILABLE = False

# rigctld (Hamlib) Integration support
try:
    from rigctld_integration import (
        RigctldConfig, RigctldClient, RigctldSettingsDialog,
        BAND_FREQ_MAP as RIGCTLD_BAND_FREQ_MAP
    )
    RIGCTLD_AVAILABLE = True
except ImportError:
    RIGCTLD_AVAILABLE = False

#  Thanks to David (github.com/B1QUAD) 2022 for help with the python 3 version.

#  Main program starts about line 5759

prog = 'FDLog_Enhanced v2026_Beta 4.2.0 29Jan2026\n\n' \
       'Forked with thanks from FDLog by Alan Biocca (W6AKB) Copyright 1984-2017 \n' \
       'FDLog_Enhanced by Scott A Hibbs (KD4SIR) Copyright 2013-2026. \n' \
       'FDLog_Enhanced is under the GNU Public License v2 without warranty. \n'

about = """

FDLog_Enhanced can be found on https://github.com/scotthibbs/FDLog_Enhanced

Forked with thanks from FDLog by Alan Biocca (W6AKB) Copyright 1984-2017
    Previous code contributors were: 
    Eric WD6CMU, Steve KA6S, Glenn WB6W, Frank WB6MRQ and others

FDLog_Enhanced by Scott A Hibbs (KD4SIR) Copyright 2013-2026.
    Copyright also shared with Code Contributors:
    Art Miller KC7SDA 2019              Curtis E. Mills WE7U 2019
    David (github.com/B1QUAD) 2022      ChatGPT v3.5 2023
    Claude Code 2026
    
"""


def fingerprint():
    """Calculate and print MD5 fingerprint of source file."""
    try:
        with open('FDLog_Enhanced.py') as f:
            t = f.read()
        h = hashlib.md5()
        t = t.encode()
        h.update(t)
        print(" FDLog_Enhanced Fingerprint", h.hexdigest())
    except FileNotFoundError:
        # Running as bundled executable - source file not available
        print(" FDLog_Enhanced (standalone build)")


def ival(s):
    """return value of leading int"""
    r = 0
    if s != "":
        mm = re.match(r' *(-?\d*)', s)
        if mm and mm.group(1):
            r = int(mm.group(1))
    return r


def open_file(filepath):
    """Open a file with the system's default application (cross-platform).

    Works on Windows, macOS, and Linux including Raspberry Pi.
    """
    # Get absolute path relative to the script's directory
    if not os.path.isabs(filepath):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(script_dir, filepath)

    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        return False

    try:
        system = platform.system()
        if system == 'Windows':
            os.startfile(filepath)
        elif system == 'Darwin':  # macOS
            subprocess.run(['open', filepath], check=True)
        else:  # Linux, Raspberry Pi, etc.
            subprocess.run(['xdg-open', filepath], check=True)
        return True
    except Exception as e:
        print(f"Error opening file {filepath}: {e}")
        return False


class ClockClass:
    """Keeping time with update, calib, and adjust functions

    Time source priority:
      Level 0: Designated time master (GPS-locked) or NTP-synced node
      Level 1-8: Hierarchical stratum from broadcast calibration
      Level 9: Unsynchronized

    NTP is queried opportunistically. If available, this node auto-promotes
    to level 0. If NTP and designated master are both absent, the lowest
    node name among active peers auto-elects as master (fallback).
    """
    level = 9  # my time quality level
    offset = 0  # my time offset from system clock, add to system time, sec
    adjusta = 0  # amount to adjust clock now (delta)
    errors = 0  # current error sum wrt best source, in total seconds
    errorn = 0  # number of time values in errors sum
    srclev = 10  # current best time source level
    src_node = ''  # node we're syncing time from
    lock = threading.RLock()  # sharing lock
    ntp_offset = None  # last successful NTP offset (seconds) or None
    ntp_ok = False  # True if NTP has been reached recently
    ntp_last_try = 0  # monotonic time of last NTP attempt
    ntp_servers = ['pool.ntp.org', 'time.nist.gov', 'time.google.com']
    _no_master_cycles = 0  # consecutive update cycles with no master seen
    _source_type = 'none'  # 'designated', 'ntp', 'elected', 'synced', 'none'
    _election_pending = False  # True while election is in progress
    _election_start_time = 0  # When election started (monotonic)
    gps_locked = False  # True if local GPS hardware provides time

    def __init__(self):
        pass

    def _ntp_query(self):
        """Query NTP server and return offset in seconds, or None on failure.
        Uses raw UDP - no external dependencies."""
        for server in self.ntp_servers:
            try:
                NTP_EPOCH = 2208988800  # seconds between 1900-01-01 and 1970-01-01
                client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                client.settimeout(2)
                # NTP v3 client packet
                data = b'\x1b' + 47 * b'\0'
                t1 = time.time()
                client.sendto(data, (server, 123))
                data, _ = client.recvfrom(1024)
                t4 = time.time()
                client.close()
                if len(data) < 48:
                    continue
                # Transmit timestamp from server (bytes 40-47)
                t3_int = struct.unpack('!I', data[40:44])[0]
                t3_frac = struct.unpack('!I', data[44:48])[0]
                t3 = t3_int - NTP_EPOCH + t3_frac / (2**32)
                # Simplified offset: server_time - local_time (ignoring round-trip asymmetry)
                offset = t3 - (t1 + t4) / 2
                return offset
            except Exception:
                continue
        return None

    def ntp_check(self):
        """Attempt NTP sync periodically (every 300 seconds)."""
        # Check for shared NTP server from network (every call, not just at sync time)
        force_sync = False
        try:
            shared_ntp = gd.getv('tntp')
            if isinstance(shared_ntp, str) and shared_ntp and not shared_ntp.startswith('get error'):
                # Prepend shared server if not already first
                if not self.ntp_servers or self.ntp_servers[0] != shared_ntp:
                    print("Using shared NTP server: %s" % shared_ntp)
                    self.ntp_servers = [shared_ntp] + [s for s in self.ntp_servers if s != shared_ntp]
                    force_sync = True  # New server, query immediately
        except Exception:
            pass  # Ignore errors reading shared NTP
        mono = time.monotonic()
        if not force_sync and mono - self.ntp_last_try < 300:
            return
        self.ntp_last_try = mono
        result = self._ntp_query()
        if result is not None:
            self.ntp_offset = result
            if not self.ntp_ok:
                print("NTP sync acquired (offset %.3f S)" % result)
            self.ntp_ok = True
        else:
            # Keep last known offset but mark NTP as unavailable after 3 failures
            self.ntp_ok = False

    def _get_active_nodes(self):
        """Return list of active node names including self."""
        active = [node]
        # Copy values to avoid RuntimeError if dict changes during iteration
        for ni in list(net.si.nodes.values()):
            if ni.age < 60 and ni.nod and ni.nod != node:
                active.append(ni.nod)
        return active

    def _is_online(self, nname):
        """Check if a node is active on the network."""
        if not nname:
            return False
        nname_lower = str.lower(nname)
        if nname_lower == str.lower(node):
            return True
        # Copy values to avoid RuntimeError if dict changes during iteration
        for ni in list(net.si.nodes.values()):
            if ni.age < 60 and ni.nod and str.lower(ni.nod) == nname_lower:
                return True
        return False

    def _am_i_judge(self):
        """Return True if this node is the election judge (lowest named active node)."""
        active = self._get_active_nodes()
        active_lower = [n.lower() for n in active]
        active_lower.sort()
        return active_lower[0] == node.lower()

    def _get_node_priority(self, n):
        """Get priority for a node. 0=GPS, 1=NTP, 2=none. Lower is better."""
        if n.lower() == node.lower():
            if self.gps_locked:
                return 0
            elif self.ntp_ok:
                return 1
            return 2
        ni = net.si.nodes.get(n)
        if ni and ni.gps_locked:
            return 0
        elif ni and ni.ntp_ok:
            return 1
        return 2

    def _run_election(self):
        """Run election and return winner node name.
        Priority: GPS-locked > NTP-synced > lowest node name.
        Designated time master (tmast) is excluded from election."""
        active = self._get_active_nodes()
        # Exclude designated time master from election
        tmast_val = gd.getv('tmast')
        if isinstance(tmast_val, str) and tmast_val and not tmast_val.startswith('get error'):
            active = [n for n in active if n.lower() != tmast_val.lower()]
        # Build candidate list: (priority, name) where lower priority wins
        # Priority: 0=GPS, 1=NTP, 2=none
        candidates = []
        for n in active:
            if n.lower() == node.lower():
                # This node - we know our own status
                if self.gps_locked:
                    candidates.append((0, n))
                elif self.ntp_ok:
                    candidates.append((1, n))
                else:
                    candidates.append((2, n))
            else:
                # Other nodes - look up their GPS/NTP status from broadcasts
                ni = net.si.nodes.get(n)
                if ni and ni.gps_locked:
                    candidates.append((0, n))
                elif ni and ni.ntp_ok:
                    candidates.append((1, n))
                else:
                    candidates.append((2, n))
        # Sort by priority, then by name (lowercase)
        candidates.sort(key=lambda x: (x[0], x[1].lower()))
        return candidates[0][1] if candidates else node

    def update(self):
        """periodic clock update every 30 seconds"""
        broadcast_action = None  # Collect broadcast to do after releasing lock

        self.lock.acquire()
        try:
            # Get current master settings
            tmast_val = gd.getv('tmast')
            if isinstance(tmast_val, str) and tmast_val.startswith('get error'):
                tmast_val = ''
            telect_val = gd.getv('telect')
            if isinstance(telect_val, str) and telect_val.startswith('get error'):
                telect_val = ''

            # Am I the designated master?
            i_am_designated = node.lower() == tmast_val.lower() if tmast_val else False
            # Is designated master online?
            tmast_online = self._is_online(tmast_val) if tmast_val else False
            # Is elected master online? (telect can be "election" during election)
            telect_is_node = telect_val and telect_val.lower() != "election"
            telect_online = self._is_online(telect_val) if telect_is_node else False
            i_am_elected = telect_is_node and node.lower() == telect_val.lower()
            election_in_progress = telect_val.lower() == "election" if telect_val else False

            # === PRIORITY 1: Designated time master (tmast) ===
            if i_am_designated:
                if self._source_type != 'designated':
                    print("Time Master (designated)")
                self.offset = 0 if not self.ntp_offset else self.ntp_offset
                self.level = 0
                self._no_master_cycles = 0
                self._source_type = 'designated'
                self._election_pending = False  # Clear any pending election

            # === PRIORITY 2: Elected time master (telect) when tmast offline ===
            elif i_am_elected and not tmast_online:
                if self._source_type != 'elected':
                    print("Time Master (elected)")
                self.offset = self.ntp_offset if self.ntp_ok else 0
                self.level = 0
                self._no_master_cycles = 0
                self._source_type = 'elected'

            # === Was elected but tmast came back - step down ===
            elif i_am_elected and tmast_online:
                if self._source_type == 'elected':
                    print("Stepping down: designated master '%s' is back online" % tmast_val)
                self._source_type = 'synced'
                self._election_pending = False
                self.level = 9  # Will sync to tmast
                self._do_client_sync()

            # === ELECTION JUDGE DUTIES ===
            elif self._am_i_judge():
                need_election = False
                # tmast set but offline, no valid telect
                if tmast_val and not tmast_online and not telect_online and not election_in_progress:
                    need_election = True
                    print("Judge: tmast '%s' is offline, starting election" % tmast_val)
                # telect set but offline (and tmast still offline or not set)
                elif telect_is_node and not telect_online and not tmast_online:
                    need_election = True
                    print("Judge: telect '%s' is offline, starting new election" % telect_val)
                # No tmast, no telect, no time source for too long
                elif not tmast_val and not telect_val and self._no_master_cycles >= 3:
                    need_election = True
                    print("Judge: no time master, starting election")
                # Designated online but no elected backup
                elif tmast_val and tmast_online and not telect_is_node and not election_in_progress:
                    need_election = True
                    print("Judge: no backup for tmast '%s', electing standby" % tmast_val)
                # Better candidate available (e.g., GPS node joined while non-GPS is elected)
                elif telect_online and not tmast_online:
                    telect_priority = self._get_node_priority(telect_val)
                    for n in self._get_active_nodes():
                        # Skip the current elected master and designated master
                        if n.lower() == telect_val.lower():
                            continue
                        if tmast_val and n.lower() == tmast_val.lower():
                            continue
                        if self._get_node_priority(n) < telect_priority:
                            need_election = True
                            print("Judge: node '%s' has better time source than '%s', starting election" % (n, telect_val))
                            break

                if need_election and not self._election_pending:
                    # Start election
                    self._election_pending = True
                    self._election_start_time = time.monotonic()
                    broadcast_action = "election"
                    print("Judge: election announced, collecting status...")

                # Adopt stalled election: another node published 'election' but
                # this judge hasn't started tracking it yet.  Take over.
                if election_in_progress and not self._election_pending:
                    print("Judge: adopting election in progress")
                    self._election_pending = True
                    self._election_start_time = time.monotonic()

                # If election in progress and we're judge, wait then decide
                if self._election_pending:
                    elapsed = time.monotonic() - self._election_start_time
                    if elapsed >= 10:  # 10 second collection period
                        winner = self._run_election()
                        print("Judge: election complete, winner is '%s'" % winner)
                        broadcast_action = winner
                        self._election_pending = False

                # Judge also syncs time normally
                self._do_client_sync()

            # === NORMAL CLIENT: sync to available master ===
            else:
                # Clear election state if we're no longer judge
                self._election_pending = False
                self._do_client_sync()

        finally:
            self.lock.release()

        # Do broadcast after releasing lock to avoid deadlock
        if broadcast_action:
            self._broadcast_telect(broadcast_action)

    def _do_client_sync(self):
        """Standard client time synchronization logic."""
        if self.errorn > 0:
            error = float(self.errors) / self.errorn
        else:
            error = 0
        self.adjusta = error
        err = abs(error)
        if (err <= 2) & (self.errorn > 0) & (self.srclev < 9):
            self.level = self.srclev + 1
            self._no_master_cycles = 0
            self._source_type = 'synced'
        else:
            self.level = 9
            self._no_master_cycles += 1
            if self.srclev > 8:
                self.adjusta = 0  # no valid source

        if abs(self.adjusta) > 1:
            print("Adjusting Clock %.1f S, src level %d, total offset %.1f S, at %s" %
                  (self.adjusta, self.level, self.offset + self.adjusta, now()))
        self.srclev = 10
        self.src_node = ''  # Reset for next cycle

    def _broadcast_telect(self, value):
        """Broadcast election status to the network.
        value can be: 'election' (in progress), node name (winner), or '' (cleared)"""
        try:
            globDb.put('telect', value)
            qdb.globalshare('telect', value)
            if value == "election":
                print("Broadcast: telect = 'election' (election in progress)")
            elif value:
                print("Broadcast: telect = '%s' (election winner)" % value)
            else:
                print("Broadcast: telect cleared")
        except Exception as e:
            print("Error broadcasting telect: %s" % e)

    def calib(self, fnod, stml, td):
        """process time info in incoming pkt"""
        if fnod == node:
            return
        self.lock.acquire()  # take semaphore
        #    print "time fm",fnod,"lev",stml,"diff",td
        stml = int(stml)
        if stml < self.srclev:
            self.errors, self.errorn = 0, 0
            self.srclev = stml
            self.src_node = fnod  # track who we're syncing from
        if stml == self.srclev:
            self.errorn += 1
            self.errors += td
            if not self.src_node:
                self.src_node = fnod
        self.lock.release()  # release sem

    def adjust(self):
        """adjust the clock each second as needed"""
        # numbers adjusted from ChatGPTv3.5 conversation.
        rate = 0.1  # delta seconds each second
        # thus the clock offset will be adjusted by a maximum of (rate) seconds each second.
        threshold = 0.01  # adjust if error is greaater than this threshold
        # previously .001 (one hundreth of a second) changed to a tenth of a second 30Nov2023 Scott Hibbs KD4SIR
        adj = self.adjusta
        if abs(adj) < threshold:
            return
        if adj > rate:
            adj = rate
        elif adj < -rate:
            adj = -rate + 0.05  # This so it doesn't kick back and forth - 30Nov2023 Scott KD4SIR
            # ChatGPT 3.5 recommended "...0.05  # small positive offset to prevent oscillations" - ChatGPTv3.5
        self.offset += adj
        # or self.offset = float(database.get('tmast',0)) instead of the line above.
        self.adjusta -= adj
        print("Slewing clock", adj, "to", self.offset, "difference is:", self.adjusta)


def initialize():
    # code cleanup and modify (refactor), added wfd support Art Miller KC7SDA 2019
    kinp = ""  # keyboard input
    anscount = ""  # answer counter
    kfd = 0  # FD indicator to skip questions
    print("\n \n")
    print("For the person in Charge of Logging:")
    print("*** ONLY ONE PERSON CAN DO THIS ***")
    print("Do you need to set up the event? Y or N")
    print("       if in doubt select N")
    while anscount != "1":
        kinp = str.lower(str.strip(sys.stdin.readline())[:1])
        if kinp == "y":
            anscount = "1"
        if kinp == "n":
            anscount = '1'
        if anscount != "1":
            print("Press Y or N please")
    if kinp == "y":
        # Field Day or VHF contest
        anscount = ""
        print("Which contest is this?")
        print("F = FD, W = WFD, and V = VHF")
        while anscount != "1":
            kinp = str.lower(str.strip(sys.stdin.readline())[:1])
            if kinp == "f":
                anscount = "1"
            if kinp == "w":
                anscount = "1"
            if kinp == "v":
                anscount = '1'
            if anscount != "1":
                print("Press F, W or V please")
        if kinp == "f":
            kfd = 1  # used later to skip grid square question.
            globDb.put('contst', "FD")
            qdb.globalshare('contst', "FD")  # global to db
            renew_title()
            print("Have a nice Field Day!")
        if kinp == "w":
            kfd = 2  # used later to skip grid square question.
            globDb.put('contst', "WFD")
            qdb.globalshare('contst', "WFD")  # global to db
            renew_title()
            print("Have a nice Field Day!")
        if kinp == "v":
            globDb.put('contst', "VHF")
            qdb.globalshare('contst', "VHF")  # global to db
            renew_title()
            print("Enjoy the VHF contest!")
        # Name of the club or group
        print("What is the NAME of your club or group?")
        kinp = str.strip(sys.stdin.readline())
        while kinp == "":
            print("Please type the NAME of your club or group")
            kinp = str.strip(sys.stdin.readline())
        globDb.put('grpnam', kinp)
        qdb.globalshare('grpnam', kinp)  # global to db
        renew_title()
        print(kinp, "is a nice name.")
        # Club Call
        # Fixed lower case so Club and GOTA it would match dupe check - Scott Hibbs 18Jun2022
        print("What will be your club call?")
        kinp = str.strip(sys.stdin.readline())
        kinp = kinp.lower()
        while kinp == "":
            print("Please type the club call.")
            kinp = str.strip(sys.stdin.readline())
            kinp = kinp.lower()
        globDb.put('fdcall', kinp)
        qdb.globalshare('fdcall', kinp)  # global to db
        renew_title()
        print(kinp, "will be the club call.")
        # Gota Call
        if kfd == 1:
            print("What will be your GOTA call?")
            kinp = str.strip(sys.stdin.readline())
            kinp = kinp.lower()
            while kinp == "":
                print("Please type the GOTA call. (if none type none)")
                kinp = str.strip(sys.stdin.readline())
                kinp = kinp.lower()
            else:
                globDb.put('gcall', kinp)
                qdb.globalshare('gcall', kinp)  # global to db
                renew_title()
                print(kinp, "will be the GOTA call.")
        # Class
        print("What will be your class? (like 2A)")
        kinp = str.strip(sys.stdin.readline())
        while kinp == "":
            print("Please type the class.")
            kinp = str.strip(sys.stdin.readline())
        else:
            globDb.put('class', kinp)
            qdb.globalshare('class', kinp)  # global to db
            renew_title()
            print(kinp, "will be the class.")
        # Section - validate against Arrl_sections_ref.txt
        valid_sections = {}
        sect_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Arrl_sections_ref.txt")
        try:
            with open(sect_file, "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        parts = line.split()
                        if parts:
                            valid_sections[parts[0].upper()] = line
        except FileNotFoundError:
            print("Warning: Arrl_sections_ref.txt not found, skipping validation.")
        print("What will be your section abbreviation? (e.g. IN, EMA, STX)")
        kinp = str.strip(sys.stdin.readline()).upper()
        while kinp == "" or (valid_sections and kinp not in valid_sections):
            if kinp == "":
                print("Please type your section abbreviation.")
            else:
                print(f"'{kinp}' is not a valid section. Examples: CO, EMA, NLI, STX, TER")
            kinp = str.strip(sys.stdin.readline()).upper()
        if kinp in valid_sections:
            print(f"  {valid_sections[kinp]}")
        globDb.put('sect', kinp)
        qdb.globalshare('sect', kinp)  # global to db
        renew_title()
        print(kinp, "will be the section.")
        if kfd == 0:
            # grid square
            print("What will be your grid square? (if none type none)")
            kinp = str.strip(sys.stdin.readline())
            while kinp == "":
                print("Please type the grid square. (For FD type none)")
                kinp = str.strip(sys.stdin.readline())
                kinp = kinp.upper()  # changed the init so the grid square will be caps -Art Miller KC7SDA 2019
            else:
                globDb.put('grid', kinp)
                qdb.globalshare('grid', kinp)  # global to db
                renew_title()
                print(kinp, "will be the grid.")
        if kfd != 2:
            # questions for vhf and fd, skip for wfd
            # Bonus Points Questions - Added comprehensive prompts Jan 2026
            anscount = ""
            print("\n--- BONUS POINTS SETUP ---")
            print("Are you ready to answer bonus point questions?")
            print("(You can set these later with 'set' command)")
            print("Y = yes, N = skip all bonus questions")
            while anscount != "1":
                kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                if kinp == "y":
                    anscount = "1"
                if kinp == "n":
                    anscount = '1'
                if anscount == "":
                    print("Press Y or N please")
            if kinp == "y":
                # Public Place
                anscount = ""
                print("\n1. Will the location be in a public place? (100 pts)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('public', "A public location")
                    qdb.globalshare('public', "A public location")
                    print("  Public location bonus enabled!")
                else:
                    globDb.put('public', "")
                    qdb.globalshare('public', "")
                # Info Booth
                anscount = ""
                print("\n2. Will you have an information booth/table? (100 pts)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('infob', "1")
                    qdb.globalshare('infob', "1")
                    print("  Information booth bonus enabled!")
                else:
                    globDb.put('infob', "0")
                    qdb.globalshare('infob', "0")
                # Safety Officer
                anscount = ""
                print("\n3. Will you have a designated Safety Officer? (100 pts)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('safety', "1")
                    qdb.globalshare('safety', "1")
                    print("  Safety Officer bonus enabled!")
                else:
                    globDb.put('safety', "0")
                    qdb.globalshare('safety', "0")
                # Site Responsibilities
                anscount = ""
                print("\n4. Will someone handle Site Responsibilities? (50 pts)")
                print("   (Ensuring site is hazard-free throughout event)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('sitere', "1")
                    qdb.globalshare('sitere', "1")
                    print("  Site Responsibilities bonus enabled!")
                else:
                    globDb.put('sitere', "0")
                    qdb.globalshare('sitere', "0")
                # Educational Activity
                anscount = ""
                print("\n5. Will you have an Educational Activity? (100 pts)")
                print("   (Formal amateur radio education component)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('eduact', "1")
                    qdb.globalshare('eduact', "1")
                    print("  Educational Activity bonus enabled!")
                else:
                    globDb.put('eduact', "0")
                    qdb.globalshare('eduact', "0")
                # Social Media
                anscount = ""
                print("\n6. Will you promote on Social Media? (100 pts)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('social', "1")
                    qdb.globalshare('social', "1")
                    print("  Social Media bonus enabled!")
                else:
                    globDb.put('social', "0")
                    qdb.globalshare('social', "0")
                # GOTA Coach
                anscount = ""
                print("\n7. Will you have a GOTA Coach? (100 pts if 10+ GOTA QSOs)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('gotaco', "1")
                    qdb.globalshare('gotaco', "1")
                    print("  GOTA Coach bonus enabled!")
                else:
                    globDb.put('gotaco', "0")
                    qdb.globalshare('gotaco', "0")
                # Youth Participants
                print("\n8. How many youth participants (under 18)? (20 pts each, max 100)")
                print("   Enter a number 0-99 (0 if none):")
                while True:
                    kinp = str.strip(sys.stdin.readline())
                    if kinp.isdigit() and 0 <= int(kinp) <= 99:
                        break
                    print("Please enter a number 0-99")
                globDb.put('youth', kinp)
                qdb.globalshare('youth', kinp)
                if int(kinp) > 0:
                    print("  Youth participation: %s youth!" % kinp)
                # Government Official Visit
                print("\n9. Name of visiting elected government official? (100 pts)")
                print("   (Leave blank if none, or enter name):")
                kinp = str.strip(sys.stdin.readline())[:35]
                globDb.put('svego', kinp)
                qdb.globalshare('svego', kinp)
                if kinp:
                    print("  Government official visit: %s" % kinp)
                # Agency Representative Visit
                print("\n10. Name of visiting agency representative? (100 pts)")
                print("    (Red Cross, FEMA, etc. Leave blank if none):")
                kinp = str.strip(sys.stdin.readline())[:35]
                globDb.put('svroa', kinp)
                qdb.globalshare('svroa', kinp)
                if kinp:
                    print("  Agency representative visit: %s" % kinp)
                # Web Submission
                anscount = ""
                print("\n11. Will you submit entry via web? (50 pts)")
                print("Y = yes, N = no")
                while anscount != "1":
                    kinp = str.lower(str.strip(sys.stdin.readline())[:1])
                    if kinp == "y":
                        anscount = "1"
                    if kinp == "n":
                        anscount = '1'
                    if anscount == "":
                        print("Press Y or N please")
                if kinp == "y":
                    globDb.put('websub', "1")
                    qdb.globalshare('websub', "1")
                    print("  Web submission bonus enabled!")
                else:
                    globDb.put('websub', "0")
                    qdb.globalshare('websub', "0")
                print("\n--- Bonus points setup complete! ---")
                print("Use 'set' command to change these later.")
                print("Use 'score' command to see your score.\n")
            else:
                print("\nSkipping bonus questions. Use 'set' command later.")
                print("Available bonus fields: public, infob, safety, sitere,")
                print("eduact, social, gotaco, youth, svego, svroa, websub\n")
        # Admin PIN setup
        print("\n--- ADMIN PIN SETUP ---")
        print("Enter a 4-digit admin PIN for editing participants.")
        print("(This PIN will be required to edit participant data)")
        pin_set = False
        while not pin_set:
            print("Enter PIN: ", end="", flush=True)
            pin1 = str.strip(sys.stdin.readline())
            if not re.match(r'^\d{4}$', pin1):
                print("PIN must be exactly 4 digits. Try again.")
                continue
            print("Confirm PIN: ", end="", flush=True)
            pin2 = str.strip(sys.stdin.readline())
            if pin1 != pin2:
                print("PINs do not match. Try again.")
                continue
            hashed = hashlib.md5(pin1.encode()).hexdigest()
            globDb.put('adminpin', hashed)
            qdb.globalshare('adminpin', hashed)
            print("Admin PIN set successfully.\n")
            pin_set = True
        # Deploy to other computers
        anscount = ""
        print("\nDo you need to deploy this program to other computers?")
        print("This will create a zip and share it on the network.")
        print("Y = yes, N = no")
        while anscount != "1":
            kinp = str.lower(str.strip(sys.stdin.readline())[:1])
            if kinp == "y":
                anscount = "1"
            if kinp == "n":
                anscount = '1'
            if anscount == "":
                print("Press Y or N please")
        if kinp == "y":
            import subprocess
            # Check multiple locations: next to script, next to exe, and current working dir
            candidates = [
                os.path.join(os.path.dirname(os.path.abspath(__file__)), "share_fdlog.py"),
                os.path.join(os.path.dirname(os.path.abspath(sys.executable)), "share_fdlog.py"),
                os.path.join(os.getcwd(), "share_fdlog.py"),
            ]
            share_script = next((p for p in candidates if os.path.isfile(p)), None)
            if share_script:
                print(f"Launching: {share_script}")
                # Find Python interpreter (sys.executable may be the PyInstaller exe)
                import shutil
                python_exe = shutil.which("python") or shutil.which("python3") or sys.executable
                subprocess.Popen(
                    [python_exe, share_script],
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                )
                print("Deployment server is running in a separate window.")
                print("Close that window when all computers have downloaded.\n")
            else:
                print("Error: share_fdlog.py not found. Skipping deployment.\n")
    return


def exin(op):
    """extract Contestant or logger initials"""
    r = ""
    corlinit = re.match(r'([a-z\d]{2,3})', op)
    if corlinit:
        r = corlinit.group(1)
    return r


def set_font(face, size):
    """ Font menu selection to change the font and size
        Consolidated from 10 separate functions - Scott Hibbs KD4SIR 09Aug2022
    """
    global typeface, fontsize, fdfont
    typeface = face
    fontsize = size
    fdfont = (typeface, fontsize)
    redrawall()


def redrawall():
    """ Used by Font menu selections to redraw all the elements again """
    #  Added by Scott Hibbs KD4SIR 09Aug2022
    #  Refactored to use recursive traversal - no need to name every widget
    global fdfont

    def update_fonts_recursive(widget):
        """Recursively update fonts for all child widgets."""
        for child in widget.winfo_children():
            # Check if widget supports font option before trying to set it
            try:
                if 'font' in child.keys():
                    child.config(font=fdfont)
            except tkinter.TclError:
                # Skip any widgets that cause errors
                pass
            # Recurse into children
            update_fonts_recursive(child)

    # Update fonts on all widgets starting from root
    update_fonts_recursive(root)

    # These special function calls rebuild their sections (more than just font)
    bandbuttons(f1)
    bandset(band)
    renew_title()
    logwredraw()


class SQDB:
    """SQL database upgrade"""

    # sqlite3.connect(":memory:", check_same_thread = False)
    # I found this online to correct thread errors with SQL locking to one thread only.
    # Scott Hibbs 7/5/2015

    def __init__(self):
        self.dbPath = logdbf[0:-4] + '.sq3'
        #  print "Using database", self.dbPath
        self.sqdb = sqlite3.connect(self.dbPath, check_same_thread=False)  # connect to the database
        # Have to add FALSE here to get this stable - Scott Hibbs 7/17/2015
        self.sqdb.row_factory = sqlite3.Row  # namedtuple_factory
        self.curs = self.sqdb.cursor()  # make a database connection cursor
        sql = "create table if not exists qjournal(src text,seq int,date text,band " \
              "text,call text,rept text,powr text,oper text,logr text,primary key (src,seq))"
        self.curs.execute(sql)
        self.sqdb.commit()

    def readlog(self):  # ,srcId,srcIdx):            # returns list of log journal items
        print("Loading log journal from sqlite database")
        sql = "select * from qjournal"
        result = self.curs.execute(sql)
        nl = []
        for r in result:
            # print dir(r)
            nl.append("|".join(('q', r['src'], str(r['seq']), r['date'], r['band'], r['call'], r['rept'], r['powr'],
                                r['oper'], r['logr'], '')))
        # print nl
        return nl

    def log(self, n):  # add item to journal logfile table (and other tables...)
        parms = (n.src, n.seq, n.date, n.band, n.call, n.rept, n.powr, n.oper, n.logr)
        sqdb1 = sqlite3.connect(self.dbPath)  # connect to the database
        #        self.sqdb.row_factory = sqlite3.Row   # namedtuple_factory
        curs = sqdb1.cursor()  # make a database connection cursor
        # start commit, begin transaction
        sql = "insert into qjournal (src,seq,date,band,call,rept,powr,oper,logr) values (?,?,?,?,?,?,?,?,?)"
        curs.execute(sql, parms)
        # sql = "insert into qsos values (src,seq,date,band,call,sfx,rept,powr,oper,logr),(?,?,?,?,?,?,?,?,?,?)"
        # self.cur(sql,parms)
        # update qso count, scores? or just use q db count? this doesn't work well for different weights
        # update sequence counts for journals?
        sqdb1.commit()  # do the commit
        if n.band == '*QST':
            print(("QST " + n.rept + " -" + n.logr))
            try:
                if sound_enabled.get(): root.bell()  # Audio notification for QST (if enabled)
            except NameError:
                pass  # sound_enabled not yet defined during startup


class QsoDb:
    """Database class for QSOs."""

    def __init__(self):
        self.seq = None
        self.src = None
        self.date = None
        self.band = None
        self.call = None
        self.rept = None
        self.powr = None
        self.oper = None
        self.logr = None

    byid = {}  # qso database by src.seq
    bysfx = {}  # call list by suffix.band
    hiseq = {}  # high sequence number by node
    lock = threading.RLock()  # sharing lock

    @staticmethod
    def new(source):
        n = QsoDb()
        n.src = source  # source id
        return n

    def to_log(self):
        """Make log file entry."""
        self._log_to_database()
        self._log_to_file()

    def _log_to_database(self):
        SQDB().log(self)

    def _log_to_file(self):
        with self.lock:
            with open(logdbf, "a") as fd:
                fd.write(f"\nq|{self.src}|{self.seq}|{self.date}|{self.band}|{self.call}|{self.rept}|{self.powr}|"
                         f"{self.oper}|{self.logr}|")

    # def to_log(self):
    #     """ make log file entry """
    #     SQDB().log(self)  # to database
    #     self.lock.acquire()  # and to ascii journal file as well
    #     fd = open(logdbf, "a")
    #     fd.write("\nq|%s|%s|%s|%s|%s|%s|%s|%s|%s|" %
    #              (self.src, self.seq,
    #               self.date, self.band, self.call, self.rept,
    #               self.powr, self.oper, self.logr))
    #     fd.close()
    #     self.lock.release()

    def ldrec(self, line):
        """Load log entry from text"""
        (dummy, self.src, self.seq, self.date, self.band, self.call, self.rept, self.powr, self.oper,
         self.logr, dummy) = str.split(line, '|')
        self.seq = int(self.seq)
        self.dispatch('logf')

    @staticmethod
    def loadfile():
        """Load the log file."""
        # global sqdb  # setup sqlite database connection
        print("Loading Log File")
        icounter, s, log = 0, 0, []
        sqdb = SQDB()  # type: SQDB
        log = sqdb.readlog()  # read the database
        for ln in log:
            if ln[0] == 'q':  # qso db line 
                r = qdb.new(0)
                try:
                    r.ldrec(ln)
                    icounter += 1
                except ValueError as ee:
                    print("  error, item skipped: ", ee)
                    print("    in:", ln)
                    s += 1
                    # sqdb.log(r)
                    #  push a copy from the file into the
                    # database (temporary for transition)
        if icounter == 0 and s == 1:
            print("Log file not found, must be new")
            initialize()  # Set up routine - Scott Hibbs 7/26/2015
        else:
            print("  ", icounter, "Records Loaded,", s, "Errors")
        if icounter == 0:
            initialize()

    def cleanlog(self):
        """return clean filtered dictionaries of the log"""
        d, cdict, gdict = {}, {}, {}
        fdstart, fdend = gd.getv('fdstrt'), gd.getv('fdend')
        self.lock.acquire()
        for index in list(self.byid.values()):  # copy, index by node, sequence
            strsrcseq = "%s|%s" % (index.src, index.seq)
            d[strsrcseq] = index
        self.lock.release()
        for index in list(d.keys()):  # process deletes
            if index in d:
                iv = d[index]
                if iv.rept[:5] == "*del:":
                    dummy, st, sn, dummy = iv.rept.split(':')  # extract deleted id
                    strsrcseq = "%s|%s" % (st, sn)
                    if strsrcseq in list(d.keys()):
                        #  print iv.rept,; iv.pr()
                        del (d[strsrcseq])  # delete it
                        # else: print "del target missing",iv.rept
                    del (d[index])
        for index in list(d.keys()):  # filter time window
            iv = d[index]
            if iv.date < fdstart or iv.date > fdend:
                # print "discarding out of date range",iv.date,iv.src,iv.seq
                del (d[index])
        for index in list(d.values()):  # re-index by call-band
            dummy, dummy, dummy, dummy, call1, dummy, dummy = self.qparse(index.call)  # extract call (not /...)
            strsrcseq = "%s-%s" % (call1, index.band)
            # filter out noncontest entries
            if ival(index.powr) == 0 and index.band[0] != '*':
                continue
            if index.band == 'off':
                continue
            if index.band[0] == '*':
                continue  # rm special msgs
            if index.src == 'gotanode':
                gdict[strsrcseq] = index  # gota is separate dup space
            else:
                cdict[strsrcseq] = index
        return d, cdict, gdict  # Deletes processed, fully Cleaned
        #     by id, call-bnd, gota by call-bnd

    @staticmethod
    def prlogln(s):
        """convert log item to display format"""
        #  note that a lot of functions read data by location from the editor so
        #  changing columns matters to these other functions.
        if s.band == '*QST':
            ln = "%8s %5s %-41s %-3s %-3s %4s %s" % \
                 (s.date[4:11], s.band, s.rept[:41], s.oper, s.logr, s.seq, s.src)
        elif s.band == '*set':
            ln = "%8s %5s %-11s %-29s %-3s %-3s %4s %s" % \
                 (s.date[4:11], s.band, s.call[:10], s.rept[:29], s.oper, s.logr, s.seq, s.src)
        elif s.rept[:5] == '*del:':
            ln = "%8s %5s %-7s %-33s %-3s %-3s %4s %s" % \
                 (s.date[4:11], s.band, s.call[:7], s.rept[:33], s.oper, s.logr, s.seq, s.src)
        else:
            ln = "%8s %5s %-11s %-24s %4s %-3s %-3s %4s %s" % \
                 (s.date[4:11], s.band, s.call[:11], s.rept[:24], s.powr, s.oper, s.logr, s.seq, s.src)
        return ln

    def pr_log(self):
        """Print the log, in time order"""
        llist = self.filterlog("")
        for strii in llist:
            print(strii)

    def pr_adif(self):
        """print clean log in adif format"""
        pgm = "FDLog_Enhanced (https://github.com/scotthibbs/FDLog_Enhanced)"
        print("<PROGRAMID:%d>%s" % (len(pgm), pgm))
        dummy, n, strgg = self.cleanlog()
        for iii in list(n.values()) + list(strgg.values()):
            dat = "20%s" % iii.date[0:6]
            tim = iii.date[7:11]
            cal = iii.call
            bnd = "%sm" % iii.band[:-1]
            mod = iii.band[-1:]
            if mod == 'p':
                mod = 'SSB'
            elif mod == 'c':
                mod = 'CW'
            elif mod == 'd':
                mod = 'RTTY'
            com = iii.rept
            print("<QSO_DATE:8>%s" % dat)
            print("<TIME_ON:4>%s" % tim)
            print("<CALL:%d>%s" % (len(cal), cal))
            print("<BAND:%d>%s" % (len(bnd), bnd))
            print("<MODE:%d>%s" % (len(mod), mod))
            print("<QSLMSG:%d>%s" % (len(com), com))
            print("<EOR>")
            print()

    def filterlog(self, filt):
        """list filtered (by bandm) log in time order, nondup valid q's only"""
        somelocallist2 = []
        dummy, n, gg = self.cleanlog()
        for i6 in list(n.values()) + list(gg.values()):
            if filt == "" or re.match('%s$' % filt, i6.band):
                somelocallist2.append(i6.prlogln(i6))
        somelocallist2.sort()
        return somelocallist2

    def filterlog2(self, filt):
        """list filtered (by bandm) log in time order, including special msgs"""
        somelocallist3 = []
        mm, dummy, dummy = self.cleanlog()
        for i7 in list(mm.values()):
            if filt == "" or re.match('%s$' % filt, i7.band):
                somelocallist3.append(i7.prlogln(i7))
        somelocallist3.sort()
        return somelocallist3

    def filterlog3(self, filt):
        """list filtered (by mode) log in time order, including special msgs"""
        # Added by Scott Hibbs KD4SIR 05Aug2022
        somelocallist3z = []
        mmz, dummy, dummy = self.cleanlog()
        for i7z in list(mmz.values()):
            if filt in i7z.band:
                somelocallist3z.append(i7z.prlogln(i7z))
        somelocallist3z.sort()
        return somelocallist3z

    def filterlogst(self, filt):
        """list filtered (by nod) log in time order, including special msgs"""
        somelocallist4 = []
        mmm, dummy, dummy = self.cleanlog()
        for i8 in list(mmm.values()):
            if re.match('%s$' % filt, i8.src):
                somelocallist4.append(i8.prlogln(i8))
        somelocallist4.sort()
        return somelocallist4

    def qsl(self, time1, call3, bandmod, report):
        """log a qsl"""
        return self.post_new_info(time1, call3, bandmod, report)

    def qst(self, msg):
        """put a qst in database + log"""
        return self.post_new_info(now(), '', '*QST', msg)

    def globalshare(self, name1, value):
        """put global var set in db + log"""
        return self.post_new_info(now(), name1, '*set', value)

    def post_new_info(self, time2, call4, bandmod, report):
        """post new locally generated info"""
        # Added tmob so that we can count time inactive - Scott Hibbs KD4SIR 09Aug2022
        global tmob
        tmob = now()
        return self.post_new(time2, call4, bandmod, report, exin(operator),
                             exin(logger), power)

    def post_new(self, time3, call5, bandmod, report, oper, logr, powr):
        """post new locally generated info"""
        s = self.new(node)
        s.date, s.call, s.band, s.rept, s.oper, s.logr, s.powr = time3, call5, bandmod, report, oper, logr, powr
        s.seq = -1
        return s.dispatch('user')

    def qdelete(self, nod, seq, reason):
        """remove a Qso by creating delete record"""
        global node
        #        print "del",nod,seq
        a, dummy, dummy = self.cleanlog()
        k3 = "%s|%s" % (nod, seq)
        if k3 in a and a[k3].band[0] != '*':  # only visible qso records
            tm, call6, bandmod = a[k3].date, a[k3].call, a[k3].band
            rept = "*del:%s:%s:%s" % (nod, seq, reason)
            s = self.new(node)
            s.date, s.call, s.band, s.rept, s.oper, s.logr, s.powr = \
                now(), call6, bandmod, rept, exin(operator), exin(logger), 0
            s.seq = -1
            s.dispatch('user')
            txtbillb.insert(END, " DELETE Successful %s %s %s\n" % (tm, call6, bandmod))
            topper()
            logw.config(state="normal")
            logw.delete(0.1, END)
            logw.insert(END, "\n")
            # This Redraws the logw text window (on delete) to only show valid calls in the log.
            # This avoids confusion by only listing items in the log to edit in the future.
            # Scott Hibbs KD4SIR - 03Jul2018
            # Fixed so that it wasn't printing in all blue - Scott Hibbs KD4SIR 31Jul2022
            # i9.prlogln(i9) gives the line of the log output.
            for i9 in list(a.values()):
                if i9.seq == seq:
                    continue
                else:
                    if node in i9.prlogln(i9):
                        logw.insert(END, i9.prlogln(i9), "b")
                        logw.insert(END, "\n")
                    else:
                        logw.insert(END, i9.prlogln(i9))
                        logw.insert(END, "\n")
            logw.config(state="disabled")
        else:
            txtbillb.insert(END, " DELETE Ignored [%s,%s] Not Found\n" % (nod, seq))
            topper()

    def udelete(self, nod, seq, reason):
        """remove a user by creating delete record"""
        #  Added by Scott Hibbs KD4SIR 22Aug2022
        global node
        a, dummy, dummy = self.cleanlog()
        k5 = "%s|%s" % (nod, seq)
        if k5 in a:  # check if in log
            tm, call6, bandmod = a[k5].date, a[k5].call, a[k5].band
            rept = "*del:%s:%s:%s" % (nod, seq, reason)
            s = self.new(node)
            s.date, s.call, s.band, s.rept, s.oper, s.logr, s.powr = \
                now(), call6, bandmod, rept, exin(operator), exin(logger), 0
            s.seq = -1
            s.dispatch('udelete')
            txtbillb.insert(END, " DELETE Successful %s %s %s\n" % (tm, call6, bandmod))
            topper()
            logw.config(state="normal")
            logw.delete(0.1, END)
            logw.insert(END, "\n")
            # This Redraws the logw text window (on delete) to only show valid calls in the log.
            # This avoids confusion by only listing items in the log to edit in the future.
            # Scott Hibbs KD4SIR - 03Jul2018
            # Fixed so that it wasn't printing in all blue - Scott Hibbs KD4SIR 31Jul2022
            # i9.prlogln(i9) is the line of the log output that was read.
            for i9 in list(a.values()):
                if i9.seq == seq:
                    continue
                else:
                    if node in i9.prlogln(i9):
                        logw.insert(END, i9.prlogln(i9), "b")
                        logw.insert(END, "\n")
                    else:
                        logw.insert(END, i9.prlogln(i9))
                        logw.insert(END, "\n")
            logw.config(state="disabled")
        else:
            txtbillb.insert(END, " DELETE Ignored [%s,%s] Not Found\n" % (nod, seq))
            topper()

    def qdelete_silent(self, nod, seq, reason):
        """Remove a QSO by creating delete record - no GUI updates (for network operations)"""
        # Added by Scott Hibbs KD4SIR Jan 2026 for network dupe checking
        global node
        a, dummy, dummy = self.cleanlog()
        k3 = "%s|%s" % (nod, seq)
        if k3 in a and a[k3].band[0] != '*':  # only visible qso records
            call6, bandmod = a[k3].call, a[k3].band
            rept = "*del:%s:%s:%s" % (nod, seq, reason)
            s = self.new(node)
            s.date, s.call, s.band, s.rept, s.oper, s.logr, s.powr = \
                now(), call6, bandmod, rept, exin(operator), exin(logger), 0
            s.seq = -1
            s.dispatch('user')
            print("  Network Dupe: deleted %s %s from %s (reason: %s)" % (call6, bandmod, nod, reason))
            return True
        return False

    def check_network_dupe(self, new_src, new_seq, new_date, new_band, new_call):
        """Check for duplicate call-band when receiving network records.
        If dupe found, keep the oldest record and delete the newer one.
        Added by Scott Hibbs KD4SIR Jan 2026"""
        global node
        # Skip special messages
        if new_band[0] == '*':
            return
        # Parse the call to get base call
        dummy, dummy, dummy, dummy, base_call, dummy, dummy = self.qparse(new_call)
        if not base_call:
            base_call = new_call.lower()  # fallback to full call if parse fails
        # Get contest time window
        fdstart, fdend = gd.getv('fdstrt'), gd.getv('fdend')
        # Scan all records in byid for duplicates
        with self.lock:
            for rec_key, rec in list(self.byid.items()):
                # Skip special messages and delete markers
                if rec.band[0] == '*' or rec.rept[:5] == '*del:':
                    continue
                # Skip records outside contest time window
                if rec.date < fdstart or rec.date > fdend:
                    continue
                # Skip zero power (not real QSO)
                if ival(rec.powr) == 0:
                    continue
                # Skip if same record (same src and seq)
                if rec.src == new_src and rec.seq == int(new_seq):
                    continue
                # Check GOTA vs non-GOTA (separate dupe spaces)
                if (new_src == 'gotanode') != (rec.src == 'gotanode'):
                    continue
                # Parse existing call
                dummy, dummy, dummy, dummy, rec_call, dummy, dummy = self.qparse(rec.call)
                if not rec_call:
                    rec_call = rec.call.lower()
                # Check if same call and band
                if base_call == rec_call and new_band == rec.band:
                    # Found a duplicate! Compare timestamps
                    try:
                        time_diff = tmsub(new_date, rec.date)
                        if time_diff > 0:
                            # New record is NEWER - delete the new record
                            print("  Network Dupe Found: %s on %s (new from %s is newer than %s)" %
                                  (new_call, new_band, new_src, rec.src))
                            self.qdelete_silent(new_src, int(new_seq), "netdupe-newer")
                        elif time_diff < 0:
                            # New record is OLDER - delete the existing record
                            print("  Network Dupe Found: %s on %s (existing from %s is newer than %s)" %
                                  (rec.call, rec.band, rec.src, new_src))
                            self.qdelete_silent(rec.src, rec.seq, "netdupe-older")
                        return  # Only handle first dupe found
                    except Exception as err:
                        print("  Network dupe check error: %s" % str(err))

    def todb(self):
        """Q record object to db"""
        r = None
        # self.lock.acquire()
        with self.lock:
            current = self.hiseq.get(self.src, 0)
            self.seq = int(self.seq)
            if self.seq == current + 1:  # filter out dup or nonsequential
                self.byid["%s.%s" % (self.src, self.seq)] = self
                self.hiseq[self.src] = current + 1
                # if debug: print "todb:",self.src,self.seq
                r = self
            elif self.seq == current:
                if debug:
                    print("dup sequence log entry ignored")
            else:
                print("out of sequence log entry ignored", self.seq, current + 1)
        # self.lock.release()
        return r

    def pr(self):
        """print Q record object"""
        sms.prmsg(self.prlogln(self))

    def dispatch(self, src):
        """process new db rec (fm logf,user,net) to where it goes"""
        # src is the reason this was called.
        with self.lock:
            self.seq = int(self.seq)
            if self.seq == -1:  # assign new seq num
                self.seq = self.hiseq.get(self.src, 0) + 1
            r = self.todb()
        if r:  # r was set to self.todb() so always true
            self.pr()  # prints the q record object
            if src != 'logf':
                self.to_log()
            if src == 'user':
                net.bc_qsomsg(self.src, self.seq)
            if self.band == '*set':
                # oper is initials of person at the node;
                # call is p:initials of new person;
                # rept is "initials, name, call, age, title" of new person
                # self.src is the node in the log entry?
                if src == 'udelete':
                    net.bc_qsomsg(self.src, self.seq)
                else:
                    m5 = gd.setv(r.call, r.rept, r.date)
                    if not m5:
                        r = None
            else:
                self.logdup()
        return r  # remember r is self.todb()

    def band_rpt(self):
        """band report q/band pwr/band, q/oper q/logr q/station"""
        qpb, ppb, qpop, qplg, qpst, tq, score, maxp = {}, {}, {}, {}, {}, 0, 0, 0
        cwq, digq, fonq = 0, 0, 0
        qpgop, gotaq, nat, sat = {}, 0, [], []
        # qso per band, power per band, qso per operator, qso per logger, qso per station, total qsos,
        # score points, max power, cw qsos, digital qsos, phone qsos, qso per gota operator, gota qsos,
        # natural power, satelite
        dummy, c1, g3 = self.cleanlog()  # by id, call-bnd, gota by call-bnd
        for i10 in list(c1.values()) + list(g3.values()):
            if re.search('sat', i10.band):
                sat.append(i10)
            if 'n' in i10.powr:
                nat.append(i10)
            # stop ignoring above 100 q's per oper per new gota rules. - Alan Biocca (W6AKB) Jun2005
            # GOTA q's stop counting over 400 (500 in 2009)
            if i10.src == 'gotanode':  # analyze gota limits
                qpgop[i10.oper] = qpgop.get(i10.oper, 0) + 1
                qpop[i10.oper] = qpop.get(i10.oper, 0) + 1
                qplg[i10.logr] = qplg.get(i10.logr, 0) + 1
                qpst[i10.src] = qpst.get(i10.src, 0) + 1
                if gotaq >= 500:
                    continue  # stop over 500 total
                gotaq += 1
                tq += 1
                score += 1
                if 'c' in i10.band:
                    cwq += 1
                    score += 1
                    qpb['gotac'] = qpb.get('gotac', 0) + 1
                    ppb['gotac'] = max(ppb.get('gotac', 0), ival(i10.powr))
                if 'd' in i10.band:
                    digq += 1
                    score += 1
                    qpb['gotad'] = qpb.get('gotad', 0) + 1
                    ppb['gotad'] = max(ppb.get('gotad', 0), ival(i10.powr))
                if 'p' in i10.band:
                    fonq += 1
                    qpb['gotap'] = qpb.get('gotap', 0) + 1
                    ppb['gotap'] = max(ppb.get('gotap', 0), ival(i10.powr))
                continue
            qpb[i10.band] = qpb.get(i10.band, 0) + 1
            ppb[i10.band] = max(ppb.get(i10.band, 0), ival(i10.powr))
            maxp = max(maxp, ival(i10.powr))
            qpop[i10.oper] = qpop.get(i10.oper, 0) + 1
            qplg[i10.logr] = qplg.get(i10.logr, 0) + 1
            qpst[i10.src] = qpst.get(i10.src, 0) + 1
            score += 1
            tq += 1
            if 'c' in i10.band:
                score += 1  # extra cw and dig points
                cwq += 1
            if 'd' in i10.band:
                score += 1
                digq += 1
            if 'p' in i10.band:
                fonq += 1
        return qpb, ppb, qpop, qplg, qpst, tq, score, maxp, cwq, digq, fonq, qpgop, gotaq, nat, sat

    def status_so_far(self):
        """ .ba command band status station on, q/band, xx needs upgd"""
        # This function from 152i
        qpb, tmlq, dummy = {}, {}, {}
        # qso per band, time since last qso,
        self.lock.acquire()
        for i11 in list(self.byid.values()):  # reading qso database by src.seq
            if ival(i11.powr) < 1:
                continue
            if i11.band == 'off':
                continue
            v = 1
            if i11.rept[:5] == '*del:':
                v = -1
            qpb[i11.band] = qpb.get(i11.band, 0) + v  # num q's
            tmlq[i11.band] = max(tmlq.get(i11.band, ''), i11.date)  # time of last (latest) q
        self.lock.release()
        print()
        print("Stations this node is hearing:")
        # scan for stations on bands
        for s in list(net.si.nodes.values()):  # xx
            # print dir(s)
            print(s.nod, s.host, s.ip, s.stm)
            # nod[s.bnd] = s.nod_on_band()
            # print "%8s %4s %18s %s"%(s.nod,s.bnd,s.msc,s.stm)
            # s.stm,s.nod,seq,s.bnd,s.msc
            # i.tm,i.fnod,i.fip,i.stm,i.nod,i.seq,i.bnd,i.msc
        d = {}
        print()
        print("Node Info")
        print("--node-- band --opr lgr pwr----- Min last heard")
        for t in list(net.si.nodinfo.values()):
            dummy, dummy, age1 = d.get(t.nod, ('', '', 9999))
            if age1 > t.age:
                d[t.nod] = (t.bnd, t.msc, t.age)
        for t in d:
            print("%8s %4s %-18s %4s" % (t, d[t][0], d[t][1], d[t][2]))  # t.bnd,t.msc,t.age)
        print()
        print("  band -------- cw ----- ------- dig ----- ------- fon -----")
        print("          nod  Q's  tslq    nod  Q's  tslq    nod  Q's  tslq")
        #      xxxxxx yyyyyy xxxx xxxxx yyyyyy xxxx xxxxx yyyyyy xxxx xxxxx
        #  t1 = now()
        for b in (160, 80, 40, 20, 15, 10, 6, 2, 220, 440, 900, 1200, 'Sat'):
            print("%6s" % b, end=' ')
            for m3 in 'cdp':
                bm1 = "%s%s" % (b, m3)
                t2 = tmlq.get(bm1, '')  # time since last Q minutes
                # if t2 == '':
                #     tdif = ''
                # else:
                #     tdif = int(tmsub(t1, t2) / 60.)
                #     tmin = tdif % 60
                #     tdhr = tdif / 60
                #     if tdhr > 99: tdhr = 99
                #     tdif = tdhr * 100 + tmin
                #    if tdif > 9999: tdif = 9999
                #    tdif = str(int(tdif))           # be nice to make this hhmm instead of mmmm
                #  t = "" # time of latest Q hhmm
                #  m = re.search(r"(\d{4})\d{2}$",tmlq.get(bm,''))
                #  if m: t = m.group(1)
                nob = net.si.nod_on_band(bm1)  # node now on band
                # This will print the node on the current band
                if len(nob) == 0:
                    nob = ''  # list take first item if any
                else:
                    nob = nob[0]
                print("%6s %4s %5s" %
                      (nob[0:6], qpb.get(bm1, ''), t2), end=' ')  # was t
                #    (nod.get(bm,'')[0:5],qpb.get(bm,''),t),
            print()

    def sfx2call(self, suffix1, band1):
        """return calls w suffix on this band"""
        return self.bysfx.get(suffix1 + '.' + band1, [])

    def pfx2call(self, prefix1):
        """return dict of {band: [calls]} matching prefix across all bands"""
        results = {}
        for key, calls in self.bysfx.items():
            # key format is "suffix.band"
            dot = key.rfind('.')
            if dot < 0:
                continue
            bnd = key[dot + 1:]
            for c in calls:
                if c.startswith(prefix1):
                    results.setdefault(bnd, []).append(c)
        return results

    @staticmethod
    def qparse(line):
        """"qso/call/partial parser"""
        # check for valid input at each keystroke
        # return status, time, extended call, base call, suffix, report
        # stat: 0 invalid, 1 partial, 2 suffix, 3 prefix, 4 call, 5 full qso
        # example --> :12.3456 wb4ghj/ve7 2a sf Steve in CAN
        global stat
        stat, tm, pfx, sfx, call7, xcall, rept = 0, '', '', '', '', '', ''
        # break into basic parts: time, call, report
        m4 = re.match(r'(:([\d.]*)( )?)?(([a-z\d/]+)( )?)?([\da-zA-Z ]*)$', line)
        if m4:
            tm = m4.group(2)
            xcall = m4.group(5)
            rept = m4.group(7)
            stat = 0
            if m4.group(1) is not None or xcall is not None:
                stat = 1
            #            print; print "tm [%s] xcall [%s] rept [%s]"%(tm,xcall,rept)
            if tm is not None:
                stat = 0
                m4 = re.match(r'([0-3](\d([.]([0-5](\d([0-5](\d)?)?)?)?)?)?)?$', tm)
                if m4:
                    stat = 1  # at least partial time
            if xcall is not None:
                stat = 0  # invalid unless something matches
                # Handle slash notation for portable/international operations
                basecall = xcall
                if '/' in xcall:
                    basecall = xcall[:xcall.index('/')]

                if basecall:
                    has_digit = any(ch.isdigit() for ch in basecall)
                    has_letter = any(ch.isalpha() for ch in basecall)

                    if not has_digit:
                        # Only letters - it's a suffix
                        stat = 2
                        sfx = basecall
                    elif not has_letter:
                        # Only digits - treat as partial suffix
                        stat = 2
                        sfx = basecall
                    else:
                        # Use CallSignParser for prefix/suffix splitting
                        try:
                            prefix, separator, suffix = CallSignParser.parse_callsign(basecall)
                            # Combine prefix and separator to match existing format
                            pfx = prefix + separator
                            sfx = suffix

                            if sfx and pfx:
                                stat = 4  # complete call
                                call7 = basecall
                            elif pfx and not sfx:
                                stat = 3  # prefix only (ends with digit)
                        except (InvalidCallSignError, CallSignParserError, IndexError):
                            # Fallback to partial status if parsing fails
                            stat = 1

                if (stat == 4) & (rept > ""):
                    stat = 0
                    m4 = re.match(r'[\da-zA-Z]+[\da-zA-Z ]*$', rept)
                    if m4:
                        stat = 5  # complete qso
                if len(xcall) > 12:
                    stat = 0  # limit lengths
                if len(pfx) > 6:
                    stat = 0
                if len(sfx) > 4:
                    stat = 0
                if tm:  # if forced time exists
                    if len(tm) < 7:  # it must be complete
                        stat = 0
                        #        print "stat[%s] time[%s] pfx[%s] sfx[%s] call[%s] xcall[%s] rpt[%s]"%\
                        #              (stat,tm,pfx,sfx,call,xcall,rept)
        return stat, tm, pfx, sfx, call7, xcall, rept

    @staticmethod
    def get_callsign_country(callsign):
        """Return country for a callsign using cty.dat database.

        Args:
            callsign: The callsign to look up (can include portable suffix like W1ABC/4)

        Returns:
            str: Country name or None if not found/invalid
        """
        try:
            # Handle slash notation - use base callsign for lookup
            basecall = callsign
            if '/' in callsign:
                basecall = callsign[:callsign.index('/')]

            prefix, separator, suffix, country, is_valid = CallSignParser.parse(basecall)
            return country if is_valid else None
        except (InvalidCallSignError, CallSignParserError):
            return None

    def dupck(self, wcall, band2):
        """check for duplicate call on this band"""
        dummy, dummy, dummy, sfx, call8, xcall, dummy = self.qparse(wcall)
        if gd.getv('contst').upper() == "VHF":
            return xcall in self.sfx2call(sfx, band2)  # vhf contest
        return call8 in self.sfx2call(sfx, band2)  # field day

    def partck(self, wcall):
        """ check for participants to act as dupes in this event"""
        # Added function to test against participants like dupes Scott Hibbs KD4SIR Jan/29/2017
        # Added function to test against call and gota call like dupes Scott Hibbs KD4SIR Mar/23/2017
        dummy, dummy, dummy, dummy, call9, xcall, dummy = self.qparse(wcall)
        somelocallist6 = []
        for i12 in list(participants.values()):
            somelocallist6.append(i12)
            dummy, dummy, dcall, dummy, dummy = str.split(i12, ', ')
            if dcall == xcall:
                # to debug: print("%s dcall matches %s xcall" % (dcall, xcall))
                if gd.getv('contst').upper() == "VHF":
                    return xcall  # vhf contest
                return call9  # field day
            if dcall == call9:
                # to debug: print("%s dcall matches %s call" % (dcall, call))
                if gd.getv('contst').upper() == "VHF":
                    return xcall  # vhf contest
                return call9  # field day
        return None

    def logdup(self):
        """enter into dup log"""
        dummy, dummy, dummy, sfx, dummy, xcall, dummy = self.qparse(self.call)
        #        print call,sfx,self.band
        key = sfx + '.' + self.band
        self.lock.acquire()
        if self.rept[:5] == "*del:":
            self.redup()
        else:
            # duplog everything with nonzero power, or on band off (test)
            if (self.band == 'off') | (ival(self.powr) > 0):
                # dup only if Q and node type match (gota/not)
                if (node == 'gotanode') == (self.src == 'gotanode'):
                    if key in self.bysfx:  # add to suffix db
                        self.bysfx[key].append(xcall)
                    else:
                        self.bysfx[key] = [xcall]
                        #                else: print "node type mismatch",node,self.src
        self.lock.release()

    def redup(self):
        """rebuild dup db"""
        dummy, c2, g4 = self.cleanlog()
        self.lock.acquire()
        #        print self.bysfx
        QsoDb.bysfx = {}
        for i13 in list(c2.values()) + list(g4.values()):
            #            print i.call,i.band
            i13.logdup()
        self.lock.release()
        #        print qsodb.bysfx

    def was_log_report(self):
        """Generate a report on worked states."""
        sectost, stcnt, r, ee = {}, {}, [], []

        # Read section data
        try:
            with open("Arrl_sections_ref.txt", "r") as fd:
                for ln in fd:
                    if ln.startswith('#'):
                        continue
                    try:
                        sec, st, *_ = ln.split(" ", 3)
                        sectost[sec] = st
                        stcnt[st] = 0
                    except ValueError as ee:
                        print("Error reading section data:", ee)
        except IOError as ee:
            print("Error loading section data file:", ee)

        # Clean log
        a, _, _ = self.cleanlog()
        for ii in a.values():
            sect, state = "", ""
            if ii.rept[:1] == '*' or ii.band[0] == '*' or ii.band == 'off' or ii.powr == '0':
                continue
            m2 = re.match(r' *\d+[a-fiohA-FIOH] +([A-Za-z]{2,4})', ii.rept)
            if m2:
                sect = str.upper(m2.group(1))
                state = sectost.get(sect, "")
                if state:
                    stcnt[state] += 1
            if not state:
                ee.append(ii.prlogln(ii))

        # Generate report
        h = [ii for ii in stcnt.keys() if ii != "--" and stcnt[ii] != 0]
        n = [ii for ii in stcnt.keys() if ii != "--" and stcnt[ii] == 0]
        n.sort()
        h.sort()
        r.append("Worked All States Report\n%s Warning(s) Below\nNeed %s States:" % (len(ee), len(n)))
        r.extend(n)
        r.append("\nHave %s States:" % len(h))
        r.extend("%s %s" % (ii, stcnt[ii]) for ii in h)
        if len(ee) > 0:
            r.append("\nWarnings - Cannot Discern US Section in Q(s):\n")
            r.extend(ee)
        # print(r)
        return r

    def get_have_states(self):
        """Extract and return the 'have' states from the report."""
        report = self.was_log_report()
        have_states = []
        # Find the index of the element that starts with "\nHave"
        start_index = None
        end_index = len(report)
        for idx, line in enumerate(report):
            if line.startswith("\nHave"):
                start_index = idx + 1
            elif line.startswith("\nWarnings"):
                end_index = idx
                break
        if start_index is None:
            return have_states  # No states found
        for line in report[start_index:end_index]:
            if line.startswith("--"):
                continue
            state_info = line.split()
            if state_info:
                state = state_info[0]  # State abbreviation is first element
                have_states.append(state)
        return have_states

    # Example usage:
    # have_states = get_have_states(r)
    #     # print(have_states)

    def was_sections_report(self):
        """Generate a report on worked ARRL/RAC sections."""
        sectcnt, r, ee = {}, [], []
        all_sections = []

        # Read section data
        try:
            with open("Arrl_sections_ref.txt", "r") as fd:
                for ln in fd:
                    if ln.startswith('#'):
                        continue
                    try:
                        sec, st, area, *_rest = ln.split(" ", 3)
                        all_sections.append(sec)
                        sectcnt[sec] = 0
                    except ValueError as ee:
                        print("Error reading section data:", ee)
        except IOError as ee:
            print("Error loading section data file:", ee)

        # Clean log
        a, _, _ = self.cleanlog()
        for ii in a.values():
            if ii.rept[:1] == '*' or ii.band[0] == '*' or ii.band == 'off' or ii.powr == '0':
                continue
            m2 = re.match(r' *\d+[a-fiohA-FIOH] +([A-Za-z]{2,4})', ii.rept)
            if m2:
                sect = str.upper(m2.group(1))
                if sect in sectcnt:
                    sectcnt[sect] += 1
                else:
                    ee.append(ii.prlogln(ii))
            else:
                ee.append(ii.prlogln(ii))

        # Generate report
        h = [ii for ii in sectcnt.keys() if sectcnt[ii] != 0]
        n = [ii for ii in sectcnt.keys() if sectcnt[ii] == 0]
        n.sort()
        h.sort()
        r.append("Worked All Sections Report\n%s Warning(s) Below\nNeed %s Sections:" % (len(ee), len(n)))
        r.extend(n)
        r.append("\nHave %s Sections:" % len(h))
        r.extend("%s %s" % (ii, sectcnt[ii]) for ii in h)
        if len(ee) > 0:
            r.append("\nWarnings - Cannot Discern Section in Q(s):\n")
            r.extend(ee)
        # print(r)
        return r

    def get_have_sections(self):
        """Extract and return the 'have' sections from the report."""
        report = self.was_sections_report()
        have_sections = []
        # Find the index of the element that starts with "\nHave"
        start_index = None
        end_index = len(report)
        for idx, line in enumerate(report):
            if line.startswith("\nHave"):
                start_index = idx + 1
            elif line.startswith("\nWarnings"):
                end_index = idx
                break
        if start_index is None:
            return have_sections  # No sections found
        for line in report[start_index:end_index]:
            section_info = line.split()
            if section_info:
                section = section_info[0]  # Section abbreviation is first element
                have_sections.append(section)
        return have_sections

    def vhf_cabrillo(self):
        """output VHF contest cabrillo QSO data"""
        band_map = {'6': '50', '2': '144', '220': '222', '440': '432', '900': '902', '1200': '1.2G'}
        dummy, n, dummy = self.cleanlog()
        mycall = str.upper(gd.getv('fdcall'))
        mygrid = gd.getv('grid')
        lllist = []
        print("QSO: freq  mo date       time call              grid   call              grid ")
        for iiii in list(n.values()):  # + g.values(): no gota in vhf
            freq = "%s" % iiii.band[:-1]  # band
            if freq in band_map:
                freq = band_map[freq]
            mod = iiii.band[-1:]  # mode
            if mod == "c":
                mod = "CW"
            if mod == "p":
                mod = "PH"
            if mod == "d":
                mod = "RY"
            date = "20%2s-%2s-%2s" % (iiii.date[0:2], iiii.date[2:4], iiii.date[4:6])
            tim = iiii.date[7:11]
            call2 = iiii.call
            grid = ''
            if '/' in call2:  # split off grid from call
                call2, grid = call2.split('/')
            lllist.append("%sQSO: %-5s %-2s %-10s %4s %-13s     %-6s %-13s     %-6s" % (
                iiii.date, freq, mod, date, tim, mycall, mygrid, call2, grid))
        lllist.sort()  # sort data with prepended date.time
        for iiii in lllist:
            print(iiii[13:])  # rm sort key date.time

    def winter_fd(self):
        # added support for winter field day, this outputs the cabrillo format that is posted on their
        # website. -Art Miller KC7SDA 2019
        """output Winter Field day QSO data in cabrillo format:"""
        # vars:
        #  band_map = {'160': '1800', '80': '3500', '40': '7000', '20': '14000', '15': '21000', '10':
        #              '28000', '6': '50', '2': '144', '220': '222', '440': '432', '900': '902', '1200': '1.2G'}
        dummy, n, dummy = self.cleanlog()
        somelocallist = []
        mycall = str.upper(gd.getv('fdcall'))
        mycat = gd.getv('class')
        mystate, mysect = gd.getv('sect').split("-")
        # number of tx
        txnum = mycat[:-1]
        # data crunching:
        # QSO log generation:
        for i5 in list(n.values()):
            freq = "%s" % i5.band[:-1]  # band
            # if freq in band_map: freq = band_map[freq]
            mod = i5.band[-1:]  # mode
            if mod == "c":
                mod = "CW"
            if mod == "p":
                mod = "PH"
            if mod == "d":
                mod = "DI"  # per 2019 rules
            date = "20%2s-%2s-%2s" % (i5.date[0:2], i5.date[2:4], i5.date[4:6])
            # date = "%2s-%2s-20%2s" % (i.date[2:4], i.date[4:6], i.date[0:2])
            tim = i5.date[7:11]
            call2 = i5.call
            cat, sect = i5.rept.split(" ")
            if '/' in call2:  # split off grid from call
                call2, grid = call2.split('/')
            # cabrillo example: QSO:  40 DI 2019-01-19 1641 KC7SDA        1H  WWA    KZ9ZZZ        1H  NFL
            somelocallist.append("%sQSO:  %-5s %-2s %-10s %4s %-10s %-2s  %-5s %-10s %-2s  %-5s" % (
                i5.date, freq, mod, date, tim, mycall, mycat, mysect, call2, cat, sect))
        somelocallist.sort()  # sort data with prepended date.time
        # check operator (single or multi op):
        #  cat_op = ""
        if len(participants) > 1:
            cat_op = "MULTI-OP"
        else:
            cat_op = "SINGLE-OP"
        # check fixed or portable?
        # tx power:
        # calls for ops:
        ops_calls_list = []
        # print(participants)
        # participants: {u'am': u'am, art miller, kc7sda, 37, '}
        for i5 in list(participants.values()):
            dummy, dummy, cs, dummy, dummy = i5.split(", ")
            ops_calls_list.append(str.upper(cs))
        ops_calls = ', '.join(ops_calls_list)
        # output
        print("Winter field day Cabrillo output")
        print("START-OF-LOG: 3.0")
        print("Created-By: FDLog_Enhanced (https://github.com/scotthibbs/FDLog_Enhanced)")
        print("CONTEST: WFD ")
        print("CALLSIGN: " + mycall)
        print("LOCATION: " + mystate)
        print("ARRL-SECTION: " + mysect)
        print("CATEGORY-OPERATOR: " + cat_op)
        print("CATEGORY-STATION: ")  # fixed or portable
        print("CATEGORY_TRANSMITTER: " + txnum)  # how many transmitters
        print("CATEGORY_POWER: LOW")  # qrp low or high
        print("CATEGORY_ASSISTED: NON-ASSISTED")  # assisted or non-assisted
        print("CATEGORY-BAND: ALL")  # leave for wfd
        print("CATEGORY-MODE: MIXED")  # leave for wfd
        print("CATEGORY-OVERLAY: OVER-50")  # leave for wfd
        print("SOAPBOX: ")  # fill in?
        print("CLAIMED-SCORE: ")  # figure out score and add
        print("OPERATORS: " + ops_calls)  # agregate the ops
        print("NAME: " + gd.getv('fmname'))
        print("ADDRESS: " + gd.getv('fmad1'))
        print("ADDRESS-CITY: " + gd.getv('fmcity'))
        print("ADDRESS-STATE: " + gd.getv('fmst'))
        print("ADDRES-POSTALCODE: " + gd.getv('fmzip'))  # zip
        print("ADDRESS-COUNTRY: USA")  # hard coded for now, possibly change later
        print("EMAIL: " + gd.getv('fmem'))  # email address
        # print log:
        for i5 in somelocallist:
            print(i5[13:])  # rm sort key date.time
        print("END-OF-LOG:")


def logwredraw():
    """redraw the logw window with only valid log entries"""
    # Added by Scott Hibbs KD4SIR 31Jul2022
    global node
    a, dummy, dummy = qdb.cleanlog()
    logw.config(state="normal", font=fdfont)
    logw.delete(0.1, END)
    logw.insert(END, "\n")
    logw.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", "b")
    logw.insert(END, "                            DATABASE DISPLAY WINDOW\n", "b")
    logw.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", "b")
    logw.insert(END, "%s\n" % prog, "b")
    # i32.prlogln(i32) gives the line of the log output.
    for i32 in list(a.values()):
        if node in i32.prlogln(i32):
            logw.insert(END, i32.prlogln(i32), "b")
            logw.insert(END, "\n")
        else:
            logw.insert(END, i32.prlogln(i32))
            logw.insert(END, "\n")
    logw.see(END)
    logw.config(state="disabled")

# def logwredrawminus():
#     """redraw the logw window with only valid log entries minus QSTs"""
#     # Added by Scott Hibbs KD4SIR 31Jul2022
#     global node
#     a, dummy, dummy = qdb.cleanlog()
#     logw.config(state="normal")
#     logw.delete(0.1, END)
#     logw.insert(END, "\n")
#     # i32.prlogln(i32) gives the line of the log output.
#     for i32 in list(a.values()):
#         if node in i32.prlogln(i32):
#             logw.insert(END, i32.prlogln(i32), "b")
#             logw.insert(END, "\n")
#         else:
#             logw.insert(END, i32.prlogln(i32))
#             logw.insert(END, "\n")
#     logw.config(state="disabled")
#     logw.see(END)


class NodeInfoClass:
    """Threads and networking section"""
    nodes = {}
    nodinfo = {}
    # rembcast = {}
    #  This was not remarked out of the 2015_stable version
    #  Scott Hibbs 7/3/2015
    lock = threading.RLock()  # reentrant sharing lock

    def __init__(self):
        self.age = None
        self.msc = None
        self.bnd = None
        self.nod = None
        self.gps_locked = False
        self.ntp_ok = False

    @staticmethod
    def sqd(src, seq, t, b, c3, rp, p1, o, logr1):
        """process qso data from net into db"""
        s = qdb.new(src)
        s.seq, s.date, s.call, s.band, s.rept, s.oper, s.logr, s.powr = \
            seq, t, c3, b, rp, o, logr1, p1
        s.dispatch('net')
        # Check for network dupes after dispatch - Added Jan 2026
        qdb.check_network_dupe(src, seq, t, b, c3)

    @staticmethod
    def netnum(ip, mask):
        """extract net number"""
        i14, m6, r = [], [], {}
        i14 = str.split(ip, '.')
        m6 = str.split(mask, '.')
        for n in (0, 1, 2, 3):
            r[n] = ival(i14[n]) & ival(m6[n])
        return "%s.%s.%s.%s" % (r[0], r[1], r[2], r[3])

    def ssb(self, pkt_tm, host, sip, nod, stm, stml, ver, td, gps_locked='0', ntp_ok='0'):
        """process status broadcast (first line)"""
        self.lock.acquire()
        if nod not in self.nodes:  # create if new
            self.nodes[nod] = NodeInfoClass()
            if nod != node:
                print("New Node Heard", host, sip, nod, stm, stml, ver, td)
        i15 = self.nodes[nod]
        #        if debug: print "ssb before assign",i.nod,i.stm,i.bnd
        i15.ptm, i15.nod, i15.host, i15.ip, i15.stm, i15.age = pkt_tm, nod, host, sip, stm, 0
        i15.gps_locked = (gps_locked == '1')
        i15.ntp_ok = (ntp_ok == '1')
        self.lock.release()
        #   if debug:
        #  print "ssb:",pkt_tm,host,sip,nod,stm,stml,ver,td

    def sss(self, pkt_tm, fnod, sip, nod, seq, bnd, msc, age2):
        """process node status bcast (rest of bcast lines)"""
        self.lock.acquire()
        key = "%s-%s" % (fnod, nod)
        if key not in self.nodinfo:
            self.nodinfo[key] = NodeInfoClass()  # create new
            #  if debug: print "sss: new nodinfo instance",key
        i16 = self.nodinfo[key]
        i16.tm, i16.fnod, i16.fip, i16.nod, i16.seq, i16.bnd, i16.msc, i16.age = \
            pkt_tm, fnod, sip, nod, seq, bnd, msc, int(age2)
        self.lock.release()
        #        if debug: print "sss:",i.age,i.nod,i.seq,i.bnd

    def age_data(self):
        """increment age and delete old band"""
        # updates from 152i
        t = now()[7:]  # time hhmmss
        self.lock.acquire()
        for i17 in list(self.nodinfo.values()):
            if i17.age < 999:
                i17.age += 1
                # if debug: print "aging nodinfo",i.fnod,i.nod,i.bnd,i.age
            if i17.age > 55 and i17.bnd:
                print(t, "age out info from", i17.fnod, "about", i17.nod, "on", i17.bnd, "age", i17.age)
                i17.bnd = ""
                if i17.fnod in operatorsonline:
                    operatorsonline.pop(i17.fnod)
        for i17 in list(self.nodes.values()):
            if i17.age < 999:
                i17.age += 1
        self.lock.release()

    def fill_requests_list(self):
        """return list of fills needed"""
        r = []
        self.lock.acquire()
        for i18 in list(self.nodinfo.values()):  # for each node
            j1 = qdb.hiseq.get(i18.nod, 0)
            if int(i18.seq) > j1:  # if they have something we need
                r.append((i18.fip, i18.nod, j1 + 1))  # add req for next to list
                # if debug: print "req fm",i.fip,"for",i.nod,i.seq,"have",j+1
        self.lock.release()
        return r  # list of (addr,src,seq)

    def node_status_list(self):
        """return list of node status tuples"""
        summ1 = {}  # summary dictionary
        self.lock.acquire()
        i19 = NodeInfoClass()  # update our info
        i19.nod, i19.bnd, i19.age = node, band, 0
        i19.msc = "%s %s %sW" % (exin(operator), exin(logger), power)
        summ1[node] = i19
        for i19 in list(qdb.hiseq.keys()):  # insure all db nod on list
            if i19 not in summ1:  # add if new
                j2 = NodeInfoClass()
                j2.nod, j2.bnd, j2.msc, j2.age = i19, '', '', 999
                summ1[i19] = j2
                # if debug: print "adding nod fm db to list",i
        for i19 in list(self.nodinfo.values()):  # browse bcast data
            if i19.nod not in summ1: 
                j2 = NodeInfoClass()
                j2.nod, j2.bnd, j2.msc, j2.age = i19.nod, '', '', 999
                summ1[i19.nod] = j2
            j2 = summ1[i19.nod]  # collect into summary
            #            if debug:
            #                print "have",      j.nod,j.age,j.bnd,j.msc
            #                print "inspecting",i.nod,i.age,i.bnd,i.msc
            if i19.age < j2.age:  # keep latest wrt src time
                #                if debug:
                #                    print "updating",j.nod,j.age,j.bnd,j.msc,\
                #                                "to",      i.age,i.bnd,i.msc
                j2.bnd, j2.msc, j2.age = i19.bnd, i19.msc, i19.age
        self.lock.release()
        r = []  # form the list (xx return sum?)
        for s in list(summ1.values()):
            seq = qdb.hiseq.get(s.nod, 0)  # reflect what we have in our db
            if seq or s.bnd:  # only report interesting info
                r.append((s.nod, seq, s.bnd, s.msc, s.age))
        return r  # list of (nod,seq,bnd,msc,age)

    def nod_on_band(self, band3):
        """return list of nodes on this band"""
        r = []
        for s in self.node_status_list():
            # print("s1:", s[1], "s3:", s[3])  # (nod,seq,bnd,msc,age)
            if band3 == s[2]:
                r.append(s[0])
        return r

    def nod_on_bands(self):
        """return dictionary of list of nodes indexed by band and counts"""
        r, hf, vhf, gotanode = {}, 0, 0, 0
        for s in self.node_status_list():
            #            print s[0],s[2]
            # if not r.has_key(s[2]): # has_key deprecated here
            if not s[2] in r:
                r[s[2]] = []
            r[s[2]].append(s[0])
            if s[2] == 'off' or s[2] == "":
                continue
            if s[0] == 'gotanode':
                gotanode += 1
            else:
                b = ival(s[2])
                if b > 8 or b < 200:
                    hf += 1
                if b < 8 or b > 200:
                    vhf += 1
        return r, hf, vhf, gotanode


class NetworkSync:
    """network database synchronization"""

    def __init__(self):
        self.skt = None
        self.port = None

    # netmask = '255.255.255.0' not used - Art Miller KC7SDA Jul/01/2018
    rem_adr = ""  # remote bc address
    authkey = hashlib.md5()
    pkts_rcvd, fills, badauth_rcvd, send_errs = 0, 0, 0, 0
    hostname = socket.gethostname()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 53))
        s.settimeout(20)  # set timeout to 20 seconds instead of the default minute and a half. - Scott 12Jul2022
        my_addr = s.getsockname()[0]
    except socket.error as exc:
        print("Caught exception socket.error : %s" % exc)
        my_addr = "127.0.0.1"
    finally:
        s.close()
    print("\n IP address is:  %s\n" % my_addr)
    bc_addr = re.sub(r'\d+$', '255', my_addr)  # calc bcast addr
    si = NodeInfoClass()  # node info

    def setport(self, useport):
        """set net port"""
        self.port = useport
        self.skt = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # send socket
        self.skt.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)  # Eric's Linux fix - Eric WD6CMU
        self.skt.bind((self.my_addr, self.port + 1))

    def setauth(self, newauth):
        """set authentication key code base, copy on use"""
        global authk
        authk = newauth
        seed = "2023113011111sah"  # change when protocol changes
        # changed seed when added 'u' bcast - 30Nov2023
        # self.authkey = md5.new(newauth+seed)
        newauthseed = newauth + seed
        newauthseed = newauthseed.encode()
        self.authkey = hashlib.md5(newauthseed)

    def auth(self, msg):
        """calc authentication hash"""
        h = self.authkey.copy()
        msg = msg.encode()
        h.update(msg)
        return h.hexdigest()

    def ckauth(self, msg):
        """check authentication hash"""
        h, m7 = msg.split('\n', 1)
        #        print h; print self.auth(m); print
        return h == self.auth(m7)

    def sndmsg(self, msg, addr):
        """send message to address list"""
        if authk != "" and node != "":
            amsg = self.auth(msg) + '\n' + msg
            amsg = amsg.encode()
            addrlst = []
            if addr == 'bcast':
                addrlst.append(self.bc_addr)
            else:
                addrlst.append(addr)
            for a in addrlst:
                if a == "":
                    continue
                if a == '0.0.0.0':
                    continue
                if debug:
                    print("send to ", a)
                    print(msg)
                try:
                    self.skt.sendto(amsg, (a, self.port))
                except socket.error as e01:
                    self.send_errs += 1
                    print("error, pkt xmt failed %s %s [%s]" % (now(), e01.args, a))

    def send_qsomsg(self, nod, seq, destip):
        """send q record"""
        key = nod + '.' + str(seq)
        if key in qdb.byid:
            i20 = qdb.byid[key]
            msg = "q|%s|%s|%s|%s|%s|%s|%s|%s|%s\n" % \
                  (i20.src, i20.seq, i20.date, i20.band, i20.call, i20.rept, i20.powr, i20.oper, i20.logr)
            self.sndmsg(msg, destip)

    def bc_qsomsg(self, nod, seq):
        """broadcast new q record"""
        self.send_qsomsg(nod, seq, self.bc_addr)

    def bcast_now(self):
        gps_flag = '1' if mclock.gps_locked else '0'
        ntp_flag = '1' if mclock.ntp_ok else '0'
        msg = "b|%s|%s|%s|%s|%s|%s|%s|%s\n" % \
              (self.hostname, self.my_addr, node, now(), mclock.level, version, gps_flag, ntp_flag)
        for i21 in self.si.node_status_list():
            msg += "s|%s|%s|%s|%s|%s\n" % i21  # nod,seq,bnd,msc,age
            # if debug: print i
        self.sndmsg(msg, 'bcast')  # broadcast it

    def bc_user(self, where, whoops, whologs, whatband):
        """ This sends out the operator and the logger to everyone"""
        msg = "u|%s|%s|%s|%s\n" % (where, whoops, whologs, whatband)
        self.sndmsg(msg, 'bcast')  # broadcast it

    def fillr(self):
        """filler thread requests missing database records"""
        time.sleep(0.2)
        if debug:
            print("filler thread starting")
        while 1:
            time.sleep(.1)  # periodically check for fills
            if debug:
                time.sleep(1)  # slow for debug
            r = self.si.fill_requests_list()
            self.fills = len(r)
            if self.fills:
                p2 = random.randrange(0, len(r))  # randomly select one
                c4 = r[p2]
                msg = "r|%s|%s|%s\n" % (self.my_addr, c4[1], c4[2])  # (addr,src,seq)
                self.sndmsg(msg, c4[0])
                print("req fill", c4)

    def rcvr(self):
        """receiver thread processes incoming packets"""
        buffer_size = 800  # size of udp packets to be received

        if debug:
            print("receiver thread starting")
        r = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        r.bind(('', self.port))
        while 1:
            msg, addr = r.recvfrom(buffer_size)

            #  curious about udp packet size?  Most are less than 200 bytes
            # msg_size = len(msg)  # Measure the size of the received packet
            # print(f"Received packet from {addr}, size: {msg_size} bytes")

            msg = msg.decode()
            if addr[0] != self.my_addr:
                self.pkts_rcvd += 1
            # if authk == "": continue             # skip till auth set
            pkt_tm = now()
            host, sip, fnod, stm = '', '', '', ''
            if debug:
                print("rcvr: %s: %s" % (addr, msg),)  # xx
            if not self.ckauth(msg):  # authenticate packet
                # if debug: sms.prmsg("bad auth from: %s" %addr)
                print("bad auth from:", addr)
                self.badauth_rcvd += 1
            else:
                lines = msg.split('\n')  # decode lines
                for line in lines[1:-1]:  # skip auth hash, blank at end
                    #                    if debug: sms.prmsg(line)
                    fields = line.split('|')
                    if fields[0] == 'b':  # status bcast
                        # Parse with backwards compatibility for older nodes
                        if len(fields) >= 9:
                            host, sip, fnod, stm, stml, ver, gps_flag, ntp_flag = fields[1:9]
                        else:
                            host, sip, fnod, stm, stml, ver = fields[1:7]
                            gps_flag, ntp_flag = '0', '0'
                        td = tmsub(stm, pkt_tm)
                        self.si.ssb(pkt_tm, host, sip, fnod, stm, stml, ver, td, gps_flag, ntp_flag)
                        mclock.calib(fnod, stml, td)
                        if abs(td) >= tdwin:
                            print('Incoming packet clock error', td, host, sip, fnod, pkt_tm)
                        if showbc:  # this is around line 4380 to turn on/off.
                            print("bcast received", host, sip, fnod, ver, pkt_tm, td)
                    elif fields[0] == 's':  # source status
                        nod, seq, bnd, msc, age3 = fields[1:]
                        # if debug: print pkt_tm,fnod,sip,stm,nod,seq,bnd,msc
                        self.si.sss(pkt_tm, fnod, sip, nod, seq, bnd, msc, age3)
                    elif fields[0] == 'r':  # fill request
                        destip, src, seq = fields[1:]
                        # if debug: print destip,src,seq
                        self.send_qsomsg(src, seq, destip)
                    elif fields[0] == 'q':  # qso data
                        src, seq, stm, b, c5, rp, p3, o, l01 = fields[1:]
                        # if debug: print src,seq,stm,b,c,rp,p,o,l
                        self.si.sqd(src, seq, stm, b, c5, rp, p3, o, l01)
                    # Added user broadcast to see who is where - 30Nov2023 KD4SIR Scott Hibbs
                    elif fields[0] == 'u':  # User data - who is op and logger where.
                        where, whoops, whologs, whatband = fields[1:]
                        whoops = exin(whoops)
                        operatorsonline.update({where: whoops})
                        buildmenus()
                    else:
                        sms.prmsg("msg not recognized %s" % addr)

    def start(self):
        """launch all threads"""
        #        global node
        print("This host:", self.hostname, "IP:", self.my_addr, "Mask:", self.bc_addr)
        #        if (self.hostname > "") & (node == 's'):
        #            node = self.hostname             # should filter chars
        #        print "Node ID:",node
        print("Launching threads")
        #        thread.start_new_thread(self.bcastr,())
        _thread.start_new_thread(self.fillr, ())
        _thread.start_new_thread(self.rcvr, ())
        if debug:
            print("threads launched")
        time.sleep(0.5)  # let em print
        print("Startup complete")


class GlobalDataClass:
    """Global data stored in the journal"""

    def __init__(self):
        pass

    byname = {}

    def new(self, name2, desc1, defaultvalue, okgrammar, maxlen1):
        i22 = GlobalDataClass()  # create
        i22.name = name2  # set
        i22.val = defaultvalue
        i22.okg = okgrammar
        i22.maxl = maxlen1
        i22.ts = ""
        i22.desc = desc1
        self.byname[name2] = i22
        return i22

    def setv(self, name3, value, timestamp):
        """Sets the global data """
        # name3 = call, value = rept, timestamp is just that.
        if node == "":
            txtbillb.insert(END, "error - no node id\n")
            return "error - no node id"
        if name3[:2] == 'p:':  # set oper/logr
            i23 = self.byname.get(name3, self.new(name3, '', '', '', 0))
        else:
            if name3 not in self.byname:  # new
                return "error - invalid global data name: %s" % name3
            i23 = self.byname[name3]
            if len(value) > i23.maxl:  # too long
                return "error - value too long: %s = %s" % (name3, value)
            if name3 == 'grid':
                value = value.upper()  # added to properly format grid (ie CN88 not cn88) - Art Miller KC7SDA 2019
            if not re.match(i23.okg, value):  # bad grammar
                return "set error - invalid value: %s = %s" % (name3, value)
        if timestamp > i23.ts:  # timestamp later?
            i23.val = value
            # print("this is the value: %s" % value)
            i23.ts = timestamp
            if name3[:2] == 'p:':
                if "*del" in value:
                    initchachacha = name3[2:]
                    del (participants[initchachacha])
                else:
                    ini, name3, dummy, dummy, dummy = str.split(value, ', ')
                    participants[ini] = value
                    # if name3 == 'deleteq':
                    #     del (participants[ini])
                buildmenus()
        return None

    def getv(self, name4):
        if name4 not in self.byname:  # new
            return "get error - global data name %s not valid" % name4
        return self.byname[name4].val

    def sethelp(self):
        lhelp = ["   Set Commands\n   For the Logging Guru In Charge\n   eg: .set <parameter> <value>\n"]
        #  above is spaced for sort
        for i24 in list(self.byname.keys()):
            if i24[:2] != 'p:':  # skip ops in help display
                lhelp.append("  %-6s  %-43s  '%s'" % (i24, self.byname[i24].desc, self.byname[i24].val))
        lhelp.sort()
        viewtextl(lhelp)


class SynchMessage:
    """synchronous message displaying"""

    def __init__(self):
        pass

    lock = threading.RLock()
    msgs = []

    def prmsg(self, msg):
        """put message in queue for displaying log"""
        self.lock.acquire()
        self.msgs.append(msg)
        self.lock.release()

    def prout(self):
        """get message from queue for displaying log"""
        shonuff = ""
        self.lock.acquire()
        while self.msgs:
            # print(str(self.msgs))
            logw.config(state="normal")
            logw.see(END)
            nod = self.msgs[0][70:81]  # color local entries
            seq = self.msgs[0][65:69].strip()
            seq = int(seq)
            stn = self.msgs[0][69:].strip()
            rpod = self.msgs[0][27:31]  # looks for "*del" entries

            # Added ability to redraw the log window after receiving a *del message - Scott Hibbs KD4SIR 05Aug2022
            if rpod == "*del":  # redraw if del.
                shonuff = "yes"

            if nod == node:
                # Added a check to see if in the log to print blue or not - Scott Hibbs June 26, 2018
                bid, dummy, dummy = qdb.cleanlog()  # get a clean log
                stnseq = stn + "|" + str(seq)
                if stnseq in bid:
                    logw.insert(END, "%s\n" % self.msgs[0], "b")
            else:
                logw.insert(END, "%s\n" % self.msgs[0])
            logw.config(state="disabled")
            del self.msgs[0]
        self.lock.release()
        if shonuff == "yes":
            logwredraw()


def now():
    """return current time in standard str format"""
    # n = time.localtime(time.time())
    n = time.gmtime(time.time() + mclock.offset)  # time in gmt utc
    # offset to correct to master
    t = time.strftime("%y%m%d.%H%M%S", n)  # compact version YY
    return t


def tmtofl(a):
    """time to float in seconds, allow milliseconds"""
    # Reworked in 152i
    return time.mktime((2000 + int(a[0:2]), int(a[2:4]), int(a[4:6]),
                        int(a[7:9]), int(a[9:11]), int(a[11:13]), 0, 0, 0))
    # return calendar.timegm((2000 + int(a[0:2]), int(a[2:4]), int(a[4:6]),
    #                        int(a[7:9]), int(a[9:11]), float(a[11:]), 0, 0, 0))


def tmsub(a, b):
    """time subtract in seconds"""
    return tmtofl(a) - tmtofl(b)


class GlobalDb:
    """new sqlite globals database fdlog.sq3 replacing globals file"""

    def __init__(self):
        self.dbPath = globf[0:-4] + '.sq3'
        print("  Using local value database", self.dbPath)  # In Class init this prints twice
        self.sqdb = sqlite3.connect(self.dbPath, check_same_thread=False)  # connect to the database
        # Have to add FALSE here to get this stable. - Scott Hibbs 7/17/2015
        self.sqdb.row_factory = sqlite3.Row  # row factory
        self.curs = self.sqdb.cursor()  # make a database connection cursor
        sql = "create table if not exists global(nam text,val text,primary key(nam))"
        self.curs.execute(sql)
        self.sqdb.commit()
        self.cache = {}  # use a cache to reduce db i/o

    def get(self, name5, default1):
        if name5 in self.cache:
            # print "reading from globCache",name
            return self.cache[name5]
        sql = "select * from global where nam == ?"
        results = self.curs.execute(sql, (name5,))
        value = default1
        for result in results:
            value = result['val']
            # print "reading from globDb", name, value
            self.cache[name5] = value
        return value

    def put(self, name6, value):
        now1 = self.get(name6, 'zzzzz')
        # print now,str(value),now==str(value)
        if str(value) == now1:
            return  # skip write if same
        sql = "replace into global (nam,val) values (?,?)"
        self.curs.execute(sql, (name6, value))
        self.sqdb.commit()
        # print "writing to globDb", name, value
        self.cache[name6] = str(value)


def loadglob():
    """load persistent local config to global vars from file"""
    # updated from 152i
    global globDb, node, operator, logger, power, tdwin, debug, authk, kick
    node = globDb.get('node', '')
    operator = globDb.get('operator', '')
    logger = globDb.get('logger', '')
    power = globDb.get('power', '0')
    authk = globDb.get('authk', 'tst')
    tdwin = int(globDb.get('tdwin', 5))  # 152i changed from 10 to 5
    debug = int(globDb.get('debug', 0))
    kick = globDb.get('kick', "10")
    #  timeok = int(globDb.get('timeok', 0))
    NetworkSync.rem_host = globDb.get('remip', '0.0.0.0')
    if debug:
        print("  debug:", debug)


def saveglob():
    """save persistent local config global vars to file"""
    globDb.put('node', node)
    globDb.put('operator', operator)
    globDb.put('logger', logger)
    globDb.put('power', power)
    globDb.put('authk', authk)
    globDb.put('tdwin', tdwin)
    globDb.put('debug', debug)
    globDb.put('kick', kick)
    #  globDb.put('timeok', timeok)
    #    fd = file(globf,"w")
    #    fd.write("|%s|%s|%s|%s|%s|%s|%s|"%(node,operator,logger,power,\
    #                                       authk,tdwin,debug))
    #    fd.close()


def getfile(fn):
    """get file contents"""
    data = ""
    try:
        fd = open(fn, "r")
        data = fd.read()
        fd.close()
    except IOError:
        pass
    if data != "":
        print("Found file", fn)
        # print data
    return data


def contestlog(pr):
    """generate contest entry and log forms"""
    w1aw_msg = getfile("w1aw_msg.txt")  # W1AW bulletin copy
    # National Traffic System Messages
    nts_orig_msg = getfile("nts_msg.txt")  # status message
    nts_msg_relay = []
    for i25 in range(0, 10):  # relayed messages
        fn = "nts_rly%d.txt" % i25
        msg = getfile(fn)
        if msg != "":
            nts_msg_relay.append(msg)
    media_copy = getfile("media.txt")  # media activity
    soapbox = getfile("soapbox.txt")  # soapbox commentary
    fd_call = str.upper(gd.getv('fdcall'))  # prep data
    xmttrs = ival(gd.getv('class'))
    gota_call = str.upper(gd.getv('gcall'))
    if xmttrs < 2:
        gota_call = ""
    if pr == 0:
        return  # only define variables return
    # output the entry, adif & cabrillo log file
    datime = now()
    dummy, bycall, gotabycall = qdb.cleanlog()  # get a clean log
    qpb, ppb, qpop, qplg, qpst, dummy, dummy, maxp, cwq, digq, fonq, qpgop, gotaq, nat, sat = \
        qdb.band_rpt()  # and count it
    print("..", end=' ')
    sys.stdout = open(logfile, "w")  # redirect output to file
    print("Field Day 20%s Entry Form" % datime[:2])
    print()
    print("Date Prepared:              %s UTC" % datime[:-2])
    print()
    print("1.  Field Day Call:         %s" % fd_call)
    if gota_call != "":
        print("    GOTA Station Call:      %s" % gota_call)
    print("2.  Club or Group Name:     %s" % gd.getv('grpnam'))
    print("3.  Number of Participants: %s" % len(participants))
    print("4.  Transmitter Class:      %s" % xmttrs)
    print("5.  Entry Class:            %s" % str.upper(gd.getv('class'))[-1:])
    print()
    print("6.  Power Sources Used:")
    if int(gd.getv('psgen')) > 0:
        print("      Generator")
    if int(gd.getv('pscom')) > 0:
        print("      Commercial")
    if int(gd.getv('psbat')) > 0:
        print("      Battery")
    # add solar! xx
    if gd.getv('psoth') != '':
        print("      Other: %s" % (gd.getv('psoth')))
    print()
    print("7.  ARRL Section:           %s" % gd.getv('sect'))
    print()
    print("8.  Total CW QSOs:      %4s  Points: %5s" % (cwq, cwq * 2))
    print("9.  Total Digital QSOs: %4s  Points: %5s" % (digq, digq * 2))
    print("10. Total Phone QSOs:   %4s  Points: %5s" % (fonq, fonq))
    qsop = cwq * 2 + digq * 2 + fonq
    print("11. Total QSO Points:                 %5s" % qsop)
    print("12. Max Power Used:     %4s  Watts" % maxp)
    powm = 5
    if int(gd.getv('psgen')) > 0 or int(gd.getv('pscom')) > 0:
        powm = 2
    if maxp > 5:
        powm = 2
    if maxp > 150:
        powm = 1
    if maxp > 1500:
        powm = 0
    print("13. Power Multiplier:                  x %2s" % powm)
    qso_scor = qsop * powm
    print("14. Claimed QSO Score:                %5s" % qso_scor)
    print()
    print("15. Bonus Points:")
    tot_bonus = 0
    #  emerg_powr_bp = 0  # not used
    if gd.getv('pscom') == '0':
        emerg_powr_bp = 100 * xmttrs
        if emerg_powr_bp > 2000:
            emerg_powr_bp = 2000
        tot_bonus += emerg_powr_bp
        print("   %4s 100%s Emergency Power (%s xmttrs)" % (emerg_powr_bp, '%', xmttrs))
    #  media_pub_bp = 0  # not used
    if media_copy > "":
        media_pub_bp = 100
        tot_bonus += media_pub_bp
        print("    %3s Media Publicity (copy below)" % media_pub_bp)
    public_bp = 0
    public_place = gd.getv('public')
    if public_place != "":
        public_bp = 100
        tot_bonus += public_bp
        print("    %3s Set-up in a Public Place (%s)" % (public_bp, public_place))
    #  info_booth_bp = 0  # not used
    if int(gd.getv('infob')) > 0 and public_bp > 0:
        info_booth_bp = 100
        tot_bonus += info_booth_bp
        print("    %3s Information Booth (photo included)" % info_booth_bp)
    #  nts_orig_bp = 0  # not used
    if nts_orig_msg > "":
        nts_orig_bp = 100
        tot_bonus += nts_orig_bp
        print("    %3s NTS message Originated to ARRL SM/SEC (copy below)" % nts_orig_bp)
    n = len(nts_msg_relay)
    nts_msgs_bp = 10 * n
    if nts_msgs_bp > 100:
        nts_msgs_bp = 100
    if nts_msgs_bp > 0:
        tot_bonus += nts_msgs_bp
        print("    %3s Formal NTS messages handled (%s) (copy below)" % (nts_msgs_bp, n))
    sat_qsos = len(sat)
    #  sat_bp = 0  # not used
    if sat_qsos > 0:
        sat_bp = 100
        tot_bonus += sat_bp
        print("    %3s Satellite QSO Completed (%s/1) (list below)" % (sat_bp, sat_qsos))
    natural_q = len(nat)
    #  natural_bp = 0  # not used
    if natural_q >= 5:
        natural_bp = 100
        tot_bonus += natural_bp
        print("    %3s Five Alternate power QSOs completed (%s/5) (list below)" % (natural_bp, natural_q))
    #  w1aw_msg_bp = 0  # not used
    if len(w1aw_msg) > 30:  # ignore short file placeholder 152i
        w1aw_msg_bp = 100
        tot_bonus += w1aw_msg_bp
        print("    %3s W1AW FD Message Received (copy below)" % w1aw_msg_bp)
    #  site_visited_ego_bp = 0  # not used
    if gd.getv('svego') > "":
        site_visited_ego_bp = 100
        tot_bonus += site_visited_ego_bp
        print("    %3s Site Visited by elected govt officials (%s)" % (site_visited_ego_bp, gd.getv('svego')))
    #  site_visited_roa_bp = 0  # not used
    if gd.getv('svroa') > "":
        site_visited_roa_bp = 100
        tot_bonus += site_visited_roa_bp
        print("    %3s Site Visited by representative of agency (%s)" % (site_visited_roa_bp, gd.getv('svroa')))
    # GOTA Contacts Bonus - 5 points per GOTA QSO (up to 500 QSOs max)
    if gotaq > 0:
        gota_contact_bp = 5 * min(gotaq, 500)  # Cap at 500 GOTA QSOs
        tot_bonus += gota_contact_bp
        print("    %3s GOTA Contacts Bonus (%s QSOs x 5 pts)" % (gota_contact_bp, min(gotaq, 500)))
    # GOTA Coach Bonus - 100 points if coach supervised 10+ contacts
    if gd.getv('gotaco') == "1" and gotaq >= 10:
        gota_coach_bp = 100
        tot_bonus += gota_coach_bp
        print("    %3s GOTA Coach Bonus (supervised 10+ contacts)" % gota_coach_bp)
    # Youth Participation Bonus - 20 points per youth (max 100 = 5 youth)
    if int(gd.getv('youth')) > 0:
        youth_bp = 20 * int(gd.getv('youth'))
        if youth_bp > 5 * 20:
            youth_bp = 5 * 20
        tot_bonus += youth_bp
        print("    %3s Youth Participation Bonus (%s youth x 20 pts)" % (youth_bp, min(int(gd.getv('youth')), 5)))
    # Educational Activity Bonus - 100 points
    if gd.getv('eduact') == "1":
        eduact_bp = 100
        tot_bonus += eduact_bp
        print("    %3s Educational Activity Bonus" % eduact_bp)
    # Social Media Bonus - 100 points
    if gd.getv('social') == "1":
        social_bp = 100
        tot_bonus += social_bp
        print("    %3s Social Media Bonus" % social_bp)
    # Safety Officer Bonus - 100 points
    if gd.getv('safety') == "1":
        safety_bp = 100
        tot_bonus += safety_bp
        print("    %3s Safety Officer Bonus" % safety_bp)
    # Site Responsibilities Bonus - 50 points
    if gd.getv('sitere') == "1":
        sitere_bp = 50
        tot_bonus += sitere_bp
        print("    %3s Site Responsibilities Bonus" % sitere_bp)
    # keep web submission last
    if gd.getv('websub') == "1":
        web_sub_bp = 50
        tot_bonus += web_sub_bp
        print("    %3s Web Submission Bonus" % web_sub_bp)
    print()
    print("    Total Bonus Points Claimed: %5s" % tot_bonus)
    print()
    tot_scor = qso_scor + tot_bonus
    print("    Total Claimed Score:        %5s" % tot_scor)
    print()
    print("16. We have observed all competition rules as well as all regulations")
    print("    for amateur radio in our country. Our report is correct and true")
    print("    to the best of our knowledge. We agree to be bound by the decisions")
    print("    of the ARRL Awards Committee.")
    print()
    print("Submitted By:")
    print()
    print("    Date:     %s UTC" % datime[:-2])
    print("    Call:     %s" % str.upper(gd.getv('fmcall')))
    print("    Name:     %s" % gd.getv('fmname'))
    print("    Address:  %s" % gd.getv('fmad1'))
    print("    Address:  %s" % gd.getv('fmad2'))
    print("    Email:    %s" % gd.getv('fmem'))
    print()
    print()
    print("Field Day Call: %s" % str.upper(fd_call))
    print()
    print("17. QSO Breakdown by Band and Mode")
    print()
    print("        ----CW----  --Digital-  ---Phone--")
    print("  Band  QSOs   PWR  QSOs   PWR  QSOs   PWR")
    print()
    qsobm, pwrbm = {}, {}
    for b in (160, 80, 40, 20, 15, 10, 6, 2, 220, 440, 1200, 'sat', 'gota'):
        if b == 'gota' and gota_call == "":
            continue
        print("%6s" % b, end=' ')
        for m8 in 'cdp':
            bm2 = "%s%s" % (b, m8)
            print("%5s %5s" % (qpb.get(bm2, 0), ppb.get(bm2, 0)), end=' ')
            qsobm[m8] = qsobm.get(m8, 0) + qpb.get(bm2, 0)
            pwrbm[m8] = max(pwrbm.get(m8, 0), ppb.get(bm2, 0))
        print()
    print()
    print("Totals", end=' ')
    print("%5s %5s" % (qsobm['c'], pwrbm['c']), end=' ')
    print("%5s %5s" % (qsobm['d'], pwrbm['d']), end=' ')
    print("%5s %5s" % (qsobm['p'], pwrbm['p']))
    print()
    print()
    if gota_call:
        print("18. Callsigns and QSO counts of GOTA Contestants")
        print()
        print("      Call  QSOs")
        for i25 in list(qpgop.keys()):
            print("    %6s   %3s" % (i25, qpgop[i25]))
        print("    %6s   %3s" % ("Total", gotaq))
        print()
        print()
    print("Dupe Lists sorted by Band, Mode and Call:")
    print()
    print("  Main Station(s) Dupe List (%s)" % fd_call)
    lbycalls = []
    for i25 in list(bycall.values()):
        lbycalls.append("    %4s %s" % (i25.band, i25.call))
    lbycalls.sort()
    b2, n = "", 0
    for i25 in lbycalls:
        b, c6 = i25.split()
        if (b == b2) & (n < 5):  # same band, 5 per line
            print("%-10s" % c6, end=' ')
            n += 1
        else:
            print()
            print("    %4s   %-10s" % (b, c6), end=' ')
            b2 = b
            n = 1
    print()
    print()
    print()
    if gota_call > "":
        print("  GOTA Station Dupe List (%s)" % gota_call)
        lbycalls = []
        for i25 in list(gotabycall.values()):
            lbycalls.append("    %4s %s" % (i25.band, i25.call))
        lbycalls.sort()
        b2, n = "", 0
        for i25 in lbycalls:
            b, c6 = i25.split()
            if (b == b2) & (n < 5):  # same band
                print("%-10s" % c6, end=' ')
                n += 1
            else:
                print()
                print("    %4s   %-10s" % (b, c6), end=' ')
                b2 = b
                n = 1
        print()
        print()
        print()
    if w1aw_msg != "":
        print("W1AW FD Message Copy")
        print()
        print("%s" % w1aw_msg)
        print()
        print()
    if nts_orig_msg != "":
        print("Originated NTS Message")
        print()
        print(nts_orig_msg)
        print()
        print()
    if len(nts_msg_relay) > 0:
        print("RELAYED NTS Messages")
        print()
        for i25 in nts_msg_relay:
            print(i25)
            print()
        print()
    if media_copy != "":
        print("Media Copy")
        print()
        print(media_copy)
        print()
        print()
    if len(nat) > 0:
        print("Natural Power QSOs (show first 10 logged)")
        print()
        lnat = []
        for i25 in nat:
            ln = "%8s %5s %-10s %-18s %4s %-6s %-6s %4s %s" % \
                 (i25.date[4:11], i25.band, i25.call, i25.rept[:18], i25.powr, i25.oper, i25.logr, i25.seq, i25.src)
            lnat.append(ln)
        lnat.sort()
        j3 = 0
        for i25 in lnat:
            print(i25)
            j3 += 1
            if j3 > 9:
                break
        print()
        print()
    if len(sat) > 0:
        print("Satellite QSOs (show 5)")
        print()
        lsat = []
        for i25 in sat:
            ln = "%8s %5s %-10s %-18s %4s %-6s %-6s %4s %s" % \
                 (i25.date[4:11], i25.band, i25.call, i25.rept[:18], i25.powr, i25.oper, i25.logr, i25.seq, i25.src)
            lsat.append(ln)
        lsat.sort()
        j3 = 0
        for i25 in lsat:
            print(i25)
            j3 += 1
            if j3 > 4:
                break
        print()
        print()
    if soapbox != "":
        print("Soapbox Comments")
        print()
        print(soapbox)
        print()
        print()
    print("Logging and Reporting Software Used:\n")
    print(prog)
    print("===================== CLIP HERE ============================")
    print()
    print("(do not include below in ARRL submission)")
    print()
    print("Submission Notes")
    print("""
    email files as attachments to FieldDay@arrl.org within 30 days!!!
    web entry at www.b4h.net/cabforms
        fdlog.log log file, less log detail below 'CLIP HERE'
        proof of bonus points, as needed:
            public info booth picture, visitor list, info
            visiting officials pictures
            media visiting pictures
            natural power pictures
            demo stations pictures
        plus other interesting pictures
    """)
    print("Participant List")
    print()
    lpart = []
    for i25 in list(participants.values()):
        lpart.append(i25)
    lpart.sort()
    n = 0
    for i25 in lpart:
        n += 1
        print("  %4s %s" % (n, i25))
    print()
    print()
    print("QSO breakdown by Station")
    print()
    for i25 in list(qpst.keys()):
        print("  %4s %s" % (qpst[i25], i25))
    print()
    print()
    print("QSO breakdown by Contestant")
    print()
    for i25 in list(qpop.keys()):
        print("  %4s %s" % (qpop[i25], i25))
    print()
    print()
    print("QSO breakdown by Logger")
    print()
    for i25 in list(qplg.keys()):
        print("  %4s %s" % (qplg[i25], i25))
    print()
    print()
    print("Worked All States during FD Status")
    print()
    r = qdb.was_log_report()
    for i25 in r:
        print(i25)
    print()
    print()
    print("Detailed Log")
    print()
    print("  Date Range", gd.getv('fdstrt'), "-", gd.getv('fdend'), "UTC")
    print()
    qdb.pr_log()
    print()
    print()
    print("ADIF Log")
    print()
    qdb.pr_adif()
    print()
    print("VHF Cabrillo")
    print()
    qdb.vhf_cabrillo()
    print()
    print()
    print("Winter Field day")
    print()
    qdb.winter_fd()
    print()
    print("eof")
    sys.stdout = sys.__stdout__  # revert print to console
    print()
    print("entry and log written to file", logfile)


def bandset(b):
    global band, tmob
    if node == "":
        b = 'off'
        txtbillb.insert(END, "err - no node\n")
    if operator == "":
        b = 'off'
        # txtbillb.insert(END, "err - no Contestant\n")
    # if b != 'off':
        # s = net.si.nod_on_band(b)
        # if s:
        # txtbillb.insert(END, " Already on [%s]: %s\n" % (b, s))
    txtbillb.see(END)
    if band != b:
        tmob = now()  # reset time on band
    band = b
    bandb[b].select()
    # Update CW/Voice status label appearance based on mode
    mode_char = b[-1:] if b != 'off' else ''
    if CW_AVAILABLE and cw_status_label:
        if mode_char == 'c':
            hint = " [Hide]" if fkey_bar_visible else " [Show]"
            cw_status_label.config(foreground='dark green', state='normal',
                                   text=f"CW: Ready{hint}")
        else:
            cw_status_label.config(foreground='gray', state='disabled',
                                   text="CW: Ready")
            if fkey_bar_visible and mode_char != 'p':
                toggle_fkey_bar()
    if VOICE_AVAILABLE and voice_status_label:
        if mode_char == 'p':
            hint = " [Hide]" if fkey_bar_visible else " [Show]"
            voice_status_label.config(foreground='dark blue', state='normal',
                                      text=f"Voice: Ready{hint}")
        else:
            voice_status_label.config(foreground='gray', state='disabled',
                                      text="Voice: Ready")
            if fkey_bar_visible and mode_char != 'c':
                toggle_fkey_bar()
    if operator != "":
        ini2 = operator.split(':', 1)[0]
        operatorsonline.update({node: ini2})
    renew_title()
    # Push frequency to fldigi if connected and push_frequency enabled
    if FLDIGI_AVAILABLE and fldigi_poller and fldigi_poller.is_connected():
        if fldigi_poller.config.push_frequency and b != 'off' and b in BAND_FREQ_MAP:
            fldigi_poller.set_frequency(BAND_FREQ_MAP[b])
    # Push frequency to N3FJP client if connected
    if N3FJP_AVAILABLE and n3fjp_client and n3fjp_client.is_connected():
        if b != 'off' and b in N3FJP_BAND_FREQ_MAP:
            n3fjp_client.set_frequency(N3FJP_BAND_FREQ_MAP[b])
    # Push frequency to rigctld if connected and push_frequency enabled
    if RIGCTLD_AVAILABLE and rigctld_client and rigctld_client.is_connected():
        if rigctld_client.config.push_frequency and b != 'off' and b in RIGCTLD_BAND_FREQ_MAP:
            rigctld_client.set_frequency(RIGCTLD_BAND_FREQ_MAP[b])


def bandoff():
    """ To set the band to off"""
    bandset('off')


class NewParticipantDialog:
    """ this is the new participant window that pops up"""

    def __init__(self):
        self.t = None
        self.call = None
        self.vist = None
        self.age = None
        self.name = None
        self.initials = None

    @staticmethod
    def dialog():
        """ the gui of the new participant window"""
        if node == "":
            txtbillb.insert(END, "err - no node\n")
            return
        s = NewParticipantDialog()
        s.t = Toplevel(root)
        s.t.transient(root)
        s.t.title('Add New Participant')
        s.t.bind('<Escape>', lambda e: s.t.destroy())
        # Frame 1
        fr1 = Frame(s.t)
        fr1.grid(row=0, column=0)

        def getpartsel(event):
            """Used to select the participant from the listbox"""
            #  Added by Scott Hibbs KD4SIR 15Aug2022
            s.initials.delete(0, END)
            s.name.delete(0, END)
            s.call.delete(0, END)
            s.age.delete(0, END)
            s.vist.delete(0, END)
            selection = event.widget.curselection()
            indx = selection[0]
            value = event.widget.get(indx)
            # print('value : ', value)
            init, nomio, callio, ageio, vistio = value.split(", ")
            # ln = init + " " + nomio + " " + callio + " " + ageio + " " + vistio
            s.initials.insert(END, init)
            s.name.insert(END, nomio)
            s.call.insert(END, callio)
            s.age.insert(END, ageio)
            s.vist.insert(END, vistio)

        partlbox = Listbox(fr1, bg='light gray', height=0, width=0, selectmode="single", exportselection=False)
        partlbox.grid(row=0, column=0, sticky=NSEW)
        lpart1 = list(participants.values())
        lpart1.sort()
        partlboxind = -1
        for player in lpart1:
            #  print("player is : " , player)
            partlboxind += 1
            partlbox.insert(partlboxind, player)
        partlbox.bind('<<ListboxSelect>>', getpartsel)  # Select click
        Label(fr1, text=" Select above to edit.", font=fdfont).grid(row=1, column=0, sticky=NSEW)
        Label(fr1, text="~Initials must be unique~", font=fdfont).grid(row=2, column=0, sticky=NSEW)
        # Frame 2
        fr2 = Frame(s.t)
        fr2.grid(row=1, column=0)
        # Moved the Initials below the name. It was awkward to ask for initials first. - Scott Hibbs 18Jun2022
        Label(fr2, text='Name', font=fdfont).grid(row=0, column=0, sticky=W)
        s.name = Entry(fr2, width=20, font=fdfont)
        s.name.grid(row=0, column=1, sticky=W)
        s.name.focus()
        Label(fr2, text='Initials   ', font=fdfont).grid(row=1, column=0, sticky=W)
        s.initials = Entry(fr2, width=3, font=fdfont, validate='focusout', validatecommand=s.lookup)
        s.initials.grid(row=1, column=1, sticky=W)
        Label(fr2, text='Call', font=fdfont).grid(row=2, column=0, sticky=W)
        s.call = Entry(fr2, width=6, font=fdfont)
        s.call.grid(row=2, column=1, sticky=W)
        Label(fr2, text='Age', font=fdfont).grid(row=3, column=0, sticky=W)
        s.age = Entry(fr2, width=2, font=fdfont)
        s.age.grid(row=3, column=1, sticky=W)
        Label(fr2, text='Visitor Title', font=fdfont).grid(row=4, column=0, sticky=W)
        s.vist = Entry(fr2, width=20, font=fdfont)
        s.vist.grid(row=4, column=1, sticky=W)
        # Frame 3
        fr3 = Frame(s.t)
        fr3.grid(row=2, column=0, sticky=EW, pady=3)
        fr3.columnconfigure(0, weight=1)
        # Added Save label - Curtis E. Mills WE7U 25Jun2019
        Label(fr3, text='  Save = <Enter>', font=fdfont, foreground='green').grid(row=3, column=0, sticky=W)
        # Added a button to delete participant - Scott Hibbs KD4SIR 15Aug2022
        # Button(fr3, text='Delete', font=fdfont, command=dlbtn1) .grid(row=3, column=1, sticky=EW, padx=3)
        # Added clear label - Scott Hibbs KD4SIR 15Aug2022
        Button(fr3, text='Clear', font=fdfont, command=s.clearbtn) .grid(row=3, column=2, sticky=EW, padx=3)
        # Button renamed to Dismiss - Curtis E. Mills WE7U 25Jun2019
        Button(fr3, text='Dismiss', font=fdfont, command=s.quitbtn).grid(row=3, column=3, sticky=EW, padx=3)
        # Bound enter key to save entries - Scott Hibbs KD4SIR Mar/30/2017
        s.t.bind('<Return>', lambda event: s.applybtn)

    def lookup(self):
        # constrain focus to the initials until they are ok -slightly annoying - may change in future
        initials = str.lower(self.initials.get())
        if not re.match(r'[a-zA-Z]{2,3}$', initials):
            # self.initials.delete(0,END)
            self.initials.config(bg='gold')
            self.initials.focus()
        else:
            self.initials.config(bg='white')
            dummy, name7, call10, age4, vist1 = str.split(participants.get(initials, ', , , , '), ', ')
            if dummy == initials:
                self.initials.delete(0, END)
                self.initials.config(bg='gold')
                self.initials.focus()
                age4 = 0
                vist1 = ""
            if age4 == 0:
                pass
            else:
                self.age.insert(END, age4)
            self.vist.delete(0, END)
            if vist1 == "":
                pass
            else:
                self.vist.insert(END, vist1)
        return True

    @property  # This added, so I can use the <Return> binding -Scott Hibbs KD4SIR Mar/30/2017
    def applybtn(self):
        global participants
        # print "store"
        initials = self.initials.get().lower()
        name11 = self.name.get()
        call11 = str.lower(self.call.get())
        age5 = str.lower(self.age.get())
        vist2 = str.lower(self.vist.get())
        self.initials.config(bg='white')
        self.name.config(bg='white')
        self.call.config(bg='white')
        self.age.config(bg='white')
        self.vist.config(bg='white')
        if not re.match(r'[a-zA-Z]{2,3}$', initials):
            txtbillb.insert(END, "error in initials\n")
            txtbillb.see(END)
            topper()
            self.initials.focus()
            self.initials.config(bg='gold')
        elif not re.match(r'[A-Za-z ]{4,20}$', name11):
            txtbillb.insert(END, "error in name\n")
            txtbillb.see(END)
            topper()
            self.name.focus()
            self.name.config(bg='gold')
        elif not re.match(r'([a-zA-Z\d]{3,6})?$', call11):
            txtbillb.insert(END, "error in call\n")
            txtbillb.see(END)
            topper()
            self.call.focus()
            self.call.config(bg='gold')
        elif not re.match(r'(\d{1,2})?$', age5):
            txtbillb.insert(END, "error in age\n")
            txtbillb.see(END)
            topper()
            self.age.focus()
            self.age.config(bg='gold')
        elif not re.match(r'([a-zA-Z\d]{4,20})?$', vist2):
            txtbillb.insert(END, "error in title\n")
            txtbillb.see(END)
            topper()
            self.vist.focus()
            self.vist.config(bg='gold')
        else:
            # Enter the Participant in the dictionary
            # initials # statement has no effect - removed
            nam = "p:%s" % initials  # not used
            v = "%s, %s, %s, %s, %s" % (initials, name11, call11, age5, vist2)
            participants[initials] = v
            _dummy = qdb.globalshare(nam, v)  # store + bcast #
            txtbillb.insert(END, " New Participant Entered.")
            if sound_enabled.get(): root.bell()
            txtbillb.see(END)
            topper()
            self.initials.delete(0, END)
            self.name.delete(0, END)
            self.call.delete(0, END)
            self.age.delete(0, END)
            self.vist.delete(0, END)
            self.name.focus()
            buildmenus()
            self.quitbtn()
            self.dialog()
        return None  # used to avoid pycharm error "Getter should return or yield something"

    def clearbtn(self):
        """ Used to clear the data from the participant form."""
        # Added by Scott Hibbs KD4SIR 15Aug2022
        self.name.delete(0, END)
        self.initials.delete(0, END)
        self.call.delete(0, END)
        self.age.delete(0, END)
        self.vist.delete(0, END)

    def quitbtn(self):
        self.t.destroy()


def verify_admin_pin():
    """Open a dialog to verify the admin PIN. Returns True if correct, False otherwise."""
    stored_hash = globDb.get('adminpin', '')
    if not stored_hash:
        txtbillb.insert(END, "\nNo admin PIN set. Use initialize or .set adminpin\n")
        txtbillb.see(END)
        return False
    result = [False]
    dlg = Toplevel(root)
    dlg.transient(root)
    dlg.title('Enter Admin PIN')
    dlg.grab_set()
    Label(dlg, text='Enter admin PIN:', font=fdfont).grid(row=0, column=0, padx=5, pady=5)
    pin_entry = Entry(dlg, width=6, font=fdfont, show='*')
    pin_entry.grid(row=0, column=1, padx=5, pady=5)
    pin_entry.focus()
    msg_label = Label(dlg, text='', font=fdfont, fg='red')
    msg_label.grid(row=1, column=0, columnspan=2)

    def check_pin(event=None):
        entered = pin_entry.get().strip()
        hashed = hashlib.md5(entered.encode()).hexdigest()
        if hashed == stored_hash:
            result[0] = True
            dlg.destroy()
        else:
            msg_label.config(text='Incorrect PIN')
            pin_entry.delete(0, END)
            pin_entry.focus()

    def cancel(event=None):
        dlg.destroy()

    dlg.bind('<Return>', check_pin)
    dlg.bind('<Escape>', cancel)
    Button(dlg, text='OK', font=fdfont, command=check_pin).grid(row=2, column=0, pady=5)
    Button(dlg, text='Cancel', font=fdfont, command=cancel).grid(row=2, column=1, pady=5)
    root.wait_window(dlg)
    return result[0]


class EditParticipantDialog:
    """Dialog to edit existing participants, protected by admin PIN."""

    def __init__(self):
        self.t = None
        self.name = None
        self.call = None
        self.age = None
        self.vist = None
        self.initials_label = None
        self.selected_initials = None

    @staticmethod
    def dialog():
        if node == "":
            txtbillb.insert(END, "err - no node\n")
            return
        if not verify_admin_pin():
            return
        s = EditParticipantDialog()
        s.t = Toplevel(root)
        s.t.transient(root)
        s.t.title('Edit Participant')
        s.t.bind('<Escape>', lambda e: s.t.destroy())
        # Frame 1 - participant list
        fr1 = Frame(s.t)
        fr1.grid(row=0, column=0, sticky=NSEW)

        def getpartsel(event):
            selection = event.widget.curselection()
            if not selection:
                return
            indx = selection[0]
            value = event.widget.get(indx)
            init, nomio, callio, ageio, vistio = value.split(", ")
            s.selected_initials = init
            s.initials_label.config(text=init)
            s.name.delete(0, END)
            s.name.insert(END, nomio)
            s.call.delete(0, END)
            s.call.insert(END, callio)
            s.age.delete(0, END)
            s.age.insert(END, ageio)
            s.vist.delete(0, END)
            s.vist.insert(END, vistio)

        partlbox = Listbox(fr1, bg='light gray', height=0, width=0, selectmode="single", exportselection=False)
        partlbox.grid(row=0, column=0, sticky=NSEW)
        lpart1 = list(participants.values())
        lpart1.sort()
        partlboxind = -1
        for player in lpart1:
            partlboxind += 1
            partlbox.insert(partlboxind, player)
        partlbox.bind('<<ListboxSelect>>', getpartsel)
        Label(fr1, text=" Select a participant to edit.", font=fdfont).grid(row=1, column=0, sticky=NSEW)
        # Frame 2 - edit fields
        fr2 = Frame(s.t)
        fr2.grid(row=1, column=0)
        Label(fr2, text='Initials', font=fdfont).grid(row=0, column=0, sticky=W)
        s.initials_label = Label(fr2, text='--', font=fdfont, width=5, relief=SUNKEN, anchor=W)
        s.initials_label.grid(row=0, column=1, sticky=W)
        Label(fr2, text='Name', font=fdfont).grid(row=1, column=0, sticky=W)
        s.name = Entry(fr2, width=20, font=fdfont)
        s.name.grid(row=1, column=1, sticky=W)
        Label(fr2, text='Call', font=fdfont).grid(row=2, column=0, sticky=W)
        s.call = Entry(fr2, width=6, font=fdfont)
        s.call.grid(row=2, column=1, sticky=W)
        Label(fr2, text='Age', font=fdfont).grid(row=3, column=0, sticky=W)
        s.age = Entry(fr2, width=2, font=fdfont)
        s.age.grid(row=3, column=1, sticky=W)
        Label(fr2, text='Visitor Title', font=fdfont).grid(row=4, column=0, sticky=W)
        s.vist = Entry(fr2, width=20, font=fdfont)
        s.vist.grid(row=4, column=1, sticky=W)
        # Frame 3 - buttons
        fr3 = Frame(s.t)
        fr3.grid(row=2, column=0, sticky=EW, pady=3)
        fr3.columnconfigure(0, weight=1)
        Button(fr3, text='Save', font=fdfont, command=s.savebtn).grid(row=0, column=0, sticky=EW, padx=3)
        Button(fr3, text='Dismiss', font=fdfont, command=s.quitbtn).grid(row=0, column=1, sticky=EW, padx=3)
        s.t.bind('<Return>', lambda event: s.savebtn())

    def savebtn(self):
        global participants
        initials = self.selected_initials
        if not initials:
            txtbillb.insert(END, "\nNo participant selected.\n")
            txtbillb.see(END)
            return
        name11 = self.name.get()
        call11 = str.lower(self.call.get())
        age5 = str.lower(self.age.get())
        vist2 = str.lower(self.vist.get())
        self.name.config(bg='white')
        self.call.config(bg='white')
        self.age.config(bg='white')
        self.vist.config(bg='white')
        if not re.match(r'[A-Za-z ]{4,20}$', name11):
            txtbillb.insert(END, "error in name\n")
            txtbillb.see(END)
            topper()
            self.name.focus()
            self.name.config(bg='gold')
        elif not re.match(r'([a-zA-Z\d]{3,6})?$', call11):
            txtbillb.insert(END, "error in call\n")
            txtbillb.see(END)
            topper()
            self.call.focus()
            self.call.config(bg='gold')
        elif not re.match(r'(\d{1,2})?$', age5):
            txtbillb.insert(END, "error in age\n")
            txtbillb.see(END)
            topper()
            self.age.focus()
            self.age.config(bg='gold')
        elif not re.match(r'([a-zA-Z\d]{4,20})?$', vist2):
            txtbillb.insert(END, "error in title\n")
            txtbillb.see(END)
            topper()
            self.vist.focus()
            self.vist.config(bg='gold')
        else:
            nam = "p:%s" % initials
            v = "%s, %s, %s, %s, %s" % (initials, name11, call11, age5, vist2)
            participants[initials] = v
            _dummy = qdb.globalshare(nam, v)
            txtbillb.insert(END, " Participant Updated.")
            if sound_enabled.get(): root.bell()
            txtbillb.see(END)
            topper()
            buildmenus()
            self.quitbtn()

    def quitbtn(self):
        self.t.destroy()


def renew_title():
    """renew title and various, called at 10 second rate"""
    if node == 'gotanode':
        call12 = str.upper(gd.getv('gcall'))
    else:
        call12 = str.upper(gd.getv('fdcall'))
    clas = str.upper(gd.getv('class'))
    sec = gd.getv('sect')
    t = now()
    sob = tmsub(t, tmob)
    mob = sob / 60
    h = mob / 60
    m9 = mob % 60
    # Get local time for display
    local_time = time.localtime(time.time() + mclock.offset)
    local_hm = time.strftime("%H:%M", local_time)
    # Added port to the heading - Scott Hibbs KD4SIR Jan/27/2017
    # Port now moved to node label and clean up title - Scott Hibbs KD4SIR 06Aug2022
    # root.title('  FDLog_Enhanced %s %s %s (Node: %s Time on Band: %d:%02d) %s:%s UTC %s/%s Port:%s' %
    #            (call12, clas, sec, node, h, m9, t[-6:-4], t[-4:-2], t[2:4], t[4:6], port_base))
    mon_abbr = time.strftime("%b", time.strptime(t[2:4], "%m"))
    root.title('  FDLog_Enhanced      %s %s %s      %s%s20%s  UTC: %s:%s  Local: %s' %
               (call12, clas, sec, t[4:6], mon_abbr, t[0:2], t[-6:-4], t[-4:-2], local_hm))
    # Adding a lbltimeonband that needs updated with the title. - Scott Hibbs KD4SIR 06Aug2022
    # lbltimeonband.config(text= " Time on Band: %d:%02d " % (h, m9), font=fdfont, foreground='blue',
    #                      background='light gray')
    timeonband(h, m9)
    net.bcast_now()  # this is periodic bcast...
    net.bc_user(node, operator, logger, band)


def timeonband(h, m9):
    """This sets the color of the lbltimeonband"""
    # Added by Scott Hibbs KD4SIR 06Aug2022
    global acttime
    if band == "off":
        lbltimeonband.config(text=" Time Away: %d:%02d " % (h, m9), font=fdfont, foreground='blue',
                             background='red')
        acttime = m9
        #  print("Act time: %s" % acttime)
    else:
        lbltimeonband.config(text=" Inactive:  %d:%02d " % (h, m9), font=fdfont, foreground='blue',
                             background='light gray')
        acttime = m9
        #  print("Act time: %s" % acttime)


def setnode(new):
    """Set the node"""
    global node
    bandoff()
    node = str.lower(new)
    qdb.redup()
    renew_title()
    # Added so the new lblnode could be updated. - Scott Hibbs KD4SIR Mar/28/2017
    lblnode.config(text=" My Node: %s Port: %s " % (node, port_base), font=fdfont, foreground='blue',
                   background='light gray')


def applyprop():
    """apply property"""
    global operator, logger, power, node
    new = cf['e'].get()
    if re.match(cf['vre'], new):
        #        if   cf['lab'] == 'Operator': operator = new
        #        elif cf['lab'] == 'Logger':   logger = new
        #        elif cf['lab'] == 'Power':    power = new
        if cf['lab'] == 'Node':
            setnode(new)
        #        elif cf['lab'] == 'AuthKey':  reauth(new)    #net.setauth(new)
        else:
            print('error, no such var')
        saveglob()
        renew_title()
        cf['p'].destroy()
    else:
        print('bad syntax', new)


def pdiag(label, value, valid_re, wid):
    """property dialog box"""
    cf['p'] = Toplevel(root)
    cf['p'].transient(root)
    Label(cf['p'], text=label, font=fdfont).grid(sticky=E, pady=20)
    if label == 'AuthKey':
        cf['e'] = Entry(cf['p'], width=wid, font=fdfont, show='*')
    else:
        cf['e'] = Entry(cf['p'], width=wid, font=fdfont)
    cf['e'].grid(row=0, column=1, sticky=W)
    cf['e'].insert(END, value)
    Button(cf['p'], text="Apply", command=applyprop, font=fdfont) \
        .grid(sticky=W, padx=20)
    Button(cf['p'], text="Cancel", command=cf['p'].destroy, font=fdfont) \
        .grid(padx=20, pady=20, row=1, column=1, sticky=E)
    cf['vre'] = valid_re
    cf['lab'] = label
    cf['e'].bind('<Return>', applyprop)
    cf['p'].bind('<Escape>', lambda e04: (cf['p'].destroy()))
    cf['e'].focus()


def noddiag():
    pdiag('Node', node, r'[A-Za-z\d-]{1,8}$', 8)
    # def authdiag():
    #    pdiag('AuthKey',authk,r'.{3,12}$',12)


class GPSSyncDialog:
    """GPS Sync configuration dialog"""

    _default_ntp_servers = ['pool.ntp.org', 'time.nist.gov', 'time.google.com']

    def __init__(self):
        pass

    def dialog(self):
        t = Toplevel(root)
        t.transient(root)
        t.title('Time Function Settings')
        t.bind('<Escape>', lambda e: t.destroy())

        # Read current state
        current_tmast = globDb.get('tmast', '')
        # Also check network-synced value
        network_check = gd.getv('tmast')
        if isinstance(network_check, str) and network_check.startswith('get error'):
            network_check = ''
        is_tmast = ((current_tmast == node or network_check == node) and node != '')
        # Check if a custom NTP server is present (not in defaults)
        custom_ntp = ''
        if mclock.ntp_servers and mclock.ntp_servers[0] not in self._default_ntp_servers:
            custom_ntp = mclock.ntp_servers[0]

        # Determine current time master status
        # Check network-synced global (gd) for designated master, not just local storage
        network_tmast = gd.getv('tmast')
        if isinstance(network_tmast, str) and network_tmast.startswith('get error'):
            network_tmast = ''
        # Check for auto-elected master
        network_telect = gd.getv('telect')
        if isinstance(network_telect, str) and network_telect.startswith('get error'):
            network_telect = ''

        def is_node_online(node_name):
            """Check if a node is active on the network."""
            if not node_name:
                return False
            node_lower = str.lower(node_name)
            if node_lower == str.lower(node):
                return True  # We are that node
            for ni in net.si.nodes.values():
                if ni.age < 60 and ni.nod and str.lower(ni.nod) == node_lower:
                    return True
            return False

        effective_tmast = current_tmast or network_tmast
        if effective_tmast:
            online_status = "online" if is_node_online(effective_tmast) else "OFFLINE"
            tmast_status = "Time Master: %s (designated, %s)" % (effective_tmast, online_status)
        elif network_telect:
            online_status = "online" if is_node_online(network_telect) else "OFFLINE"
            tmast_status = "Time Master: %s (elected, %s)" % (network_telect, online_status)
        elif mclock.level == 0:
            tmast_status = "Time Master: %s (this node)" % node
        else:
            tmast_status = "Time Master: awaiting election"

        tmast_var = IntVar(value=1 if is_tmast else 0)
        gpsusb_var = IntVar(value=1 if mclock.gps_locked else 0)
        ntp_var = StringVar(value=custom_ntp)

        fr = Frame(t, padx=10, pady=10)
        fr.grid(row=0, column=0, sticky=NSEW)

        status_label = Label(fr, text=tmast_status, font=fdfont)
        status_label.grid(row=0, column=0, sticky=W, pady=(0, 8))

        defaults_str = ', '.join(self._default_ntp_servers)
        Label(fr, text="Default NTP Servers: %s" % defaults_str, font=fdfont) \
            .grid(row=1, column=0, sticky=W, pady=2)

        Label(fr, text="Custom NTP Address:", font=fdfont) \
            .grid(row=2, column=0, sticky=W, pady=(8, 0))
        ntp_entry = Entry(fr, textvariable=ntp_var, width=30, font=fdfont)
        ntp_entry.grid(row=3, column=0, sticky=W, padx=10, pady=2)

        ntp_info = Label(fr, text="", font=fdfont, fg="blue")
        ntp_info.grid(row=3, column=0, sticky=E, padx=10)

        def on_ntp_change(*_args):
            addr = ntp_var.get().strip()
            if addr:
                if addr in self._default_ntp_servers:
                    ntp_info.config(text="Already a default server", fg="gray")
                else:
                    ntp_info.config(text="Priority over defaults", fg="blue")
            else:
                ntp_info.config(text="")

        ntp_var.trace_add('write', on_ntp_change)
        on_ntp_change()  # Set initial state

        effective_tmast_init = current_tmast or network_tmast
        other_is_tmast = (effective_tmast_init != '' and effective_tmast_init != node)
        cb_tmast = Checkbutton(fr, text="Make this node Time Master",
                               variable=tmast_var, font=fdfont,
                               state='disabled' if other_is_tmast else 'normal')
        cb_tmast.grid(row=4, column=0, sticky=W, pady=2)

        def update_status():
            """Refresh time master status periodically."""
            try:
                cur_tmast = globDb.get('tmast', '')
                # Also check network-synced global for designated master
                net_tmast = gd.getv('tmast')
                if isinstance(net_tmast, str) and net_tmast.startswith('get error'):
                    net_tmast = ''
                # Check for auto-elected master
                net_telect = gd.getv('telect')
                if isinstance(net_telect, str) and net_telect.startswith('get error'):
                    net_telect = ''
                effective_tmast = cur_tmast or net_tmast
                if effective_tmast:
                    online_status = "online" if is_node_online(effective_tmast) else "OFFLINE"
                    new_status = "Time Master: %s (designated, %s)" % (effective_tmast, online_status)
                elif net_telect:
                    online_status = "online" if is_node_online(net_telect) else "OFFLINE"
                    new_status = "Time Master: %s (elected, %s)" % (net_telect, online_status)
                elif mclock.level == 0:
                    new_status = "Time Master: %s (this node)" % node
                else:
                    new_status = "Time Master: awaiting election"
                status_label.config(text=new_status)
                # Update checkbox state - disable if another node is the designated master
                other_master = (effective_tmast != '' and effective_tmast != node)
                cb_tmast.config(state='disabled' if other_master else 'normal')
                t.after(2000, update_status)
            except Exception:
                pass  # Dialog was closed

        t.after(2000, update_status)
        cb_gpsusb = Checkbutton(fr, text="GPS USB / GPS Locked Time",
                                variable=gpsusb_var, font=fdfont)
        cb_gpsusb.grid(row=5, column=0, sticky=W, pady=2)

        ntp_error = Label(fr, text="", fg="red", font=fdfont)
        ntp_error.grid(row=6, column=0, sticky=W)

        def test_ntp(addr):
            """Try an actual NTP query to the address. Returns True if it responds."""
            try:
                NTP_EPOCH = 2208988800
                client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                client.settimeout(3)
                data = b'\x1b' + 47 * b'\0'
                client.sendto(data, (addr, 123))
                data, _ = client.recvfrom(1024)
                client.close()
                return len(data) >= 48
            except Exception:
                return False

        def apply_settings():
            ntp_addr = ntp_var.get().strip()
            if ntp_addr and not test_ntp(ntp_addr):
                ntp_error.config(text="NTP server not responding")
                return
            # NTP server - only publish if changed
            if ntp_addr != custom_ntp:
                if ntp_addr:
                    mclock.ntp_servers = [ntp_addr] + self._default_ntp_servers
                    globDb.put('tntp', ntp_addr)
                    qdb.globalshare('tntp', ntp_addr)
                else:
                    mclock.ntp_servers = list(self._default_ntp_servers)
            # GPS locked - always local, no broadcast needed
            mclock.gps_locked = bool(gpsusb_var.get())
            # Time master - only publish if changed
            wants_tmast = bool(tmast_var.get())
            if wants_tmast != is_tmast:
                if wants_tmast:
                    globDb.put('tmast', node)
                    qdb.globalshare('tmast', node)
                    # Designation supersedes any previous election
                    globDb.put('telect', '')
                    qdb.globalshare('telect', '')
                else:
                    # This node is stepping down - trigger immediate election
                    globDb.put('tmast', '')
                    qdb.globalshare('tmast', '')
                    globDb.put('telect', 'election')
                    qdb.globalshare('telect', 'election')
                    mclock._election_pending = True
                    mclock._election_start_time = time.monotonic()
                    print("Designated master stepping down, triggering election")
            renew_title()
            t.destroy()

        btn_frame = Frame(fr)
        btn_frame.grid(row=7, column=0, pady=10)
        Button(btn_frame, text="Apply", command=apply_settings, font=fdfont) \
            .grid(row=0, column=0, padx=10)
        Button(btn_frame, text="Cancel", command=t.destroy, font=fdfont) \
            .grid(row=0, column=1, padx=10)


def viewprep(ttl=''):
    """view preparation core code"""
    w = Toplevel(root)
    #    w.transient(root)
    w.title("FDLog_Enhanced - %s" % ttl)
    t = Text(w, takefocus=0, height=20, width=85, font=fdfont,
             wrap="none", setgrid=True)
    s = Scrollbar(w, command=t.yview)
    t.config(yscrollcommand=s.set)
    t.grid(row=0, column=0, sticky=NSEW)
    s.grid(row=0, column=1, sticky=NS)
    w.grid_rowconfigure(0, weight=1)
    w.grid_columnconfigure(0, weight=1)
    t.bind('<KeyPress>', kevent)
    return t


def viewtextv(txt, ttl=''):
    """view text variable"""
    w = viewprep(ttl)
    w.insert(END, txt)
    w.config(state="disabled")


def viewtextl(lthing, ttl=''):
    """view text list"""
    w = viewprep(ttl)
    for i26 in lthing:
        w.insert(END, "%s\n" % i26)
    w.config(state="disabled")


def viewtextf(fn, ttl=''):
    """view text file"""
    if ttl == "":
        ttl = "file %s" % fn
    # Resolve path relative to script directory for cross-platform compatibility
    if not os.path.isabs(fn):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        fn = os.path.join(script_dir, fn)
    try:
        fd = open(fn, 'r', encoding='utf-8', errors='replace')
        lfile = fd.read()
        viewtextv(lfile, ttl)
        fd.close()
    except IOError:
        viewtextv("read error on file %s" % fn)


def viewlogf(bandm):
    """view log filtered by bandmode"""
    lg = qdb.filterlog2(bandm)
    viewtextl(lg, "Log Filtered for %s" % bandm)


def viewlogfm(emode):
    """view log filtered by mode"""
    # Added by Scott Hibbs KD4SIR 05Aug2022
    lg = qdb.filterlog3(emode)
    viewtextl(lg, "Log Filtered for %s" % emode)


def viewlogfs(nod):
    """view log filtered by node"""
    lg = qdb.filterlogst(nod)
    viewtextl(lg, "Log Filtered for %s" % nod)


def viewwasrpt():
    r = qdb.was_log_report()
    viewtextl(r, "Worked All States Report")


def viewsectionsrpt():
    r = qdb.was_sections_report()
    viewtextl(r, "Worked All Sections Report")


def updatebb():
    """update the Class/VHF/Gota buttons"""
    r, cl, vh, go = net.si.nod_on_bands()
    anytext = "VHF "
    for i27 in bands:
        for j4 in modes:
            bm3 = "%s%s" % (i27, j4)
            if i27 == 'off':
                continue
            sc = 'white'
            n = len(r.get(bm3, ''))  # This is the number of nodes on same band/mode.
            if n == 0:  # no one on this band/mode.
                bc = 'light gray'
            elif n == 1:  # only one on this band/mode.
                bc = 'gold'
            else:  # more than one on this band/mode.
                bc = 'dark orange'
                sc = 'red'
            bandb[bm3].config(background=bc, selectcolor=sc)
    cltg = ival(gd.getv('class'))  # class target
    if cltg > 1:
        vhfree = 1  # handle free vhf xmttr
        if vh == 0:
            ts = cl
        else:
            ts = cl - vhfree
        if ts <= -1:
            ts = 0
    else:
        vhfree = 0
        ts = cl
    # Fixed VHF to reflect a free transmitter and warn if two vhf rigs are used. - Scott Hibbs KD4SIR 5/14/2014
    clc = 'gold'
    if ts == cltg:
        clc = 'pale green'
    if ts > cltg:
        clc = 'red'
    bandb['Class'].config(text='Class %s/%s' % (ts, cltg), background=clc)
    vhc = 'gold'
    if vh - vhfree == 0:
        vhc = 'pale green'  # for 1D Class correction KD4SIR
        anytext = "VHF "
    if vh < 0:
        vhc = 'red'
        anytext = "VHF "
    if vh > vhfree:
        vhc = 'dark orange'  # 2 vhf is okay, only 1 is free...
        anytext = "VHF taking HF "
    bandb['VHF'].config(text='%s%s/%s' % (anytext, vh, vhfree), background=vhc)
    if cltg > 1:
        gotatg = 1
    else:
        gotatg = 0
    goc = 'gold'
    if go == gotatg:
        goc = 'pale green'
    if go > gotatg:
        goc = 'red'
    bandb['GOTA'].config(text='GOTA %s/%s' % (go, gotatg), background=goc)


def updateqct():
    """update contact count aka individual scoring"""
    # Separated CW and Digital scores instead of adding them - Scott Hibbs KD4SIR 05Aug2022
    dummy, dummy, qpop, qplg, dummy, dummy, dummy, dummy, cwq, digq, fonq, dummy, gotaq, nat, dummy = \
        qdb.band_rpt()  # xx reduce processing here
    for i28, j6 in (('FonQ', 'Phone: %5s' % fonq),
                    ('CW/D', 'CW: %s & Dig: %s' % (cwq, digq)),
                    ('GOTAq', 'GOTA: %6s' % gotaq)):
        bandb[i28].config(text=j6, background='light gray')
    # Update natural/alternate power countdown - 5 QSOs needed for 100pt bonus
    nat_count = len(nat)
    if nat_count >= 5:
        natpwr_countdown.config(text=f"Nat: {nat_count}/5 \u2713", background='pale green')
    else:
        natpwr_countdown.config(text=f"Nat: {nat_count}/5", background='gold')
    # Update for the operator OpQ - KD4SIR for FD 2014
    if operator == "":
        coin2 = "Contestant"
        opmb.config(text=coin2, background='red')
        opds.config(text="<Select Contestant>", background='red')
    else:
        coin = exin(operator)
        tails, dummy, dummy, dummy = str(operator).split(",")
        # print("tails is %s" % tails)
        if coin in qpop:
            coin2 = qpop['%s' % coin]
            opmb.config(text='Contacts: %2s' % coin2, background='light gray')
            opds.config(text=tails, background='light gray')
        else:
            coin2 = "0"
            opmb.config(text='Contacts: %2s' % coin2, background='light gray')
            opds.config(text=tails, background='light gray')
    # Update for the logger LoQ - KD4SIR for FD 2014
    if logger == "":
        coil2 = "Logger"
        logmb.config(text=coil2, background='red')
        logds.config(text="<Select Logger>", background='red')
    else:
        coil = exin(logger)
        heads, dummy, dummy, dummy = str(logger).split(",")
        if coil in qplg:
            coil2 = qplg['%s' % coil]
            logmb.config(text='Logs: %2s' % coil2, background='light gray')
            logds.config(text=heads, background='light gray')
        else:
            coil2 = "0"
            logmb.config(text='Logs: %2s' % coil2, background='light gray')
            logds.config(text=heads, background='light gray')
    t = ""  # check for net config trouble
    if net.fills:
        t = "NEED FILL"
    if net.badauth_rcvd:
        net.badauth_rcvd = 0
        t = "AUTH FAIL"
    if net.pkts_rcvd:
        net.pkts_rcvd = 0
    else:
        # Firewall wording added back by Curtis E. Mills WE7U 25Jun2019
        t = "Alone? Not receiving data from others. (firewall?)"
    if net.send_errs:
        t = "SEND FAIL - Not sending data to others. (firewall?)"
        net.send_errs = 0
    if authk == '':
        t = "NO AUTHKEY SELECTED"
    if node == '':
        t = "NO NODE SELECTED"
    if t:
        lblnet.config(text=t, background='gold')
    else:
        lblnet.config(text="Network OK", background='light gray')


def bandbuttons(w):
    """create band buttons"""
    a = 0
    sv = StringVar()
    sv.set(band)
    mac = os.name == 'posix'  # detect the Mac added 152i
    for i29 in bands:
        b = 0
        for j5 in modes:
            bm4 = "%s%s" % (i29, j5)
            if i29 == 'off':
                bm4 = 'off'
                # indicatoron = 0 makes square button with text inside but doesn't work well on Mac,
                # with value 1 it makes a circle alongside the text and works on both so detect
                # Mac and change it for Mac only
                bandb[bm4] = Radiobutton(master=w, text=bm4, font=fdfont, background='light gray', indicatoron=mac,
                                         variable=sv, value=bm4, selectcolor='red',
                                         command=lambda b03=bm4: (bandset(b03)))
            else:  # This creates all the buttons for band/mode.
                bandb[bm4] = Radiobutton(master=w, text=bm4, font=fdfont, background='light gray', indicatoron=mac,
                                         variable=sv, value=bm4, selectcolor='red',
                                         command=lambda b04=bm4: (bandset(b04)))
                buttonbinder(bm4)  # Added to have each button have a binding - Scott Hibbs KD4SIR 13Aug2022
            bandb[bm4].grid(row=b, column=a, sticky=NSEW)
            b += 1
        a += 1
    for i29, j5, dummy in (('Class', 0, 5),
                           ('VHF', 1, 13),
                           ('GOTA', 2, 9)):
        bandb[i29] = Button(w, text=i29, font=fdfont)
        bandb[i29].grid(row=j5, column=a, sticky=NSEW)
    w.grid_columnconfigure(a, weight=1)
    a += 1
    for i29, j5 in (('FonQ', 0),
                    ('CW/D', 1),
                    ('GOTAq', 2)):
        bandb[i29] = Button(w, text=i29, font=fdfont)
        bandb[i29].grid(row=j5, column=a, sticky=NSEW)
    w.grid_columnconfigure(a, weight=1)


_band_tooltip = None  # current tooltip window

def _band_tooltip_show(widget, text):
    """Show a tooltip popup near the given widget."""
    global _band_tooltip
    _band_tooltip_hide()
    tw = Toplevel(widget)
    tw.wm_overrideredirect(True)
    # Position below and to the right of the mouse cursor
    x = widget.winfo_rootx() + widget.winfo_width()
    y = widget.winfo_rooty() + widget.winfo_height()
    tw.wm_geometry(f"+{x}+{y}")
    label = Label(tw, text=text, font=fdfont, justify='left',
                  background='lightyellow', foreground='black',
                  relief='solid', borderwidth=1, padx=4, pady=2)
    label.pack()
    _band_tooltip = tw

def _band_tooltip_hide(event=None):
    """Destroy the current tooltip if any."""
    global _band_tooltip
    if _band_tooltip:
        _band_tooltip.destroy()
        _band_tooltip = None


def buttonbinder(bmz):
    """ This adds the individual bindings for the band/mode buttons."""
    # Added by Scott Hibbs KD4SIR 13Aug2022
    bandb[bmz].bind("<Enter>", lambda event: whosonfirstyes(bmz, event), add='+')
    bandb[bmz].bind("<Leave>", _band_tooltip_hide, add='+')


def whosonfirstyes(naturally, event=None):
    """ This displays the information for who is on which band/mode."""
    # Added by Scott Hibbs KD4SIR 13Aug2022
    # naturally is the label button the mouse is over.
    d = {}
    woflist = []
    for t in list(net.si.nodinfo.values()):
        dummy1, dummy1, age6 = d.get(t.nod, ('', '', 9999))
        if age6 > t.age:
            if t.age < 25:
                d[t.nod] = (t.bnd, t.msc, t.age)
    for t in d:
        bnd, msc, age = d[t]
        if bnd and bnd != "off" and bnd == naturally:
            woflist.append(t)
    if woflist:
        lines = ["Node     Band Opr/Lgr/Pwr        Last"]
        for what in woflist:
            lines.append("%8s %4s %-18s %4s" % (what, d[what][0], d[what][1], d[what][2]))
        widget = event.widget if event else bandb.get(naturally)
        if widget:
            _band_tooltip_show(widget, "\n".join(lines))


def rndlet():
    return chr(random.randrange(ord('a'), ord('z') + 1))


def rnddig():
    return chr(random.randrange(ord('0'), ord('9') + 1))


def autoksetter(n):
    """ This is the minutes set before autokicker activates"""
    global kick
    kick = n
    globDb.put('kick', n)
    qdb.globalshare('kick', n)  # global to db


def autokicker():
    """ This kicks band to off for inactivity - checked every 10 seconds"""
    global kick, acttime
    if band != "off":
        digkick = int(kick)
        if digkick != 0:
            if digkick < acttime:
                bandset("off")
                txtbillb.insert(END, "\n ~~~~~ Kicked off band for inactivity ~~~~~")
                topper()


def testqgen(n):
    # Scott A Hibbs KD4SIR 07/25/2013
    # added if authk protection so that .testqgen only operates with a 'tst' database.
    # no funny business with the contest log
    if authk == "tst":
        while n:
            call13 = rndlet() + rndlet() + rnddig() + rndlet() + rndlet() + rndlet()
            rpt = rnddig() + rndlet() + ' ' + rndlet() + rndlet() + ' testQ'
            print(call13, rpt)
            n -= 1
            qdb.qsl(now(), call13, band, rpt)
            time.sleep(0.1)
    else:
        txtbillb.insert(END, "This command only available while testing with tst.")


def testcmd(name8, rex, _):
    """set global from command, return value and change status"""
    global kbuf
    value = default  # added in 152i
    s = "%s +(%s)$" % (name8, rex)
    m10 = re.match(s, kbuf)
    if m10:
        value = m10.group(1)
        txtbillb.insert(END, "\n%s set to %s\n" % (name8, value))
        kbuf = ""
        topper()
    return value, default != value


def setoper(op):
    """set operator"""
    # Added global operatorsonline dictionary to track operators - KD4SIR Scott Hibbs 27Nov2023
    global operator, operatorsonline, node
    # print("op:", op)
    ini, name9, call14, age7, vist3 = str.split(op, ', ')
    # print("op:", op)
    # print("operator:", operator)
    if op or operator == "":
        pass
    else:
        if op != operator:
            operatorsonline.pop(node)
    operator = "%s: %s, %s, %s, %s" % (ini, name9, call14, age7, vist3)
    operatorsonline.update({node: ini})
    net.bc_user(node, operator, logger, band)
    # Adding red to the display - KD4SIR
    operatorcolor = 'light gray'
    opds.config(text=operator, background=operatorcolor)
    opmb.config(background='gold')
    saveglob()
    buildmenus()


def setlog(logr):
    """set logger"""
    global logger
    # print "setlog",logr
    ini, name10, call15, age8, vist4 = str.split(logr, ', ')
    logger = "%s: %s, %s, %s, %s" % (ini, name10, call15, age8, vist4)
    loggercolor = 'light gray'
    logds.config(text=logger, background=loggercolor)
    logmb.config(background='gold')
    saveglob()


def clearoper():
    """Clear the current contestant selection."""
    global operator, operatorsonline, node
    if operator:
        operatorsonline.pop(node, None)
    operator = ""
    bandset('off')
    net.bc_user(node, operator, logger, band)
    opds.config(text="<Select Contestant>", background='red')
    opmb.config(text='Contestant', background='red')
    saveglob()
    buildmenus()


def clearlog():
    """Clear the current logger selection."""
    global logger
    logger = ""
    logds.config(text="<Select Logger>", background='red')
    logmb.config(text='Logger', background='red')
    saveglob()


def buildmenus():
    global operator, operatorsonline
    opdsu.delete(0, END)
    logdsu.delete(0, END)
    lparticipants = (list(participants.values()))
    lparticipants.sort()
    # moved to top and added color. - Scott Hibbs KD4SIR 23Aug2022
    opdsu.add_command(label="Empty Contestant", background='yellow', command=clearoper)
    opdsu.add_command(label="Add New Contestant", background='green', command=newpart.dialog)
    logdsu.add_command(label="Empty Logger", background='yellow', command=clearlog)
    logdsu.add_command(label="Add New Logger",  background='green', command=newpart.dialog)
    for i30 in lparticipants:
        # Removed the $ which looks for the end of value - Scott Hibbs KD4SIR 2/12/2017
        '''
                The Operator field caused debate on if the person was Control Operator. We made a version that 
                required a license for the operator. The problem then, was that a ham & non-ham pair had no idea 
                who operated the radio or logged since it could only be entered one way. The ham got credit for 
                contacts while logging and the non-ham had no idea the number they logged or contacted 
                (added together). So the Radio Operator and Control Operator are different and confusing. Non-hams 
                are after all allowed and encouraged to operate with a Control Operator listed as logger. This 
                program has always tracked who's the logger. So the Operator field is renamed Contestant for person 
                at radio. Thus, we can track the number of contacts or data entries, and accurate logs for everyone, 
                even for non-hams. Hams can accurately know how many contacts they worked and logged for themselves 
                or someone else and know who. This maintains a score for contacts and a score for logging them. 
                The program will check for a Control Operator (license needed for Contestant or logger) 
                before allowing a contact. - Scott Hibbs KD4SIR Mar/29/2017
        '''
        #  Removed anyone as operator of a node from the drop-down list - can't operate two radios - Kd4SIR 28Nov2023
        whos_this_now = str(i30).split(',', 1)[0]  # whose turn is i30
        # this prints the operator participants
        if whos_this_now in operatorsonline.values():
            pass
        else:
            opdsu.add_command(label=i30, command=lambda n=i30: (setoper(n)))
        # this prints the logger participants
        logdsu.add_command(label=i30, command=lambda n=i30: (setlog(n)))


def get_max_power_for_class():
    """Return maximum power in watts based on Field Day class.

    Per ARRL Field Day 2026 rules:
    - Classes A, B, C: 500 watts PEP max
    - Classes D, E, F: 100 watts PEP max
    - QRP entries: 5 watts max (user must self-limit)
    """
    fd_class = str.upper(gd.getv('class'))[-1:] if gd.getv('class') else ''
    if fd_class in ('A', 'B', 'C'):
        return 500
    else:  # D, E, F and any other classes default to 100W
        return 100


def ckpowr():
    """ Power settings"""
    global power
    max_power = get_max_power_for_class()
    pwr = ival(pwrnt.get())
    if pwr < 0:
        pwr = "0"
    elif pwr > max_power:
        pwr = str(max_power)
    pwrnt.delete(0, END)
    pwrnt.insert(END, pwr)
    if natv.get():
        pwr = "%sn" % pwr
    else:
        pwr = "%s" % pwr
    power = pwr
    if power == "0":
        pcolor1 = 'red'
        pwrmb.config(background=pcolor1)
        pwrnt.config(background=pcolor1)
        powcb.config(background=pcolor1)
        powlbl.config(background=pcolor1)
    else:
        pcolor1 = 'light gray'
        pwrmb.config(background=pcolor1)
        pwrnt.config(background=pcolor1)
        powcb.config(background=pcolor1)
        powlbl.config(background=pcolor1)
    if power == "0n":
        pcolor1 = 'red'
        pwrmb.config(background=pcolor1)
        pwrnt.config(background=pcolor1)
        powcb.config(background=pcolor1)
        powlbl.config(background=pcolor1)
    else:
        # pcolor == 'light gray' # Statement has no effect
        pwrmb.config(background=pcolor1)
        pwrnt.config(background=pcolor1)
        powcb.config(background=pcolor1)
        powlbl.config(background=pcolor1)
    print('power', power)
    return True


def setpwr(p4):
    global power
    max_power = get_max_power_for_class()
    pwri = ival(p4)
    is_natural = p4[-1:] == 'n'
    # Enforce class-based power limit
    if pwri > max_power:
        pwri = max_power
        print(f"Power capped to {max_power}W for your Field Day class")
    pwr = str(pwri)
    pwrnt.delete(0, END)
    pwrnt.insert(END, pwr)
    if is_natural:
        powcb.select()
        power = pwr + 'n'
    else:
        powcb.deselect()
        power = pwr
    if power == "0":
        pcolor2 = 'red'
        pwrmb.config(background=pcolor2)
        pwrnt.config(background=pcolor2)
        powcb.config(background=pcolor2)
        powlbl.config(background=pcolor2)
    else:
        pcolor2 = 'light gray'
        pwrmb.config(background=pcolor2)
        pwrnt.config(background=pcolor2)
        powcb.config(background=pcolor2)
        powlbl.config(background=pcolor2)
    if power == "0n":
        pcolor2 = 'red'
        pwrmb.config(background=pcolor2)
        pwrnt.config(background=pcolor2)
        powcb.config(background=pcolor2)
        powlbl.config(background=pcolor2)
    else:
        pwrmb.config(background=pcolor2)
        pwrnt.config(background=pcolor2)
        powcb.config(background=pcolor2)
        powlbl.config(background=pcolor2)


def topper():
    """This will reset the display for input. Added Jul/01/2016 KD4SIR Scott Hibbs"""
    txtbillb.config(font=fdfont)
    txtbillb.insert(END, "\n")
    if authk == "tst":
        txtbillb.insert(END, "-Call-Class-Sect-  (.testq <n> to generate test QSOs)\n")
    else:
        txtbillb.insert(END, "-Call-Class-Sect- \n")
    txtbillb.see(END)  # added to always show the bottom line. Scott Hibbs KD4SIR 08Jul2022


def showthiscall(call16):
    """show the log entries for this call"""
    p5 = call16.split('/')
    #    print p[0]
    findany = 0
    m11, dummy, dummy = qdb.cleanlog()
    #    print m.values()
    for i31 in list(m11.values()):
        # print(i31.call)
        q = i31.call.split('/')
        # print(q)
        if p5[0] == q[0]:
            if findany == 0:
                txtbillb.insert(END, "\n")
            txtbillb.insert(END, "%s\n" % i31.prlogln(i31))
            findany = 1
    return findany


def showthiscall2(call16a):
    """used by proc_key function to show the log entries for this call and return the previous report"""
    # Added by Scott Hibbs KD4SIR 02Aug2022
    repta = ""
    pa5 = call16a.split('/')
    findanya = 0
    ma11, dummy, dummy = qdb.cleanlog()
    for ia31 in list(ma11.values()):
        # print(ia31.call)
        qa = ia31.call.split('/')
        ra = ia31.rept.split('/')
        if pa5[0] == qa[0]:
            repta = ra
            if findanya == 0:
                txtbillb.insert(END, "\n")
            txtbillb.insert(END, "%s\n" % ia31.prlogln(ia31))
            findanya = 1
    return findanya, repta


def showoperatorsonline():
    # Build node-to-band lookup from net status info
    node_bands = {}
    try:
        for t in list(net.si.nodinfo.values()):
            prev_age = node_bands.get(t.nod, ('', 9999))[1]
            if prev_age > t.age:
                node_bands[t.nod] = (t.bnd, t.age)
    except Exception:
        pass
    # Local node always has current band
    node_bands[node] = (band, 0)

    for node_name, op_init in operatorsonline.items():
        # Look up full name from participants
        pinfo = participants.get(op_init, '')
        if pinfo:
            parts = pinfo.split(', ')
            # Format: "INI, Name, Call, Age, Vist"
            name_str = parts[1] if len(parts) > 1 else op_init
        else:
            name_str = op_init
        # Get band for this node
        node_band = node_bands.get(node_name, ('', 9999))[0]
        band_str = f" on {node_band}" if node_band and node_band != 'off' else ""
        txtbillb.insert(END, "\n")
        txtbillb.insert(END, f"{node_name}: {op_init}, {name_str}{band_str}\n")
    topper()


def mhelp():
    """ added this to take out key help from the code - Scott Hibbs"""
    viewtextf('Keyhelp.txt')


def readsections():
    """this will read the Arrl_sections_ref.txt file for sections"""
    # This modified from Alan Biocca FDLog version 153d - Scott Hibbs Feb/6/2017
    try:
        fd = open("Arrl_sections_ref.txt", "r")  # read section data
        while 1:
            ln = fd.readline().strip()  # read a line and put in db
            if not ln:
                break
            if ln[0] == '#':
                continue
            try:
                sec, dummy, dummy, dummy = str.split(ln, " ", 3)
                secName[sec] = sec
            except ValueError as e02:
                print("read Arrl section data error, item skipped: ", e02)
        fd.close()
    except IOError as e02:
        print("read error during readSections", e02)


def proc_key(ch):
    """process keystroke"""
    #  Changes need to be made in proc_key(ch) and pasteinterpreter()
    global stat, kbuf, power, operator, logger, debug, band, node, suffix, tdwin, goBack, kick
    testq = 0
    if ch == '?' and (kbuf == "" or kbuf[0] != '#'):  # ? for help
        mhelp()
        return
    # Adding a statement to check for uppercase. Previously unresponsive while capped locked. - Scott Hibbs Jul/01/2016
    # Thanks to WW9A Brian Smith for pointing out that the program isn't randomly frozen and not requiring a restart.
    if ch.isupper():
        # Allowing uppercase for QST messages. - Scott Hibbs KD4SIR 05Aug2022
        if kbuf[0] != '#':
            txtbillb.insert(END, " LOWERCAPS PLEASE \n")
            kbuf = ""
            topper()
            return
    if ch == '\r':  # return, may be cmd or log entry
        if kbuf[:1] == '#':  # QST Message
            qdb.qst(kbuf[1:])
            kbuf = ""
            topper()
            return
        # check for valid commands
        if re.match(r'[.]h$', kbuf):  # help request
            m12 = """
                .band 160/80/40/20/15/10/6/2/220/440/900/1200/sat c/d/p
                .off               change band to off
                .pow <dddn>        power level in integer watts (suffix n for natural)
                .node <call-n>     set id of this log node
                .kick <n>          minutes to kick inactivity
                .testq <n>         generate n test qsos (only in test mode)
                .tdwin <sec>       display node bcasts exceeding this time skew
                .st                this station status
                .re                summary band report
                .ba                station band report
                .pr                generate entry and log files
                """
            viewtextv(m12, 'Command Help')
            kbuf = ""
            txtbillb.insert(END, '\n')
            return
        # This section was reworked and added from 152i
        pwr, s = testcmd(".pow", r"\d{1,4}n?", power)
        if s is True:
            power = pwr
            setpwr(power)
        NetworkSync.rem_host, s = testcmd('.remip', r'(\d{1,3}[.]){3}\d{1,3}', NetworkSync.rem_host)
        if s:
            globDb.put('remip', NetworkSync.rem_host)
        # This change was made below for debug, tdwin, and testq
        # Scott Hibbs 7/16/2015
        v, s = testcmd(".debug", r"\d+", debug)
        if s is True:
            debug = int(v)
        v, s = testcmd(".tdwin", r"\d{1,3}", tdwin)
        if s is True:
            tdwin = int(v)
        v, s = testcmd(".testq", r"\d{1,2}", testq)
        if s is True:
            testq = int(v)
        if testq:
            testqgen(testq)
        saveglob()
        renew_title()
        if kbuf.strip() == '.set adminpin':
            kbuf = ""
            topper()
            _adminpin_dlg = Toplevel(root)
            _adminpin_dlg.transient(root)
            _adminpin_dlg.title('Set Admin PIN')
            _adminpin_dlg.grab_set()
            _ap_row = 0
            _existing_hash = globDb.get('adminpin', '')
            if _existing_hash:
                Label(_adminpin_dlg, text='Current PIN:', font=fdfont).grid(row=_ap_row, column=0, padx=5, pady=2)
                _old_pin_e = Entry(_adminpin_dlg, width=6, font=fdfont, show='*')
                _old_pin_e.grid(row=_ap_row, column=1, padx=5, pady=2)
                _old_pin_e.focus()
                _ap_row += 1
            else:
                _old_pin_e = None
            Label(_adminpin_dlg, text='New PIN:', font=fdfont).grid(row=_ap_row, column=0, padx=5, pady=2)
            _new_pin_e = Entry(_adminpin_dlg, width=6, font=fdfont, show='*')
            _new_pin_e.grid(row=_ap_row, column=1, padx=5, pady=2)
            if not _old_pin_e:
                _new_pin_e.focus()
            _ap_row += 1
            Label(_adminpin_dlg, text='Confirm PIN:', font=fdfont).grid(row=_ap_row, column=0, padx=5, pady=2)
            _conf_pin_e = Entry(_adminpin_dlg, width=6, font=fdfont, show='*')
            _conf_pin_e.grid(row=_ap_row, column=1, padx=5, pady=2)
            _ap_row += 1
            _ap_msg = Label(_adminpin_dlg, text='', font=fdfont, fg='red')
            _ap_msg.grid(row=_ap_row, column=0, columnspan=2)
            _ap_row += 1

            def _ap_save():
                if _old_pin_e:
                    old_hash = hashlib.md5(_old_pin_e.get().strip().encode()).hexdigest()
                    if old_hash != _existing_hash:
                        _ap_msg.config(text='Current PIN incorrect')
                        return
                np = _new_pin_e.get().strip()
                cp = _conf_pin_e.get().strip()
                if not re.match(r'^\d{4}$', np):
                    _ap_msg.config(text='PIN must be exactly 4 digits')
                    return
                if np != cp:
                    _ap_msg.config(text='PINs do not match')
                    return
                hashed = hashlib.md5(np.encode()).hexdigest()
                globDb.put('adminpin', hashed)
                qdb.globalshare('adminpin', hashed)
                txtbillb.insert(END, "\nAdmin PIN updated.\n")
                txtbillb.see(END)
                _adminpin_dlg.destroy()

            Button(_adminpin_dlg, text='Save', font=fdfont, command=_ap_save).grid(row=_ap_row, column=0, pady=5)
            Button(_adminpin_dlg, text='Cancel', font=fdfont, command=_adminpin_dlg.destroy).grid(row=_ap_row, column=1, pady=5)
            return
        m12 = re.match(r"[.]set ([a-z\d]{3,6}) (.*)$", kbuf)
        if m12:
            name12, val = m12.group(1, 2)  # command and number
            # Added time out for inactivity - Scott Hibbs KD4SIR 10Aug2022
            if name12 == "kick":
                autoksetter(val)
                kbuf = ""
                topper()
                return
            # Added gentle reminder not to use .set for these commands - Scott Hibbs KD4SIR 10Aug2022
            if name12 == "debug":
                txtbillb.insert(END, "\n Don't use .set - type .debug instead.\n")
                kbuf = ""
                topper()
                return
            if name12 == "tdwin":
                txtbillb.insert(END, "\n Don't use .set - type .tdwin instead.\n")
                kbuf = ""
                topper()
                return
            if name12 == "testq":
                txtbillb.insert(END, "\n Don't use .set - type .testq instead.\n")
                kbuf = ""
                topper()
                return
            r = gd.setv(name12, val, now())
            if r:
                txtbillb.insert(END, "\n%s\n" % r)
            else:
                txtbillb.insert(END, "\n")
                qdb.globalshare(name12, val)  # global to db
            kbuf = ""
            renew_title()
            topper()
            return
        m12 = re.match(r"[.]band (((160|80|40|20|15|10|6|2|220|440|900|1200|sat)[cdp])|off)", kbuf)
        if m12:
            print()
            nb = m12.group(1)
            kbuf = ""
            txtbillb.insert(END, "\n")
            bandset(nb)
            return
        if re.match(r'[.]off$', kbuf):
            bandoff()
            kbuf = ""
            txtbillb.insert(END, "\n")
            return
        if re.match(r'[.]ba$', kbuf):
            qdb.status_so_far()
            kbuf = ""
            txtbillb.insert(END, "\n")
            return
        if re.match(r'[.]pr$', kbuf):
            contestlog(1)
            txtbillb.insert(END, " Entry/Log File Written\n")
            txtbillb.insert(END, "\n")
            kbuf = ""
            return
        p6 = r'[.]edit ([a-z\d]{1,6})'
        if re.match(p6, kbuf):
            #  m12 = re.match(p6, kbuf)  # not used?
            #  call = m12.group(1)  # not used?
            #  qdb.qdelete(nod,seq,reason)
            kbuf = ""
            txtbillb.insert(END, "To edit: click on the log entry\n")
            return
        # Found that .node needed fixing. Reworked - Scott Hibbs Mar/28/2017
        if re.match(r'[.]node', kbuf):
            if band != 'off':
                txtbillb.insert(END, "\nSet band off before changing node id\n")
                kbuf = ""
                return
            else:
                nde, s = testcmd(".node", r"[a-z\d-]{1,8}", node)
                if s is True:
                    node = nde
                    setnode(node)
            kbuf = ""
            txtbillb.insert(END, "\n")
            topper()
            return
        if re.match(r'[.]st$', kbuf):  # status  xx mv to gui
            print()
            print()
            print("FD Call   %s" % str.upper(gd.getv('fdcall')))
            print("GOTA Call %s" % str.upper(gd.getv('gcall')))
            print("FD Report %s %s" % (str.upper(gd.getv('class')), gd.getv('sect')))
            print("Band      %s" % band)
            print("Power     %s" % power)
            print("Contestnt %s" % operator)
            print("Logger    %s" % logger)
            print("Node      %s" % node)
            if authk != "" and node != "":
                print("Net       enabled")
            else:
                print("Net       disabled")
            print()
            kbuf = ""
            txtbillb.insert(END, "\n")
            return
        if re.match(r'[.]re$', kbuf):  # report  xx mv to gui
            print()
            print("  band  cw q   pwr dig q   pwr fon q   pwr")
            qpb, ppb, dummy, dummy, dummy, tq, score, maxp, dummy, dummy, dummy, dummy, dummy, \
                dummy, dummy = qdb.band_rpt()
            for b in (160, 80, 40, 20, 15, 10, 6, 2, 220, 440, 1200, 'sat', 'gota'):
                print("%6s" % b, end=' ')
                for m12 in 'cdp':
                    bm5 = "%s%s" % (b, m12)
                    print("%5s %5s" % (qpb.get(bm5, 0), ppb.get(bm5, 0)), end=' ')
                print()
            print()
            print("%s total Qs, %s QSO points," % (tq, score), end=' ')
            print(maxp, "watts maximum power")
            kbuf = ""
            txtbillb.insert(END, "\n")
            topper()
            return
        # Time Master command - .tmast [status|clear|elect|<nodename>]
        if re.match(r'[.]tmast', kbuf):
            parts = kbuf.strip().split()
            tmast_val = gd.getv('tmast')
            if isinstance(tmast_val, str) and tmast_val.startswith('get error'):
                tmast_val = ''
            telect_val = gd.getv('telect')
            if isinstance(telect_val, str) and telect_val.startswith('get error'):
                telect_val = ''

            def check_node_online(nname):
                if not nname:
                    return False
                nname_lower = str.lower(nname)
                if nname_lower == str.lower(node):
                    return True
                for ni in net.si.nodes.values():
                    if ni.age < 60 and ni.nod and str.lower(ni.nod) == nname_lower:
                        return True
                return False

            if len(parts) == 1:  # .tmast - show status
                txtbillb.insert(END, "\n--- Time Master Status ---\n")
                # Show designated master
                if tmast_val:
                    online = "online" if check_node_online(tmast_val) else "OFFLINE"
                    txtbillb.insert(END, "  tmast (designated): %s (%s)\n" % (tmast_val, online))
                else:
                    txtbillb.insert(END, "  tmast (designated): (none)\n")
                # Show elected master
                if telect_val == "election":
                    txtbillb.insert(END, "  telect (elected):   ELECTION IN PROGRESS\n")
                elif telect_val:
                    online = "online" if check_node_online(telect_val) else "OFFLINE"
                    txtbillb.insert(END, "  telect (elected):   %s (%s)\n" % (telect_val, online))
                else:
                    txtbillb.insert(END, "  telect (elected):   (none)\n")
                # Show this node's status
                txtbillb.insert(END, "  This node: %s, level %d\n" % (node, mclock.level))
                # Show role
                role_map = {
                    'designated': 'DESIGNATED TIME MASTER',
                    'ntp': 'NTP-synced',
                    'elected': 'ELECTED TIME MASTER',
                    'synced': 'Time client',
                    'none': 'Unsynchronized'
                }
                role = role_map.get(mclock._source_type, 'Unknown')
                txtbillb.insert(END, "  Role: %s\n" % role)
                # Show judge status
                is_judge = mclock._am_i_judge()
                txtbillb.insert(END, "  Election judge: %s\n" % ("YES (this node)" if is_judge else "No"))
                # Show time source info
                if mclock.gps_locked:
                    txtbillb.insert(END, "  GPS: locked\n")
                if mclock.ntp_ok:
                    txtbillb.insert(END, "  NTP: synced (offset %.3fs)\n" % (mclock.ntp_offset or 0))
                if mclock.ntp_servers:
                    txtbillb.insert(END, "  NTP server: %s\n" % mclock.ntp_servers[0])
                shared_ntp = gd.getv('tntp')
                if isinstance(shared_ntp, str) and shared_ntp and not shared_ntp.startswith('get error'):
                    txtbillb.insert(END, "  Shared NTP: %s\n" % shared_ntp)
                if mclock._source_type == 'synced' and mclock.src_node:
                    txtbillb.insert(END, "  Syncing from: %s (level %d)\n" % (mclock.src_node, mclock.srclev))
                txtbillb.insert(END, "  No-master cycles: %d (election at 3)\n" % mclock._no_master_cycles)
                # Show active nodes
                active = [node]
                for ni in net.si.nodes.values():
                    if ni.age < 60 and ni.nod and ni.nod != node:
                        active.append(ni.nod)
                txtbillb.insert(END, "  Active nodes: %s\n" % ', '.join(active))
            elif parts[1] == 'clear':  # .tmast clear - remove designation
                globDb.put('tmast', '')
                qdb.globalshare('tmast', '')
                globDb.put('telect', '')
                qdb.globalshare('telect', '')
                mclock._election_pending = False
                txtbillb.insert(END, "\nTime master designation cleared.\n")
                txtbillb.insert(END, "Election will occur when judge detects no master.\n")
            elif parts[1] == 'elect':  # .tmast elect - force election
                globDb.put('telect', 'election')
                qdb.globalshare('telect', 'election')
                mclock._election_pending = True
                mclock._election_start_time = time.monotonic()
                txtbillb.insert(END, "\nElection triggered. Judge will announce winner.\n")
            elif parts[1] == 'me':  # .tmast me - set this node
                globDb.put('tmast', node)
                qdb.globalshare('tmast', node)
                txtbillb.insert(END, "\nThis node (%s) set as time master.\n" % node)
            else:  # .tmast <nodename> - set specific node
                new_tmast = parts[1]
                if check_node_online(new_tmast):
                    globDb.put('tmast', new_tmast)
                    qdb.globalshare('tmast', new_tmast)
                    txtbillb.insert(END, "\nTime master set to: %s\n" % new_tmast)
                else:
                    txtbillb.insert(END, "\nWarning: Node '%s' not found on network.\n" % new_tmast)
                    txtbillb.insert(END, "Set anyway? Use: .set tmast %s\n" % new_tmast)
            kbuf = ""
            topper()
            return
        if kbuf and kbuf[0] == '.':  # detect invalid command
            txtbillb.insert(END, " Invalid Command\n")
            kbuf = ""
            txtbillb.insert(END, "\n")
            topper()
            return
        # check for valid contact
        if ch == '\r':
            stat, ftm, dummy, sfx, call17, xcall, rept = qdb.qparse(kbuf)
            goBack = "%s %s" % (call17, rept)  # for the up arrow enhancement - Scott Hibbs KD4SIR Jul/5/2018
            if stat == 5:  # whole qso parsed
                kbuf = ""
                if len(node) < 3:
                    txtbillb.insert(END, " ERROR, set .node <call> before logging\n")
                    topper()
                elif qdb.dupck(xcall, band):  # dupe check
                    txtbillb.insert(END, "\n\n DUPE on band %s\n" % band)
                    if sound_enabled.get(): root.bell()  # Audio notification for dupe
                    topper()
                elif qdb.partck(xcall):  # Participant check
                    txtbillb.insert(END, "\n Participant - not allowed \n")
                    topper()
                elif xcall == str.lower(gd.getv('fdcall')):
                    txtbillb.insert(END, "\n That's us - not allowed \n")
                    topper()
                elif xcall == str.lower(gd.getv('gcall')):
                    txtbillb.insert(END, "\n That's us - not allowed \n")
                    topper()
                else:
                    # Added database protection against no band, no power,
                    # no op, and no logger -- KD4SIR Scott Hibbs Jul/15/2013
                    # Checking Contestant or Logger has a license - Scott Hibbs Mar/28/2017
                    legal = 0
                    if re.match(r'[a-z :]+ [a-zA-Z ]+, ([a-z\d]+)', operator):
                        # print "%s has a license" % operator
                        legal = legal + 1
                    if re.match(r'[a-z :]+ [a-zA-Z ]+, ([a-z\d]+)', logger):
                        # print "%s has a license" % logger
                        legal = legal + 1
                    if legal == 0:
                        txtbillb.insert(END, "\n\n  The Contestant or the logger needs a license.\n")
                        txtbillb.insert(END, "  Please Try Again\n")
                        topper()
                        return
                    # checking for band, power, contestant or logger
                    em = ''
                    if band == "off":
                        em += " Band "
                    if power == "0":  # python 3 needs a str not a digit here
                        em += " Power "
                    if len(operator) < 2:
                        em += " Contestant "
                    if len(logger) < 2:
                        em += " Logger "
                    # print("em is ", em)
                    # print("power is ", power)
                    if em != '':
                        txtbillb.insert(END, "\n - WARNING: ( %s ) NOT SET" % em)
                        txtbillb.insert(END, "  Please try again\n")
                        txtbillb.insert(END, "  Correct this and up arrow to retype\n")
                        topper()
                        return
                    if em == "":
                        # This checks 1D to 1D contacts
                        #  clas = str.upper(gd.getv('class'))  # not used
                        rept1 = str.upper(rept)
                        # if clas == '1D': no longer applies due to rule change in 2019.
                        #     if clas in rept1:
                        #         txtbillb.insert(END, "\n 1D to 1D contacts are logged, but zero points! \n")
                        #         topper()
                        # check the report for valid fd or wfd classes - Art Miller KC7SDA
                        try:
                            # these variables are actually used. Don't edit.
                            # noinspection PyUnusedLocal
                            reptclass, reptsec = rept.split(" ")
                        except ValueError:
                            txtbillb.insert(END, "\n - ERROR: incomplete exchange ( %s ) "
                                                 "Correct with up arrow. \n" % rept)
                            topper()
                            return
                        #  m12 = ""
                        if gd.getv('contst') == "fd":
                            # field day, report in: #+a-f
                            m12 = re.match(r'\d[a-fA-F]', rept)
                        elif gd.getv('contst') == "wfd":
                            # WFD
                            m12 = re.match(r'\d[ihoIHO]', rept)
                        else:
                            # vhf or other contest
                            # allow everything
                            m12 = "something"
                        if m12 is None:  # match failed, do not allow and abort logging
                            txtbillb.insert(END, " - ERROR: Bad exchange ( %s ) Please Try Again\n" % rept)
                            topper()
                            return
                        # Check for valid section in report added by Scott Hibbs Feb/6/2017
                        aaaaa = len(rept1)
                        # print "aaaaa is %s" % aaaaa
                        rept2 = rept1[3:aaaaa].strip()
                        # print "rept2 is %s" % rept2
                        if rept2 in secName:
                            pass
                        else:
                            print("\n Use one of these for the section:")
                            kk = ""
                            nx = 0
                            ny = 0
                            for k1 in sorted(secName):
                                if ny == 0:
                                    kk += "\n  "
                                    ny = ny + 1
                                kk += str(k1) + ", "
                                nx = nx + 1
                                if nx == 17:  # how many sections to the line
                                    ny = ny + 1
                                    if ny < 6:  # last line gets the rest
                                        kk += "\n  "
                                        nx = 0
                            print(kk)
                            # print('\n'.join("{} : {}".format(k, v) for k, v in secName.items()))
                            txtbillb.insert(END, kk)
                            txtbillb.insert(END, "\n  Up arrow and correct with another section listed above.")
                            topper()
                            return
                        # The entry is good and ready to log
                        txtbillb.insert(END, " - QSL!  May I have another?")
                        txtbillb.insert(END, "\n")
                        topper()
                        tm = now()
                        if ftm:  # force timestamp
                            tm = tm[0:4] + ftm[0:8] + tm[11:]  # yymmdd.hhmmss
                        qdb.qsl(tm, xcall, band, rept)
            elif stat == 4:
                kbuf = ""
                # Added participant check here too - Feb/12/2017 -Scott Hibbs 
                if qdb.partck(xcall):  # Participant check
                    txtbillb.insert(END, "\n Participant - not allowed \n")
                    topper()
                elif showthiscall(call17) == 0:
                    txtbillb.insert(END, " none found\n")
                    topper()
            return
    if ch == '\x1b':  # escape quits this input line
        txtbillb.insert(END, " ESC -aborted line-\n")
        topper()
        kbuf = ""
        suffix = ""
        return
    if ch == '\b':  # backspace erases char
        if kbuf != "":
            kbuf = kbuf[0:-1]
            txtbillb.delete('end - 2 chars')
        return
    if ch == '\\u1p':  # up arrow reprints the input line - Scott Hibbs KD4SIR Jul/5/2018
        if goBack != "":
            if kbuf == "":
                txtbillb.insert(END, goBack)  # print goBack info
                kbuf = goBack
            else:
                return
        else:
            kbuf = ""
        return
    if ch == ' ':  # space, check for prefix/suffix/call
        stat, tm, dummy, sfx, call17, xcall, rept = qdb.qparse(kbuf)
        if stat == 2:  # suffix, dupe check
            suffix = kbuf
            kbuf = ""
            r = qdb.sfx2call(suffix, band)
            if not r:
                r = 'None'
            txtbillb.insert(END, ": %s on band '%s'\n" % (r, band))
            return
        if stat == 3:  # prefix, search logged calls by prefix
            pfx_results = qdb.pfx2call(kbuf)
            if pfx_results:
                txtbillb.insert(END, "\n")
                for bnd, calls in sorted(pfx_results.items()):
                    unique = sorted(set(calls))
                    txtbillb.insert(END, "  %s: %s\n" % (bnd, ', '.join(unique)))
                topper()
                txtbillb.insert(END, kbuf)  # re-echo prefix so user can continue typing
            else:
                txtbillb.insert(END, ": no calls matching '%s'\n" % kbuf)
                topper()
                txtbillb.insert(END, kbuf)
            # Also try combine with previously stored suffix
            if suffix:
                stat, tm, dummy, sfx, call17, xcall, rept = qdb.qparse(kbuf + suffix)
                if stat == 4:  # whole call
                    kbuf += suffix
                    txtbillb.insert(END, sfx)  # fall into call dup ck
            else:
                return
        if stat == 4:  # whole call, dup chk
            if qdb.dupck(xcall, band):
                showthiscall(call17)
                txtbillb.insert(END, " DUPE ON BAND %s \n" % band)
                kbuf = ""
                topper()
            elif qdb.partck(xcall):  # Participant check
                txtbillb.insert(END, "\n Participant - not allowed \n")
                showthiscall(call17)
                kbuf = ""
                topper()
            else:
                # This displays the previous contacts and put in the previous report too
                # so the logger only has to hit enter. Added by Scott Hibbs KD4SIR 02Aug2022
                kbuf += ' '
                txtbillb.insert(END, ch)
                _dummy, repta = showthiscall2(call17)
                repta = str(repta)
                repta = re.sub(r"[\[\]]", '', repta)
                repta = repta.replace("'", "")
                if showthiscall(call17):  # shows the previous contacts with this station
                    txtbillb.insert(END, " worked on different bands\n")
                    txtbillb.insert(END, "%s %s" % (xcall, repta))
                    kbuf += repta
            return
    buf = kbuf + ch  # echo & add legal char to kbd buf
    if len(buf) < 50:
        if buf[0] == '.':  # dot command
            if re.match(r'[ a-zA-Z\d.,/@-]{0,45}$', ch):
                kbuf = buf
                txtbillb.insert(END, ch)
        elif buf[0] == '#':  # QST Message
            if re.match(r'#[ a-zA-Z\d.,?/!@$;:+=%&()-]{0,40}$', buf):
                kbuf = buf
                txtbillb.insert(END, ch)
        else:
            # print("line 3223 buf is %s" % buf)
            stat, tm, _pfx, sfx, call17, xcall, rept = qdb.qparse(buf)
            if stat > 0:
                kbuf = buf
                # print("line 3227 kbuf is ", kbuf)
                txtbillb.insert(END, ch)
            else:
                print("ignored key")


def kevent(event):
    """keyboard event handler"""
    global goBack
    # print("event '%s' '%s' '%s'" % (event.type, event.keysym, event.keysym_num))
    k2 = event.keysym_num
    # print(chr(k2))
    if 31 < k2 < 123:  # space to z
        proc_key(chr(k2))
    elif k2 == 65362:  # up arrow
        proc_key('\\u1p')
    elif k2 == 65288:  # backspace
        proc_key('\b')
    # Added by Scott Hibbs KD4SIR 05Aug2022
    elif k2 == 65361:  # left arrow acts as backspace
        proc_key('\b')
    elif k2 == 65307:  # ESC
        proc_key('\x1b')
        # Abort based on current band mode
        current_mode = band[-1:] if band != 'off' else ''
        if current_mode == 'p' and VOICE_AVAILABLE:
            voice_stop()
        elif current_mode in ('c', 'd') and CW_AVAILABLE:
            cw_abort()
    elif k2 == 65293:  # return
        proc_key('\r')
    # F-key macros (F1-F12: 65470-65481) - route to Voice or CW based on band mode
    elif 65470 <= k2 <= 65481:
        fkey = f'F{k2 - 65469}'  # F1=65470 -> F1, F12=65481 -> F12
        current_mode = band[-1:] if band != 'off' else ''
        if current_mode == 'p' and VOICE_AVAILABLE:
            voice_send_macro(fkey)
        elif current_mode in ('c', 'd') and CW_AVAILABLE:
            cw_send_macro(fkey)
        elif CW_AVAILABLE:
            cw_send_macro(fkey)
    # CW Speed control (PgUp/PgDn)
    elif k2 == 65365:  # Page Up - speed up
        if CW_AVAILABLE:
            cw_adjust_speed(2)
    elif k2 == 65366:  # Page Down - slow down
        if CW_AVAILABLE:
            cw_adjust_speed(-2)
    #  Added from Alan Biocca (W6AKB) FDLog v4-1-154c-dev during python 3 conversion. 15Jul2022 Scott Hibbs
    #  display key code for unrecognized key
    # else:
    #     print("ignored key ", k2)
    txtbillb.see(END)  # Ensure that it stays in view
    return "break"  # prevent further processing on kbd events


def focevent(_event):
    txtbillb.mark_set('insert', END)
    return "break"


def edit_dialog(node1, seq):
    """edit log entry"""
    _ = EditDialog(root, node1, seq)


def log_select(event):
    """process mouse left-click on log window"""
    #    print e.x,e.y
    t = logw.index("@%d,%d" % (event.x, event.y))
    #    print t
    line, dummy = t.split('.')
    line = int(line)
    #    print line
    logtext = logw.get('%d.0' % line, '%d.82' % line)
    # print logtext
    _dummy = logtext[0:8].strip()  # unused variable.
    seq = logtext[65:69].strip()
    bxnd = logtext[8:14].strip()
    cxll = logtext[15:22].strip()
    cxll2 = logtext[17:24].strip()  # initials of participant.
    #  In case user clicks on a deleted log entry Feb/2/2017 Scott Hibbs
    baddd = logtext[23:24].strip()
    if baddd == '*':
        txtbillb.insert(END, "\n Can't edit a deleted entry.\n")
        topper()
        # print("Can't edit a deleted entry")
        return 'break'
    if len(seq) == 0:
        return 'break'
    #    In case user clicks on tildes - May/11/2014 Scott Hibbs
    if seq == '~~~~':
        return 'break'
    # fixed clicking on the copyright line gave a value error - Feb/12/2017 Scott Hibbs
    try:
        seq = int(seq)
        stn = logtext[69:].strip()
        if len(stn) == 0:
            return 'break'
    except ValueError:
        return 'break'
    #  print(stn, seq, bxnd, cxll)
    if stn == node:  # only edit my own Q's
        # Also check to make sure the call isn't previously deleted. Jul/02/2016 KD4SIR Scott Hibbs
        if qdb.dupck(cxll, bxnd):
            # Now we check to see if the entry is still in the log. Mar/31/2017 KD4SIR Scott Hibbs
            bid, dummy, dummy = qdb.cleanlog()  # get a clean log
            stnseq = stn + "|" + str(seq)
            if stnseq in bid:
                edit_dialog(stn, seq)
            else:
                txtbillb.insert(END, "\n Previously edited contact - Not in the log.\n")
                topper()
                # print("Previously edited contact - Not in the log.")
                return 'break'
        else:
            # Added to click on a participant to delete them. - Scott Hibbs KD4SIR 20Aug2022
            if "p:" in cxll:
                # Check to see if selection is the contestant or logger
                active = 0
                actc = exin(operator)
                actl = exin(logger)
                if cxll2 == actc:
                    active += 1
                if cxll2 == actl:
                    active += 1
                if active != 0:
                    txtbillb.insert(END, "\n Can't delete current contestant or logger.\n")
                    topper()
                    return 'break'
                else:
                    # Check to see if participant has contacts in the log.
                    dummy, dummy, qpop, qplg, dummy, dummy, dummy, dummy, dummy, dummy, \
                        dummy, dummy, dummy, dummy, dummy = qdb.band_rpt()
                    if cxll2 in qpop or cxll2 in qplg:
                        pnts = "yes"
                    else:
                        pnts = "no"
                    if pnts == "no":
                        seq = int(seq)
                        stn = logtext[69:].strip()
                        deledialog(cxll2, seq, stn)
                    else:
                        txtbillb.insert(END, "\n Can't delete: %s has contacts in the log." % cxll2)
                        txtbillb.insert(END, "  Please edit the log and try again.\n")
                        topper()
                        return 'break'
            else:
                txtbillb.insert(END, "\n This is not a log entry.\n")
                topper()
                # print("This is not a log entry.")
    else:
        txtbillb.insert(END, "\n Cannot edit another person's contact.\n")
        topper()
        # print("Cannot edit another person's contact.")
    return 'break'


def mouse_popup(event):
    """Copy and Paste functions"""
    #  txtbillb.bind('<Button-3>', mouse_popup) # Binds the right click function in the main program
    #  modified from www.stackoverflow.com by Delrius Euphoria 07Mar2021 - Added by Scott Hibbs KD4SIR 07Jul2022
    local_menu1 = Menu(root, tearoff=0)  # Create a menu
    local_menu1.add_command(label='Copy', command=lambda: copy(False))  # Create label and commands
    local_menu1.add_command(label='Paste', command=lambda: paste(False))  # Create label and commands
    try:
        local_menu1.tk_popup(event.x_root, event.y_root)  # Pop the menu up in the given coordinates
    finally:
        local_menu1.grab_release()  # Release it once an option is selected


def pasteinterpreter():
    """Needed for mouse paste event"""
    #  The program needs to interpret the paste event. Added by KD4SIR Scott Hibbs 08Jul2022
    #  Changes need to be made in proc_key(ch) and pasteinterpreter()
    global stat, kbuf, power, operator, logger, debug, band, node, suffix, tdwin, goBack, selected
    txtbillb.insert(END, selected)
    for pastebuf in selected:
        if pastebuf.isupper():
            txtbillb.insert(END, "\n LOWERCAPS PLEASE \n")
            txtbillb.insert(END, "Paste must be in -Call-Class-Sect- format only\n")
            kbuf = ""
            topper()
            return
    stat, ftm, pfx, sfx, call18, xcall, rept = 0, '', '', '', '', '', ''
    stat, ftm, pfx, sfx, call18, xcall, rept = qdb.qparse(selected)
    goBack = "%s %s" % (call18, rept)  # for the up arrow enhancement - Scott Hibbs KD4SIR Jul/5/2018
    if stat == 5:  # whole qso parsed
        kbuf = ""
        if len(node) < 3:
            txtbillb.insert(END, " ERROR, set .node <call> before logging\n")
            topper()
        elif qdb.dupck(xcall, band):  # dupe check
            txtbillb.insert(END, "\n\n DUPE on band %s\n" % band)
            if sound_enabled.get(): root.bell()  # Audio notification for dupe
            topper()
        elif qdb.partck(xcall):  # Participant check
            txtbillb.insert(END, "\n Participant - not allowed \n")
            topper()
        elif xcall == str.lower(gd.getv('fdcall')):
            txtbillb.insert(END, "\n That's us - not allowed \n")
            topper()
        elif xcall == str.lower(gd.getv('gcall')):
            txtbillb.insert(END, "\n That's us - not allowed \n")
            topper()
        else:
            # Added database protection against no band, no power, no op, and no logger -Scott Hibbs Jul/15/2013
            # Checking Contestant or Logger has a license - Scott Hibbs Mar/28/2017
            legal = 0
            if re.match(r'[a-z :]+ [a-zA-Z ]+, ([a-z\d]+)', operator):
                # print "%s has a license" % operator
                legal = legal + 1
            if re.match(r'[a-z :]+ [a-zA-Z ]+, ([a-z\d]+)', logger):
                # print "%s has a license" % logger
                legal = legal + 1
            if legal == 0:
                txtbillb.insert(END, "\n - WARNING: Contestant or the logger needs a license\n")
                txtbillb.insert(END, "up arrow or correct before repasting again\n")
                topper()
                return
            # checking for band, power, contestant or logger
            em = ""
            if band == "off":
                em += " Band "
            if power == 0:
                em += " Power "
            if len(operator) < 2:
                em += " Contestant "
            if len(logger) < 2:
                em += " Logger "
            if em != "":
                txtbillb.insert(END, "\n - WARNING: ( %s ) NOT SET" % em)
                txtbillb.insert(END, "up arrow or correct before repasting again\n")
                topper()
                return
            if em == "":
                rept1 = str.upper(rept)
                # check the report for valid fd or wfd classes - Art Miller KC7SDA
                try:
                    reptclass, reptsec = rept.split(" ")
                except ValueError:
                    txtbillb.insert(END, "\n - ERROR: incomplete exchange ( %s ) up arrow or correct before "
                                         "repasting again\n" % rept)
                    topper()
                    return
                #  m13 = ""
                if gd.getv('contst') == "fd":
                    # field day, report in: #+a-f
                    m13 = re.match(r'\d[a-fA-F]', reptclass)
                elif gd.getv('contst') == "wfd":
                    # WFD
                    m13 = re.match(r'\d[ihoIHO]', reptclass)
                else:
                    # vhf or other contest
                    # allow everything
                    m13 = "something"
                if m13 is None:  # match failed, do not allow and abort logging
                    txtbillb.insert(END, " - ERROR: Bad exchange ( %s ) up arrow or correct before "
                                         "repasting again\n" % rept)
                    topper()
                    return
                # Check for valid section in report added by Scott Hibbs Feb/6/2017
                aaaaa = len(rept1)
                # print "aaaaa is %s" % aaaaa
                rept2 = rept1[3:aaaaa].strip()
                # print "rept2 is %s" % rept2
                if rept2 in secName:
                    pass
                else:
                    print("\n Use one of these for the section:")
                    kk = ""
                    nx = 0
                    ny = 0
                    for k4 in sorted(secName):
                        if ny == 0:
                            kk += "\n  "
                            ny = ny + 1
                        kk += str(k4) + ", "
                        nx = nx + 1
                        if nx == 17:  # how many sections to the line
                            ny = ny + 1
                            if ny < 6:  # last line gets the rest
                                kk += "\n  "
                                nx = 0
                    print(kk)
                    # print('\n'.join("{} : {}".format(k, v) for k, v in secName.items()))
                    txtbillb.insert(END, kk)
                    txtbillb.insert(END, "\n  correct section with up arrow, or before repasting again\n")
                    topper()
                    return
                # The entry is good and ready to log
                txtbillb.insert(END, " - QSL!  May I have another?")
                txtbillb.insert(END, "\n")
                topper()
                tm = now()
                if ftm:  # force timestamp
                    tm = tm[0:4] + ftm[0:8] + tm[11:]  # yymmdd.hhmmss
                qdb.qsl(tm, xcall, band, rept)
    else:
        kbuf = ""
        txtbillb.insert(END, "\nPaste must be in -Call-Class-Sect- format only\n")
        topper()
    return


def paste(event):
    """Needed for mouse_popup function"""
    #  Added by KD4SIR Scott Hibbs 08Jul2022
    global stat, kbuf, power, operator, logger, debug, band, node, suffix, tdwin, goBack, selected
    if event:
        try:
            selected = root.clipboard_get()
        except tkinter.TclError:
            selected = ""
            return "break"
        pasteinterpreter()
        return "break"
    else:
        try:
            selected = root.clipboard_get()  # Get the copied item from system clipboard
        except tkinter.TclError:
            selected = ""
            return "break"
        pasteinterpreter()
        return "break"


def copy(event):
    """Needed for mouse_popup function"""
    global selected
    # if used keyboard shortcuts
    if event:
        try:
            selected = root.clipboard_get()
        except tkinter.TclError:
            selected = ""
            return "break"
    else:
        try:
            selected = txtbillb.get('sel.first', 'sel.last')  # Get the mouse selection into the clipboard
            root.clipboard_clear()  # Clear the tkinter clipboard
            root.clipboard_append(selected)  # Append to system clipboard
        except tkinter.TclError:
            selected = ""
            return "break"


class EditDialog(Toplevel):
    """edit log entry dialog"""
    #  Added functionality to check for dupes and change the title to show the error - Scott Hibbs Jul/02/2016
    #  Had to add variables for each text box to know if they changed to do dupe check.
    crazytxt = "Edit Log Entry"
    crazyclr = "light gray"
    crazylbl = Label

    def __init__(self, parent, node2, seq):
        s = '%s.%s' % (node2, seq)
        self.node, self.seq = node2, seq
        if qdb.byid[s].band[0] == '*':
            return
        top = self.top = Toplevel(parent)
        Toplevel.__init__(self, parent)  # only needed to avoid pycharm error.
        Toplevel.destroy(self)  # avoid showing as separate gui to avoid pycharm error above. :)
        self.crazytxt = "Edit Log Entry"
        self.crazyclr = "light gray"
        self.crazylbl = tl = Label(top, text=self.crazytxt, font=fdfont, bg=self.crazyclr, relief="raised")
        # tl = Label(top, text='Edit Log Entry', font=fdfont, bg='light gray', relief="raised")
        tl.grid(row=0, columnspan=2, sticky=EW)
        tl.grid_columnconfigure(0, weight=1)
        Label(top, text='Date', font=fdfont).grid(row=1, sticky=W)
        # Label(top,text='Time',font=fdfont).grid(row=2,sticky=W)
        Label(top, text='Band', font=fdfont).grid(row=3, sticky=W)
        # Label(top,text='Mode',font=fdfont).grid(row=4,sticky=W)
        Label(top, text='Call', font=fdfont).grid(row=5, sticky=W)
        Label(top, text='Report', font=fdfont).grid(row=6, sticky=W)
        Label(top, text='Power', font=fdfont).grid(row=7, sticky=W)
        # Label(top,text='Natural',font=fdfont).grid(row=8,sticky=W)
        Label(top, text='Contestant', font=fdfont).grid(row=9, sticky=W)
        Label(top, text='Logger', font=fdfont).grid(row=10, sticky=W)
        self.de = Entry(top, width=13, font=fdfont)
        self.de.grid(row=1, column=1, sticky=W, padx=3, pady=2)
        self.de.insert(0, qdb.byid[s].date)
        self.chodate = qdb.byid[s].date
        self.be = Entry(top, width=5, font=fdfont)
        self.be.grid(row=3, column=1, sticky=W, padx=3, pady=2)
        # self.be.config(bg='gold') # test yes works
        self.be.insert(0, qdb.byid[s].band)
        self.choband = qdb.byid[s].band
        self.ce = Entry(top, width=11, font=fdfont)
        self.ce.grid(row=5, column=1, sticky=W, padx=3, pady=2)
        self.ce.insert(0, qdb.byid[s].call)
        self.chocall = qdb.byid[s].call
        self.re = Entry(top, width=24, font=fdfont)
        self.re.grid(row=6, column=1, sticky=W, padx=3, pady=2)
        self.re.insert(0, qdb.byid[s].rept)
        self.chorept = qdb.byid[s].rept
        self.pe = Entry(top, width=5, font=fdfont)
        self.pe.grid(row=7, column=1, sticky=W, padx=3, pady=2)
        self.pe.insert(0, qdb.byid[s].powr)
        self.chopowr = qdb.byid[s].powr
        self.oe = Entry(top, width=3, font=fdfont)
        self.oe.grid(row=9, column=1, sticky=W, padx=3, pady=2)
        self.oe.insert(0, qdb.byid[s].oper)
        self.chooper = qdb.byid[s].oper
        self.le = Entry(top, width=3, font=fdfont)
        self.le.grid(row=10, column=1, sticky=W, padx=3, pady=2)
        self.le.insert(0, qdb.byid[s].logr)
        self.chologr = qdb.byid[s].logr
        bf = Frame(top)
        bf.grid(row=11, columnspan=2, sticky=EW, pady=2)
        bf.columnconfigure(0, weight=1)
        db = Button(bf, text=' Delete ', font=fdfont, command=self.dele)
        db.grid(row=1, sticky=EW, padx=3)
        sb = Button(bf, text=' Save ', font=fdfont, command=self.submit)
        sb.grid(row=1, column=1, sticky=EW, padx=3)
        # Button renamed to Dismiss - Curtis E. Mills WE7U 25Jun2019
        qb = Button(bf, text=' Dismiss ', font=fdfont, command=self.quitb)
        qb.grid(row=1, column=2, sticky=EW, padx=3)
        # self.wait_window(top)

    def submit(self):
        """submit edits"""
        # global newdate, newcall, newband, newrept, newopr, newlogr, newpowr
        newdate = ""
        newcall = ""
        newband = ""
        newrept = ""
        newopr = ""
        newlogr = ""
        newpowr = ""
        error = 0
        changer = 0  # 0 = no change. 1= change except band and call. 2 = change in call or band
        t = self.de.get().strip()  # date time
        if self.chodate != t:
            # print "The date has changed."
            changer = 1
        self.de.config(bg='white')
        m14 = re.match(r'\d{6}\.\d{4,6}$', t)
        if m14:
            newdate = t + '00'[:13 - len(t)]
            # print newdate
        else:
            self.de.config(bg='gold')
            error += 1
        t = self.be.get().strip()  # band mode
        if self.choband != t:
            # print "the band has changed"
            changer = 2
        self.be.config(bg='white')
        m14 = re.match(r'(160|80|40|20|15|10|6|2|220|440|900|1200|sat)[cdp]$', t)
        if m14:
            newband = t
            # print newband
        else:
            self.be.config(bg='gold')
            error += 1
        t = self.ce.get().strip()  # call
        if self.chocall != t:
            # print "the call has changed"
            changer = 2
        self.ce.config(bg='white')
        m14 = re.match(r'[a-z\d/]{3,11}$', t)
        if m14:
            newcall = t
            # print newcall
        else:
            self.ce.config(bg='gold')
            error += 1
        t = self.re.get().strip()  # report
        if self.chorept != t:
            print("the section is not verified - please check.")
            changer = 1
        self.re.config(bg='white')
        m14 = re.match(r'.{4,24}$', t)
        if m14:
            newrept = t
            # print newrept
        else:
            self.re.config(bg='gold')
            error += 1
        t = self.pe.get().strip().lower()  # power
        if self.chopowr != t:
            # print "the power has changed."
            changer = 1
        self.pe.config(bg='white')
        m14 = re.match(r'\d{1,4}n?$', t)
        if m14:
            newpowr = t
            # print newpowr
        else:
            self.pe.config(bg='gold')
            error += 1
        t = self.oe.get().strip().lower()  # operator
        if self.chooper != t:
            # print "the Contestant has changed."
            changer = 1
        self.oe.config(bg='white')
        if t in participants:
            newopr = t
            # print newopr
        else:
            self.oe.config(bg='gold')
            error += 1
        t = self.le.get().strip().lower()  # logger
        if self.chologr != t:
            # print "the logger has changed."
            changer = 1
        self.le.config(bg='white')
        if t in participants:
            newlogr = t
            # print newlogr
        else:
            self.le.config(bg='gold')
            error += 1
        if error == 0:
            # There was no dupe check on the edited qso info. This was added. Scott Hibbs Jul/01/2016
            if changer == 0:
                print('Nothing changed. No action performed.')
                self.crazytxt = "nothing changed?"
                self.crazyclr = "red"
                self.crazylbl.config(bg=self.crazyclr, text=self.crazytxt)
                error += 1
            if changer == 1:
                # delete and enter new data because something other than band or call has changed.
                # print "no errors, enter data"
                reason = "edited"
                qdb.qdelete(self.node, self.seq, reason)
                qdb.post_new(newdate, newcall, newband, newrept, newopr, newlogr, newpowr)
                self.top.destroy()
                txtbillb.insert(END, " EDIT Successful\n")
                topper()
            if changer == 2:
                # band or call changed so check for dupe before submitting to log.
                if qdb.dupck(newcall, newband):  # dup check for new data
                    # print('Edit is a DUPE. No action performed.')
                    self.crazytxt = "This is a DUPE"
                    self.crazyclr = "red"
                    self.crazylbl.config(bg=self.crazyclr, text=self.crazytxt)
                    error += 1
                else:
                    # delete and enter new data
                    # print "no errors, enter data"
                    reason = "edited"
                    qdb.qdelete(self.node, self.seq, reason)
                    qdb.post_new(newdate, newcall, newband, newrept, newopr, newlogr, newpowr)
                    self.top.destroy()
                    txtbillb.insert(END, " EDIT Successful\n")
                    topper()

    def dele(self):
        print("delete entry")
        reason = 'deleteclick'
        qdb.qdelete(self.node, self.seq, reason)
        self.top.destroy()

    def quitb(self):
        print('Dismissed - edit aborted')
        self.top.destroy()


def deledialog(cxll2, seq, stn):
    """Delete a participant using an entry dialog"""
    #  Added so participants can be deleted - Scott Hibbs 18Aug2022
    if node == "":
        txtbillb.insert(END, "err - no node\n")
        return
    s1 = Toplevel()
    s1.transient()
    s1.title('Delete Participant')
    # Frame 1
    fr1z = Frame(s1)
    fr1z.grid(row=0, column=0)

    def addpartbtn():
        s1.destroy()
        newpart.dialog()

    def quitbtn():
        s1.destroy()

    def dlbtn1z():
        """ Used to delete the participant """
        # Added by Scott Hibbs KD4SIR 15Aug2022
        qdb.udelete(node, seq, 'udelete')
        del (participants[cxll2])
        s1.initials.delete(0, END)
        s1.name.delete(0, END)
        s1.call.delete(0, END)
        s1.age.delete(0, END)
        s1.vist.delete(0, END)
        quitbtn()
        buildmenus()
        logwredraw()
        s1.destroy()

    part1lbox = Listbox(fr1z, bg='light gray', height=0, width=0, selectmode="single", exportselection=False)
    part1lbox.grid(row=0, column=0, sticky=NSEW)
    lpart1z = list(participants.values())
    lpart1z.sort()
    part1lboxind = -1
    for player1 in lpart1z:
        part1lboxind += 1
        part1lbox.insert(part1lboxind, player1)
    # Frame 2
    fr2z = Frame(s1)
    fr2z.grid(row=1, column=0)
    rog = str("%s %s" % (seq, stn))
    Label(fr2z, text=rog, font=fdfont, background='red').grid(row=0, columnspan=2, sticky=NSEW)
    # Moved the Initials below the name. It was awkward to ask for initials first. - Scott Hibbs 18Jun2022
    Label(fr2z, text='Name         ', font=fdfont, background='red').grid(row=1, column=0, sticky=W)
    s1.name = Entry(fr2z, width=20, font=fdfont)
    s1.name.grid(row=1, column=1, sticky=W)
    s1.name.focus()
    Label(fr2z, text='Initials     ', font=fdfont, background='red').grid(row=2, column=0, sticky=W)
    s1.initials = Entry(fr2z, width=3, font=fdfont, validate='focusout')
    s1.initials.grid(row=2, column=1, sticky=W)
    Label(fr2z, text='Call         ', font=fdfont, background='red').grid(row=3, column=0, sticky=W)
    s1.call = Entry(fr2z, width=6, font=fdfont)
    s1.call.grid(row=3, column=1, sticky=W)
    Label(fr2z, text='Age          ', font=fdfont, background='red').grid(row=4, column=0, sticky=W)
    s1.age = Entry(fr2z, width=2, font=fdfont)
    s1.age.grid(row=4, column=1, sticky=W)
    Label(fr2z, text='Visitor Title', font=fdfont, background='red').grid(row=5, column=0, sticky=W)
    s1.vist = Entry(fr2z, width=20, font=fdfont)
    s1.vist.grid(row=5, column=1, sticky=W)
    # Frame 3
    fr3 = Frame(s1)
    fr3.grid(row=2, column=0, sticky=EW, pady=3)
    fr3.columnconfigure(0, weight=1)
    # Added add participant button - Scott Hibbs KD4SIR 22Aug2022
    Button(fr3, text='Add Participant', font=fdfont, command=addpartbtn).grid(row=3, column=1, sticky=EW, padx=3)
    # Added a button to delete participant - Scott Hibbs KD4SIR 15Aug2022
    Button(fr3, text='Delete', font=fdfont, background='red', command=dlbtn1z).grid(row=3, column=2, sticky=EW, padx=3)
    # Button renamed to Dismiss - Curtis E. Mills WE7U 25Jun2019
    Button(fr3, text='Dismiss', font=fdfont, command=quitbtn).grid(row=3, column=3, sticky=EW, padx=3)
    # Populate the form
    s1.initials.insert(END, cxll2)
    indy = part1lbox.get(0, "end")
    # indy is a list of tuples in listbox. Now we need the index of our initials to populate the rest.
    ti = 0  # a counter to get our index.
    for dumdum in indy:
        if cxll2 in dumdum:  # initials match yet?
            break
        else:
            ti += 1
    val2 = part1lbox.get(ti)
    init, nomio, callio, ageio, vistio = val2.split(", ")
    # s1.initials.insert(END, init)
    s1.name.insert(END, nomio)
    s1.call.insert(END, callio)
    s1.age.insert(END, ageio)
    s1.vist.insert(END, vistio)
    part1lbox.config(state="disabled")  # to keep from changing participants


class USAStateMap:
    """This class displays a map of the USA with colored states based on a DataFrame"""
    # Added with the help of ChatGPT 3.5 - Scott Hibbs 01Mar2024

    def __init__(self, states_to_color):
        """ Initialize the USAStateMap object. """
        self.states_to_color = states_to_color

    def color_states(self):
        """ Color states based on the list of state initials."""
        # Define data for both Canada and the USA
        combined_data = {'state': ['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
                                   'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
                                   'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
                                   'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
                                   'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'],
                         'value': list(range(1, 51))}
        # Create DataFrame
        df = pd.DataFrame(combined_data)
        # Initialize a new column for colors
        df['color'] = 'white'
        # Change the color of the specified states to dark blue
        for state_initial in self.states_to_color:
            # Ensure state_initial is a string and convert to uppercase
            state_initial_str = str(state_initial).upper()
            state_index = df.index[df['state'] == state_initial_str].tolist()
            if state_index:
                df.at[state_index[0], 'color'] = 'darkblue'
            else:
                print(f"State '{state_initial_str}' not found in the DataFrame.")
        # Create a choropleth map with the updated colors
        fig = px.choropleth(df,
                            locations='state',
                            locationmode="USA-states",
                            projection='albers usa',
                            scope="north america",
                            color='color',  # Use the 'color' column for color
                            title='Map',
                            color_discrete_map={'white': 'white', 'darkblue': 'darkblue'},
                            category_orders={'color': ['white', 'darkblue']}
                            )
        fig.show()


def generate_map():
    qso_db = QsoDb()
    have_states = qso_db.get_have_states()
    if not have_states:
        have_states = []  # Show blank map if no states worked
    state_map = USAStateMap(have_states)
    state_map.color_states()


class SectionMap:
    """This class displays a grid map of ARRL/RAC sections organized by call area"""
    # Added by Claude - Section Map similar to WAS Map

    # Define sections by ARRL call area
    SECTIONS_BY_AREA = {
        '0': ['CO', 'IA', 'KS', 'MN', 'MO', 'NE', 'ND', 'SD'],
        '1': ['CT', 'EMA', 'ME', 'NH', 'RI', 'VT', 'WMA'],
        '2': ['ENY', 'NLI', 'NNJ', 'NNY', 'SNJ', 'WNY'],
        '3': ['DE', 'EPA', 'MDC', 'WPA'],
        '4': ['AL', 'GA', 'KY', 'NC', 'NFL', 'PR', 'SC', 'SFL', 'TN', 'VA', 'VI', 'WCF'],
        '5': ['AR', 'LA', 'MS', 'NM', 'NTX', 'OK', 'STX', 'WTX'],
        '6': ['EB', 'LAX', 'ORG', 'PAC', 'SB', 'SCV', 'SDG', 'SF', 'SJV', 'SV'],
        '7': ['AK', 'AZ', 'EWA', 'ID', 'MT', 'NV', 'OR', 'UT', 'WWA', 'WY'],
        '8': ['MI', 'OH', 'WV'],
        '9': ['IL', 'IN', 'WI'],
        'CA': ['AB', 'BC', 'GH', 'MB', 'NB', 'NL', 'NS', 'ONE', 'ONN', 'ONS', 'PE', 'QC', 'SK', 'TER'],
        'DX': ['DX']
    }

    def __init__(self, sections_to_color):
        """Initialize the SectionMap object."""
        self.sections_to_color = [s.upper() for s in sections_to_color]

    def show_map(self):
        """Display the section map in a new window."""
        # Create a new top-level window
        map_window = Toplevel()
        map_window.title("Worked All Sections Map")
        map_window.configure(background='white')

        # Count totals
        total_sections = sum(len(sects) for sects in self.SECTIONS_BY_AREA.values())
        worked_count = len(self.sections_to_color)

        # Title label
        title_label = Label(map_window, text=f"Worked All Sections: {worked_count}/{total_sections}",
                           font=('Courier', 14, 'bold'), background='white', foreground='darkblue')
        title_label.grid(row=0, column=0, columnspan=12, pady=10, sticky='ew')

        # Create section grid
        row_offset = 1
        for area, sections in self.SECTIONS_BY_AREA.items():
            # Area header
            area_label = Label(map_window, text=f"Area {area}:" if area.isdigit() else f"{area}:",
                              font=('Courier', 10, 'bold'), background='white', width=8, anchor='e')
            area_label.grid(row=row_offset, column=0, padx=5, pady=2, sticky='e')

            # Section labels
            for col, sect in enumerate(sections):
                is_worked = sect in self.sections_to_color
                bg_color = 'darkblue' if is_worked else 'white'
                fg_color = 'white' if is_worked else 'black'
                border_color = 'darkblue'

                # Create a frame for border effect
                frame = Frame(map_window, background=border_color, padx=1, pady=1)
                frame.grid(row=row_offset, column=col + 1, padx=2, pady=2)

                sect_label = Label(frame, text=sect, font=('Courier', 10),
                                  background=bg_color, foreground=fg_color,
                                  width=4, relief='flat')
                sect_label.pack()

            row_offset += 1

        # Legend
        legend_frame = Frame(map_window, background='white')
        legend_frame.grid(row=row_offset, column=0, columnspan=12, pady=10)

        Label(legend_frame, text="Legend: ", font=('Courier', 10, 'bold'),
              background='white').pack(side='left', padx=5)

        worked_box = Frame(legend_frame, background='darkblue', padx=1, pady=1)
        worked_box.pack(side='left', padx=2)
        Label(worked_box, text="    ", background='darkblue').pack()
        Label(legend_frame, text="= Worked", font=('Courier', 10),
              background='white').pack(side='left', padx=(0, 15))

        needed_box = Frame(legend_frame, background='darkblue', padx=1, pady=1)
        needed_box.pack(side='left', padx=2)
        Label(needed_box, text="    ", background='white').pack()
        Label(legend_frame, text="= Needed", font=('Courier', 10),
              background='white').pack(side='left')

        # Center the window
        map_window.update_idletasks()
        width = map_window.winfo_width()
        height = map_window.winfo_height()
        x_pos = (map_window.winfo_screenwidth() // 2) - (width // 2)
        y_pos = (map_window.winfo_screenheight() // 2) - (height // 2)
        map_window.geometry(f'+{x_pos}+{y_pos}')


def generate_section_map():
    """Generate and display the Worked All Sections map."""
    qso_db = QsoDb()
    have_sections = qso_db.get_have_sections()
    section_map = SectionMap(have_sections)
    section_map.show_map()


class InfoTableWindow:
    """Information Table display for Field Day visitors.

    This provides a kiosk-style display showing current contest status,
    top operators/loggers, and allows visitors to register as participants.
    """

    def __init__(self, root_window, qso_db, global_data, network):
        self.root = root_window
        self.qdb = qso_db
        self.gd = global_data
        self.net = network
        self.update_job = None
        self.title_label = None
        self.call_label = None
        self.gota_label = None
        self.time_label = None
        self.score_label = None
        self.qso_label = None
        self.mode_label = None
        self.contestant_labels = []
        self.logger_labels = []
        self.was_label = None
        self.sections_label = None
        self.setup_ui()
        self.update_display()

    def setup_ui(self):
        """Configure the root window and create all UI elements."""
        global txtbillb
        # Clear any existing widgets from root (from normal GUI setup)
        for widget in self.root.winfo_children():
            widget.destroy()

        # Remove any existing menus
        self.root.config(menu='')

        # Create a hidden dummy txtbillb for NewParticipantDialog compatibility
        txtbillb = Text(self.root)
        # Don't pack it - keep it hidden but available for the dialog

        self.root.title('FDLog_Enhanced - Information Table')
        self.root.configure(background='#1a1a2e')

        # Make window fullscreen/maximized
        self.root.state('zoomed')  # Maximized on Windows
        # Alternative for true fullscreen: self.root.attributes('-fullscreen', True)

        # Main container frame
        main_frame = Frame(self.root, background='#1a1a2e', padx=20, pady=10)
        main_frame.pack(fill='both', expand=True)

        # Register button at TOP so it's always visible
        self.create_register_button(main_frame)

        # Header section
        self.create_header(main_frame)

        # Score panel
        self.create_score_panel(main_frame)

        # Leaderboards frame (side by side)
        leaderboards_frame = Frame(main_frame, background='#1a1a2e')
        leaderboards_frame.pack(fill='x', pady=5)
        leaderboards_frame.columnconfigure(0, weight=1)
        leaderboards_frame.columnconfigure(1, weight=1)

        # Top Contestants panel
        self.create_contestants_panel(leaderboards_frame)

        # Top Loggers panel
        self.create_loggers_panel(leaderboards_frame)

        # Progress section (WAS and Sections)
        self.create_progress_panel(main_frame)

    def create_header(self, parent):
        """Create the header section with club name, calls, and time."""
        header_frame = Frame(parent, background='#1a1a2e', padx=15, pady=15)
        header_frame.pack(fill='x', pady=(0, 15))

        # Get data with error handling
        org_name = self.gd.getv('grpnam')
        if org_name.startswith('get error'):
            org_name = ''
        fd_call = self.gd.getv('fdcall')
        if fd_call.startswith('get error'):
            fd_call = ''
        else:
            fd_call = fd_call.upper()
        gota_call = self.gd.getv('gcall')
        if gota_call.startswith('get error'):
            gota_call = ''
        else:
            gota_call = gota_call.upper()

        # Horizontal layout: Title | FD Call | GOTA Call (justified across width)
        title_text = f"{org_name} Field Day" if org_name else "Field Day"
        self.title_label = Label(header_frame, text=title_text,
                                  font=('Helvetica', 24, 'bold'),
                                  foreground='white', background='#1a1a2e')
        self.title_label.pack(side='left', expand=True)

        # FD Call
        fd_call_text = f"FD Call: {fd_call}" if fd_call else "FD Call: Not Set"
        self.call_label = Label(header_frame, text=fd_call_text,
                                 font=('Helvetica', 24, 'bold'),
                                 foreground='white', background='#1a1a2e')
        self.call_label.pack(side='left', expand=True)

        # GOTA Call
        gota_text = f"GOTA Call: {gota_call}" if gota_call else "GOTA Call: Not Set"
        self.gota_label = Label(header_frame, text=gota_text,
                                 font=('Helvetica', 24, 'bold'),
                                 foreground='white', background='#1a1a2e')
        self.gota_label.pack(side='left', expand=True)

    def create_score_panel(self, parent):
        """Create the score display panel."""
        score_frame = Frame(parent, background='#1a1a2e', padx=15, pady=15)
        score_frame.pack(fill='x', pady=10)

        # Horizontal layout: Score | Total QSOs | Mode breakdown (justified across width)
        self.score_label = Label(score_frame, text="CURRENT SCORE: 0",
                                  font=('Helvetica', 24, 'bold'),
                                  foreground='white', background='#1a1a2e')
        self.score_label.pack(side='left', expand=True)

        # QSO counts
        self.qso_label = Label(score_frame, text="Total QSOs: 0",
                                font=('Helvetica', 24, 'bold'),
                                foreground='white', background='#1a1a2e')
        self.qso_label.pack(side='left', expand=True)

        # Mode breakdown
        self.mode_label = Label(score_frame, text="CW: 0  |  Digital: 0  |  Phone: 0",
                                 font=('Helvetica', 24, 'bold'),
                                 foreground='white', background='#1a1a2e')
        self.mode_label.pack(side='left', expand=True)

    def create_contestants_panel(self, parent):
        """Create the top Contestants leaderboard."""
        contestants_frame = Frame(parent, background='#1a1a2e', padx=10)
        contestants_frame.grid(row=0, column=0, sticky='nsew', padx=(0, 5))

        # Title
        Label(contestants_frame, text="TOP 5 CONTESTANTS",
              font=('Helvetica', 24, 'bold'),
              foreground='white', background='#1a1a2e').pack(pady=(0, 10))

        # Leaderboard entries
        self.contestant_labels = []
        for idx in range(5):
            entry_frame = Frame(contestants_frame, background='#16213e', padx=10, pady=5)
            entry_frame.pack(fill='x', pady=2)
            lbl = Label(entry_frame, text=f"{idx+1}. ---",
                        font=('Courier', 20),
                        foreground='white', background='#16213e', anchor='w')
            lbl.pack(fill='x')
            self.contestant_labels.append(lbl)

    def create_loggers_panel(self, parent):
        """Create the top Loggers leaderboard."""
        loggers_frame = Frame(parent, background='#1a1a2e', padx=10)
        loggers_frame.grid(row=0, column=1, sticky='nsew', padx=(5, 0))

        # Title
        Label(loggers_frame, text="TOP 5 LOGGERS",
              font=('Helvetica', 24, 'bold'),
              foreground='white', background='#1a1a2e').pack(pady=(0, 10))

        # Leaderboard entries
        self.logger_labels = []
        for idx in range(5):
            entry_frame = Frame(loggers_frame, background='#16213e', padx=10, pady=5)
            entry_frame.pack(fill='x', pady=2)
            lbl = Label(entry_frame, text=f"{idx+1}. ---",
                        font=('Courier', 20),
                        foreground='white', background='#16213e', anchor='w')
            lbl.pack(fill='x')
            self.logger_labels.append(lbl)

    def create_progress_panel(self, parent):
        """Create the WAS and Sections progress panel."""
        progress_frame = Frame(parent, background='#1a1a2e', padx=15, pady=15)
        progress_frame.pack(fill='x', pady=10)

        # WAS progress (justified across width)
        self.was_label = Label(progress_frame, text="WORKED ALL STATES: 0/50",
                                font=('Helvetica', 24, 'bold'),
                                foreground='white', background='#1a1a2e')
        self.was_label.pack(side='left', expand=True)

        # Sections progress
        self.sections_label = Label(progress_frame, text="SECTIONS: 0/84",
                                     font=('Helvetica', 24, 'bold'),
                                     foreground='white', background='#1a1a2e')
        self.sections_label.pack(side='left', expand=True)

    def create_register_button(self, parent):
        """Create the visitor registration button with date/time above it."""
        button_frame = Frame(parent, background='#1a1a2e', pady=20)
        button_frame.pack(fill='x')

        # Date and time display above the button
        self.time_label = Label(button_frame, text="",
                                 font=('Helvetica', 24, 'bold'),
                                 foreground='white', background='#1a1a2e')
        self.time_label.pack(pady=(0, 10))

        # Use a more visible style for Windows compatibility
        register_btn = Button(button_frame, text=">>> Sign In Here Please <<<",
                               font=('Helvetica', 18, 'bold'),
                               foreground='black', background='#00ff00',
                               activeforeground='white', activebackground='#00aa00',
                               relief='raised', borderwidth=4,
                               padx=40, pady=20,
                               cursor='hand2',
                               command=self.register_visitor)
        register_btn.pack(pady=10)

    def update_display(self):
        """Refresh all data on the display."""
        self.update_header()
        self.update_time()
        self.update_score()
        self.update_leaderboards()
        self.update_progress()

        # Keep the network alive so other nodes see us
        self.net.bcast_now()

        # Schedule next update in 10 seconds
        self.update_job = self.root.after(10000, self.update_display)

    def update_header(self):
        """Update header fields from synced global data."""
        org_name = self.gd.getv('grpnam')
        if org_name.startswith('get error'):
            org_name = ''
        fd_call = self.gd.getv('fdcall')
        if fd_call.startswith('get error'):
            fd_call = ''
        else:
            fd_call = fd_call.upper()
        gota_call = self.gd.getv('gcall')
        if gota_call.startswith('get error'):
            gota_call = ''
        else:
            gota_call = gota_call.upper()

        title_text = f"{org_name} Field Day" if org_name else "Field Day"
        self.title_label.config(text=title_text)
        fd_call_text = f"FD Call: {fd_call}" if fd_call else "FD Call: Not Set"
        self.call_label.config(text=fd_call_text)
        if self.gota_label:
            gota_text = f"GOTA: {gota_call}" if gota_call else "GOTA: Not Set"
            self.gota_label.config(text=gota_text)

    def update_time(self):
        """Update the current time display."""
        import time
        date_str = time.strftime("%d%b%Y", time.gmtime())
        utc_str = time.strftime("%H:%M:%S", time.gmtime())
        local_str = time.strftime("%H:%M:%S", time.localtime())
        self.time_label.config(text=f"{date_str}    UTC: {utc_str}    Local: {local_str}")

    def update_score(self):
        """Update the score display."""
        score_data = self.get_score_data()
        total_score, cwq, digq, fonq, total_qsos = score_data

        self.score_label.config(text=f"CURRENT SCORE: {total_score:,}")
        self.qso_label.config(text=f"Total QSOs: {total_qsos}")
        self.mode_label.config(text=f"CW: {cwq}  |  Digital: {digq}  |  Phone: {fonq}")

    def _participant_display(self, ini):
        """Get display name for a participant from initials.
        Returns 'Name (CALL)' if available, otherwise just the initials."""
        entry = participants.get(ini.lower(), '')
        if entry:
            parts = entry.split(', ')
            if len(parts) >= 3:
                name = parts[1].strip()
                call = parts[2].strip().upper()
                if name and call:
                    return f"{name} ({call})"
                elif name:
                    return name
                elif call:
                    return call
        return ini.upper()

    def update_leaderboards(self):
        """Update the top operators and loggers lists."""
        top_ops = self.get_top_operators(5)
        top_loggers = self.get_top_loggers(5)

        # Update contestant labels
        for idx, lbl in enumerate(self.contestant_labels):
            if idx < len(top_ops):
                ini, count = top_ops[idx]
                display = self._participant_display(ini)
                lbl.config(text=f"{idx+1}. {display} - {count} QSOs")
            else:
                lbl.config(text=f"{idx+1}. ---")

        # Update logger labels
        for idx, lbl in enumerate(self.logger_labels):
            if idx < len(top_loggers):
                ini, count = top_loggers[idx]
                display = self._participant_display(ini)
                lbl.config(text=f"{idx+1}. {display} - {count} QSOs")
            else:
                lbl.config(text=f"{idx+1}. ---")

    def update_progress(self):
        """Update the WAS and sections progress."""
        have_states = self.qdb.get_have_states()
        have_sections = self.qdb.get_have_sections()

        self.was_label.config(text=f"WORKED ALL STATES: {len(have_states)}/50")
        self.sections_label.config(text=f"SECTIONS: {len(have_sections)}/84")

    @staticmethod
    def _safe_int(value, default_val=0):
        """Safely convert a value to int, returning default_val on failure."""
        try:
            return int(value)
        except (ValueError, TypeError):
            return default_val

    def get_score_data(self):
        """Calculate and return current score data.

        Returns: (total_score, cwq, digq, fonq, total_qsos)
        """
        qpb, ppb, qpop, qplg, qpst, tq, score, maxp, cwq, digq, fonq, qpgop, gotaq, nat, sat = \
            self.qdb.band_rpt()

        # Calculate QSO points
        qsop = cwq * 2 + digq * 2 + fonq

        # Calculate power multiplier (with safe int conversion)
        powm = 5
        psgen = self._safe_int(self.gd.getv('psgen'))
        pscom = self._safe_int(self.gd.getv('pscom'))
        if psgen > 0 or pscom > 0:
            powm = 2
        if maxp > 5:
            powm = 2
        if maxp > 150:
            powm = 1
        if maxp > 1500:
            powm = 0

        total_score = qsop * powm
        total_qsos = cwq + digq + fonq

        return total_score, cwq, digq, fonq, total_qsos

    def get_top_operators(self, n=5):
        """Get the top n operators by QSO count.

        Returns: List of (initials, qso_count) tuples
        """
        qpb, ppb, qpop, qplg, qpst, tq, score, maxp, cwq, digq, fonq, qpgop, gotaq, nat, sat = \
            self.qdb.band_rpt()

        # Sort operators by QSO count descending
        sorted_ops = sorted(qpop.items(), key=lambda item: item[1], reverse=True)
        return sorted_ops[:n]

    def get_top_loggers(self, n=5):
        """Get the top n loggers by QSO count.

        Returns: List of (initials, qso_count) tuples
        """
        qpb, ppb, qpop, qplg, qpst, tq, score, maxp, cwq, digq, fonq, qpgop, gotaq, nat, sat = \
            self.qdb.band_rpt()

        # Sort loggers by QSO count descending
        sorted_loggers = sorted(qplg.items(), key=lambda item: item[1], reverse=True)
        return sorted_loggers[:n]

    @staticmethod
    def register_visitor():
        """Open the new participant dialog for visitor registration."""
        NewParticipantDialog.dialog()


def update():
    """Main program's timed updater"""
    # This function updated from 152i
    global updatect
    root.after(1000, update)  # type: ignore  # reschedule early for reliability
    sms.prout()  # 1 hz items
    updatebb()
    net.si.age_data()
    mclock.adjust()
    #   if mclock.level == 0:  # time master broadcasts time more frequently
    #   net.bcast_time()
    updatect += 1
    # if (updatect % 5) == 0:         # 5 sec
    # net.bcast_now()
    if (updatect % 10) == 0:  # 10 sec
        autokicker()  # this kicks user off band for inactivity - Scott Hibbs KD4SIR 10Aug2022
        updateqct()  # this updates rcv packet fail
        renew_title()  # this sends status broadcast
    if (updatect % 30) == 0:  # 30 sec
        _thread.start_new_thread(mclock.ntp_check, ())  # non-blocking NTP query
        mclock.update()
    if updatect > 59:  # 60 sec
        updatect = 0


""" ###########################   Main Program   ########################## """
#  Moved the main program elements here for better readability - Scott Hibbs KD4SIR 05Jul2022
print(prog)
version = "v2026_Beta 4.2.4"  # Changed 03Feb2026
fontsize = 12
# fontinterval = 2  # removed for the new font selection menu. - Scott Hibbs KD4SIR 10Aug2022
typeface = 'Courier'
fdfont = (typeface, fontsize)  # regular fixed width font
# fdfont = (typeface, fontsize + fontinterval)  # medium  fixed width font
# fdfont = (typeface, fontsize + fontinterval * 2)  # large   fixed width font
fingerprint()
mclock = ClockClass()
gd = GlobalDataClass()
bands = ('160', '80', '40', '20', '15', '10', '6', '2', '220', '440', '900', '1200', 'sat', 'off')
modes = ('c', 'd', 'p')
bandb = {}  # band button names
newpart = NewParticipantDialog()
editpart = EditParticipantDialog()
gpssync = GPSSyncDialog()
cf = {}
participants = {}
operatorsonline = {}

# modified the sect setting regex to accept both lower and upper case, added additional form fields
# (also fixed 'from' to 'form') for wfd NOTE: set commands have a max length of 6! - Art Miller KC7SDA 2019
for name, desc, default, okre, maxlen in (
        ('class', '<n><A-F>       FD class (eg 2A)', '2A', r'[1-9]\d?[a-fihoA-FIHO]$', 3),
        ('contst', '<text>         Contest (FD,WFD,VHF)', 'FD', r'fd|FD|wfd|WFD|vhf|VHF$', 3),
        ('fdcall', '<CALL>         FD call', '', r'[a-zA-Z\d]{3,6}$', 6),
        ('gcall', '<CALL>         GOTA call', '', r'[a-zA-Z\d]{3,6}$', 6),
        ('sect', '<XX>           ARRL section abbrev', '', r'[a-zA-Z]{2,3}$', 3),
        ('grid', '<grid>         VHF grid square', '', r'[A-Z]{2}\d{2}$', 4),
        ('grpnam', '<text>         group name', '', r'[A-Za-z\d #.:-]{4,35}$', 35),
        ('fmcall', '<CALL>         entry form call', '', r'[a-zA-Z\d]{3,6}$', 6),
        ('fmname', '<name>         entry form name', '', r'[A-Za-z\d .:-]{0,35}$', 35),
        ('fmad1', '<text>         entry form address line 1', '', r'[A-Za-z\d #.,:-]{0,35}$', 35),
        ('fmad2', '<text>         entry form address line 2', '', r'[A-Za-z\d #.,:-]{0,35}$', 35),
        ('fmst', '<text>         entry form state', '', r'[a-z]{2,3}$', 3),
        ('fmcity', '<text>         entry form city', '', r'[A-Za-z]{2,35}$', 35),
        ('fmzip', '<text>         entry form zip code', '', r'\d{5}$', 6),
        ('fmem', '<text>         entry form email', '', r'[A-Za-z\d@.:-]{0,35}$', 35),
        ('public', '<text>         public location desc', '', r'[A-Za-z\d@.: -]{0,35}$', 35),
        ('infob', '0/1            public info booth', '0', r'[0-1]$', 1),
        ('svego', '<name>         govt official visitor name', '', r'[A-Za-z., -]{0,35}$', 35),
        ('svroa', '<name>         agency site visitor name', '', r'[A-Za-z., -]{0,35}$', 35),
        ('youth', '<n>            participating youth', '0', r'\d{1,2}$', 2),
        ('websub', '0/1            web submission bonus', '0', r'[0-1]$', 1),
        ('eduact', '0/1            educational activity bonus', '0', r'[0-1]$', 1),
        ('gotaco', '0/1            GOTA coach bonus', '0', r'[0-1]$', 1),
        ('social', '0/1            social media bonus', '0', r'[0-1]$', 1),
        ('safety', '0/1            safety officer bonus', '0', r'[0-1]$', 1),
        ('sitere', '0/1            site responsibilities bonus', '0', r'[0-1]$', 1),
        ('psgen', '0/1            using generator power', '0', r'[0-1]$', 1),
        ('pscom', '0/1            using commercial power', '0', r'[0-1]$', 1),
        ('psbat', '0/1            using battery power', '0', r'[0-1]$', 1),
        ('psoth', '<text>         desc of other power', '', r'[A-Za-z\d.: -]{0,35}$', 35),
        ('fdstrt', 'yymmdd.hhmm   FD start time (UTC)', '020108.1800', r'[\d.]{11}$', 11),
        ('fdend', 'yymmdd.hhmm    FD end time (UTC)', '990629.2100', r'[\d.]{11}$', 11),
        ('tmast', '<text>         Time Master Node', '', r'[A-Za-z\d-]{0,8}$', 8),
        ('telect', '<text>        Auto-elected Time Master', '', r'[A-Za-z\d-]{0,8}$', 8),
        ('tntp', '<text>         Shared NTP Server', '', r'[A-Za-z\d.-]{0,50}$', 50),
        ('kick', '<n>            Time to kick inactivity', '0', r'\d{1,2}$', 2)):
    gd.new(name, desc, default, okre, maxlen)

# Phonetic alphabet dictionary - Added by Scott Hibbs KD4SIR
PHONETIC_ALPHABET = {
    "a": "Alpha", "b": "Bravo", "c": "Charlie", "d": "Delta", "e": "Echo",
    "f": "Foxtrot", "g": "Golf", "h": "Hotel", "i": "India", "j": "Juliett",
    "k": "Kilo", "l": "Lima", "m": "Mike", "n": "November", "o": "Oscar",
    "p": "Papa", "q": "Quebec", "r": "Romeo", "s": "Sierra", "t": "Tango",
    "u": "Uniform", "v": "Victor", "w": "Whiskey", "x": "X-ray", "y": "Yankee",
    "z": "Zulu", "0": "Zero", "1": "One", "2": "Two", "3": "Three",
    "4": "Four", "5": "Five", "6": "Six", "7": "Seven", "8": "Eight", "9": "Nine",
    "-": "Dash", "/": "Stroke"
}


def callsign_to_phonetic(callsign):
    """Convert a callsign to its phonetic alphabet representation."""
    if not callsign:
        return ""
    phonetic_parts = []
    for char in callsign.lower():
        if char in PHONETIC_ALPHABET:
            phonetic_parts.append(PHONETIC_ALPHABET[char])
    return " ".join(phonetic_parts)


def get_phonetic_response(callsign, mode):
    """
    Generate the phonetic response based on mode.
    mode: 'cq' = CQ Field Day format
          'qrz' = QRZed format
          'answer' = Just the phonetic callsign
    """
    if not callsign:
        return ""
    phonetic = callsign_to_phonetic(callsign)
    callsign_upper = callsign.upper()
    if mode == 'cq':
        return f"CQ Field Day {callsign_upper}, {phonetic} Field Day"
    elif mode == 'qrz':
        return f"{phonetic} QRZed?"
    else:  # answer
        return phonetic


def update_phonetic_display():
    """Update the phonetic display based on current callsign and selected mode.
    Uses gcall (GOTA call) for gotanode, otherwise uses fdcall."""
    try:
        if node == 'gotanode':
            callsign = gd.getv('gcall')
        else:
            callsign = gd.getv('fdcall')
        mode = phonetic_mode.get()
        response = get_phonetic_response(callsign, mode)
        phonetic_label.config(text=response)
    except (NameError, tkinter.TclError, AttributeError):
        pass  # Silently ignore if widgets not ready


def toggle_phonetic_display():
    """Toggle visibility of the phonetic display frame."""
    global phonetic_visible
    try:
        if phonetic_visible:
            phonetic_frame.grid_remove()
            phonetic_toggle_btn.config(text="Show Phonetic")
            phonetic_visible = False
        else:
            phonetic_frame.grid(row=5, column=0, columnspan=2, sticky=NSEW)
            phonetic_toggle_btn.config(text="Hide Phonetic")
            phonetic_visible = True
    except (NameError, tkinter.TclError, AttributeError):
        pass  # Silently ignore if widgets not ready


# setup persistent globals before GUI
suffix = ""
call = ""
band = "off"
power = "0"
operator = ""
logger = ""
age = 0
vist = ""
node = ""
authk = ""
port_base = 7373
tmob = now()  # time started on band in min
tdwin = 5  # time diff window on displaying node clock diffs
showbc = 0  # show broadcasts
debug = 0
logdbf = "fdlog.fdd"  # persistent file copy of log database
logfile = "fdlog.log"  # printable log file (contest entry)
globf = "fdlog.dat"  # persistent global file
kbuf = ""  # keyboard line buffer
goBack = ""  # needed to print the last line entered with up arrow - Scott Hibbs KD4SIR Jul/05/2018
selected = ""  # selected is used for the mouse functions
stat = 0
kick = 10  # This is the setting in minutes to kick off for inactivity
acttime = 0
# map_was_lst = []  # list of state initials to color for map below
# have_states1 = QsoDb.get_have_states
# map_was_lst = have_states1
# usa_map = USAStateMap(map_was_lst)  # Instantiate the USAStateMap object

# Parse command-line arguments
parser = argparse.ArgumentParser(
    description='FDLog_Enhanced - Field Day Logging Software',
    epilog='Example: python FDLog_Enhanced.py --node station1 --auth 24'
)
parser.add_argument('--node', '-n', type=str, help='Station node name (7 chars, e.g., station1)')
parser.add_argument('--auth', '-a', type=str, help='Authentication key (e.g., 24 for year 2024)')
args = parser.parse_args()

# Load globals after all these default values are set.
globDb = GlobalDb()
loadglob()  # load persistent globals from file
print()

# Handle node ID - use CLI arg, saved value, or prompt
if args.node:
    # CLI argument provided
    k = str.lower(args.node)[:8]
    if k == 'gota':
        node = 'gotanode'
    elif k == 'info':
        node = 'infotable'
    else:
        # Pad to 7 chars if needed
        while len(k) < 7:
            k = k + random.choice('abcdefghijklmnopqrstuvwxyz')
        node = k[:7] + random.choice('abcdefghijklmnopqrstuvwxyz')
    print("Node ID set from command line")
elif node == "":
    # Revised 4/19/2014 for 8 characters so the log lines up nicely. - Scott Hibbs KD4SIR
    print("  Enter the station name (lower case)")
    print("  Please be 7 characters! (I will add letters to be unique)")
    print("  (Use 'gota' for get on the air station)")
    print("  (Use 'info' for information table display)")
    #    print "  (Previous Node ID: '%s')"%node
    print("  (7 characters}")
    k = str.lower(str.strip(sys.stdin.readline())[:8])
    if len(k) == 8:
        print("That's too many.. (Marc? is that you?)")  # Thanks to Marc Fountain K9MAF for the correction. Mar/23/2017
        k = k[:7]
    z = len(k)
    if k == 'info':
        print("Starting Information Table display...")
        node = 'infotable'
        print()
    elif k != 'gota':
        while z != 7:
            if k == 'gota':
                print("please restart the program.")
                sys.exit()
            elif k == 'info':
                print("Starting Information Table display...")
                node = 'infotable'
                break
            else:
                if z < 4:
                    print("um yeah.. 7 characters....    (restart if your gota or info)")
                    k = str.lower(str.strip(sys.stdin.readline())[:8])
                    z = len(k)
                else:
                    for z in range(z, 7):
                        print("close enough (Ken? is that you?)")
                        k = k + random.choice('abcdefghijklmnopqrstuvwxyz')
                        print(k)
                        # noinspection PyRedeclaration
                        z = len(k)  # Redeclared 'z' defined above without usage- but needed keeps program from looping
                        # 1. if there is more than four characters
                        # 2. add the rest with randoms
        else:
            print("Thank You!!")
            node = k + random.choice('abcdefghijklmnopqrstuvwxyz')
            print()
    else:
        print("Thank You for being gota!!")
        node = 'gotanode'
        print()
print("Using Node ID: '%s' " % node)
print()

# Handle auth key - use CLI arg, saved value, or prompt
if args.auth:
    # CLI argument provided
    print("Authentication key set from command line")
    authk = args.auth
    operator = ""
    logger = ""
else:
    # get auth key  auth xxxpppzzz...  fdlogxxx.fdd  port ppp   hashkey (all)
    # allow user to select new one, or re-use previous
    print("Enter Authentication Key (Return to re-use previous '%s')" % authk)
    print("  (use 'tst' for testing, two digit year for contest):")
    k = str.strip(sys.stdin.readline())
    if k != "":
        print("New Key entered, Contestant and logger cleared")
        authk = k
        operator = ""
        logger = ""
        print()
print("Using Authentication Key: '%s'" % authk)
print("Using", authk[0:3], "for setting port, file")
port_offset = ival(authk[3:6]) * 7
if port_offset == 0:
    port_offset = ival(authk[0:3]) * 7
# for each char in port_offset:  xxx
# port_offset = ((port_offset << 3) + (char & 15)) & 0x0fff
port_base += port_offset
print("Using Network Port:", port_base)
logdbf = "fdlog%s.fdd" % (authk[0:3])
print("Writing Log Journal file:", logdbf)
print("Starting Network")
net = NetworkSync()  # setup net
net.setport(port_base)
net.setauth(authk)
print("Saving Persistent Configuration in", globDb.dbPath)
saveglob()
if operator != "":
    ini3 = operator.split(':', 1)[0]
    operatorsonline.update({node: ini3})
print("Time Difference Window (tdwin):", tdwin, "seconds")

# Macro variable getter - shared by CW and Voice keyers
def get_macro_variable(name):
    """Get variable value for macro substitution (CW and Voice)."""
    name = name.upper()
    if name == 'MYCALL':
        # Use GOTA call when on GOTA node, otherwise FD call
        if node == 'gotanode':
            return str.upper(gd.getv('gcall'))
        return str.upper(gd.getv('fdcall'))
    elif name == 'CALL':
        global kbuf
        parts = kbuf.strip().split()
        if parts:
            return parts[0]
        return ''
    elif name == 'RST':
        return '59'
    elif name == 'CLASS':
        return str.upper(gd.getv('class'))
    elif name == 'SECT':
        return gd.getv('sect')
    elif name == 'NAME':
        return operator.split(':')[0] if operator else ''
    else:
        return f'{{{name}}}'

# CW Keying initialization
cw_controller = None
cw_status_label = None
fkey_bar_visible = False

if CW_AVAILABLE:
    print("CW Keying support available (pyserial found)")

    def cw_load_config():
        """Load CW configuration from globDb."""
        config = CWConfig()
        config.port = globDb.get('cw_port', '')
        config.method = globDb.get('cw_method', 'DTR')
        config.wpm = int(globDb.get('cw_wpm', '20'))
        config.ptt_lead = int(globDb.get('cw_ptt_lead', '50'))
        config.ptt_tail = int(globDb.get('cw_ptt_tail', '50'))
        config.ptt_enabled = globDb.get('cw_ptt_enabled', '0') == '1'
        config.ptt_line = globDb.get('cw_ptt_line', 'RTS')
        config.cat_enabled = globDb.get('cw_cat_enabled', '0') == '1'
        config.cat_port = globDb.get('cw_cat_port', '')
        config.cat_baud = int(globDb.get('cw_cat_baud', '9600'))
        config.cat_rig = globDb.get('cw_cat_rig', '')
        return config

    def cw_save_config(config):
        """Save CW configuration to globDb."""
        globDb.put('cw_port', config.port)
        globDb.put('cw_method', config.method)
        globDb.put('cw_wpm', str(config.wpm))
        globDb.put('cw_ptt_lead', str(config.ptt_lead))
        globDb.put('cw_ptt_tail', str(config.ptt_tail))
        globDb.put('cw_ptt_enabled', '1' if config.ptt_enabled else '0')
        globDb.put('cw_ptt_line', config.ptt_line)
        globDb.put('cw_cat_enabled', '1' if config.cat_enabled else '0')
        globDb.put('cw_cat_port', config.cat_port)
        globDb.put('cw_cat_baud', str(config.cat_baud))
        globDb.put('cw_cat_rig', config.cat_rig)

    def cw_save_macros(macros):
        """Save CW macros to globDb."""
        for key, value in macros.items():
            globDb.put(f'cw_macro_{key}', value)

    def cw_load_macros():
        """Load CW macros from globDb."""
        macros = {}
        for i in range(1, 13):
            key = f'F{i}'
            default = CWMacroManager.DEFAULT_MACROS.get(key, '')
            macros[key] = globDb.get(f'cw_macro_{key}', default)
        return macros

    def cw_status_update(status):
        """Update CW status display."""
        global cw_status_label
        if cw_status_label:
            hint = " [Hide]" if fkey_bar_visible else " [Show]"
            if str(cw_status_label.cget('state')) == 'disabled':
                hint = ""
            cw_status_label.config(text=f"CW: {status}{hint}")

    def cw_settings_dialog():
        """Open CW settings dialog."""
        global cw_controller
        if cw_controller:
            def on_save(config):
                cw_save_config(config)
                cw_controller.config = config
                if cw_controller.keyer:
                    cw_controller.keyer.config = config
                print(f"CW: Settings saved - Port: {config.port}, Method: {config.method}, WPM: {config.wpm}")
            CWSettingsDialog(root, cw_controller.config, on_save)

    def cw_macro_editor_dialog():
        """Open CW macro editor dialog."""
        global cw_controller
        if cw_controller:
            def on_save(macros):
                cw_save_macros(macros)
                print("CW: Macros saved")
            CWMacroEditorDialog(root, cw_controller.macro_manager, on_save)

    def cw_connect():
        """Connect to CW keyer."""
        global cw_controller
        if cw_controller:
            if cw_controller.config.port:
                if cw_controller.connect():
                    print(f"CW: Connected to {cw_controller.config.port}")
                else:
                    print("CW: Failed to connect")
            else:
                print("CW: No port configured - use CW > Settings to configure")

    def cw_disconnect():
        """Disconnect from CW keyer."""
        global cw_controller
        if cw_controller:
            cw_controller.disconnect()
            print("CW: Disconnected")

    def cw_adjust_speed(delta):
        """Adjust CW speed."""
        global cw_controller
        if cw_controller:
            cw_controller.adjust_wpm(delta)
            cw_save_config(cw_controller.config)
            print(f"CW: Speed set to {cw_controller.config.wpm} WPM")

    _cw_sidetone_abort = False
    _cw_sidetone_proc = None  # subprocess.Popen handle for Linux/macOS

    def _cw_sidetone_stop():
        """Stop any currently playing sidetone."""
        global _cw_sidetone_abort, _cw_sidetone_proc
        _cw_sidetone_abort = True
        if sys.platform == 'win32':
            try:
                import winsound
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass
        elif _cw_sidetone_proc and _cw_sidetone_proc.poll() is None:
            _cw_sidetone_proc.terminate()
            _cw_sidetone_proc = None

    def _cw_sidetone_build_wav(text, wpm, freq=600):
        """Build a complete WAV file (as bytes) for the given CW text.

        Timing (in dit-units):
          dit  = 1, dah = 3, inter-element gap = 1,
          inter-character gap = 3, word gap = 7.
        """
        import struct, math, wave, io
        sample_rate = 22050
        dit_samples = int(sample_rate * 1.2 / wpm)  # samples per dit-unit

        audio = []

        def add_tone(units):
            n = dit_samples * units
            audio.extend(
                int(16000 * math.sin(2 * math.pi * freq * t / sample_rate))
                for t in range(n)
            )

        def add_silence(units):
            audio.extend([0] * (dit_samples * units))

        for ci, char in enumerate(text.upper()):
            if char == ' ':
                # Word gap is 7 units; previous char already added 3,
                # so add 4 more
                add_silence(4)
                continue
            code = MORSE_CODE.get(char)
            if not code:
                continue
            for ei, element in enumerate(code):
                if element == '.':
                    add_tone(1)
                elif element == '-':
                    add_tone(3)
                # Inter-element gap (1 unit) except after last element
                if ei < len(code) - 1:
                    add_silence(1)
            # Inter-character gap (3 units)
            add_silence(3)

        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(struct.pack('<%dh' % len(audio), *audio))
        return buf.getvalue()

    _cw_sidetone_tmpfile = None  # temp WAV path for cleanup

    def _cw_sidetone_play_wav(wav_bytes):
        """Play WAV bytes cross-platform (blocking, but abortable)."""
        global _cw_sidetone_proc, _cw_sidetone_tmpfile
        import subprocess, tempfile
        # Write to temp file on all platforms
        tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        tmp.write(wav_bytes)
        tmp.close()
        _cw_sidetone_tmpfile = tmp.name
        try:
            if sys.platform == 'win32':
                import winsound
                # SND_ASYNC returns immediately; _cw_sidetone_stop() calls SND_PURGE to cancel
                winsound.PlaySound(tmp.name, winsound.SND_FILENAME | winsound.SND_ASYNC)
                # Poll until playback finishes or is aborted
                duration = max(0, (len(wav_bytes) - 44)) / (22050 * 2)
                elapsed = 0.0
                while elapsed < duration and not _cw_sidetone_abort:
                    time.sleep(0.05)
                    elapsed += 0.05
            else:
                cmd = ['afplay', tmp.name] if sys.platform == 'darwin' else ['aplay', '-q', tmp.name]
                _cw_sidetone_proc = subprocess.Popen(cmd,
                                                     stdout=subprocess.DEVNULL,
                                                     stderr=subprocess.DEVNULL)
                _cw_sidetone_proc.wait()
                _cw_sidetone_proc = None
        finally:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass

    def _cw_sidetone_play(text, wpm):
        """Play CW sidetone through PC audio (no keyer needed)."""
        global _cw_sidetone_abort
        _cw_sidetone_abort = False
        wav_bytes = _cw_sidetone_build_wav(text, wpm)

        def play():
            global _cw_sidetone_abort
            root.after(0, lambda: cw_status_update(f"Sending: {text}"))
            _cw_sidetone_play_wav(wav_bytes)
            _cw_sidetone_abort = False
            root.after(0, lambda: cw_status_update("Ready"))

        threading.Thread(target=play, daemon=True).start()

    def cw_send_macro(key):
        """Send a CW macro."""
        global cw_controller
        if cw_controller and cw_controller.is_connected():
            cw_controller.send_macro(key)
        elif cw_controller:
            # No keyer connected — play sidetone simulation
            macro_text = cw_controller.macro_manager.expand_macro(key) if cw_controller.macro_manager else key
            if macro_text:
                _cw_sidetone_play(macro_text, cw_controller.config.wpm)

    def cw_abort():
        """Abort CW transmission."""
        global cw_controller, _cw_sidetone_abort
        _cw_sidetone_stop()
        if cw_controller:
            cw_controller.abort()

else:
    print("CW Keying support NOT available (pyserial not found)")
    print("  Install with: pip install pyserial")

    def cw_settings_dialog():
        pass

    def cw_macro_editor_dialog():
        pass

    def cw_connect():
        pass

    def cw_disconnect():
        pass

    def cw_adjust_speed(delta):
        pass

    def cw_send_macro(key):
        pass

    def cw_abort():
        pass

# Voice Keying initialization
voice_keyer = None
voice_status_label = None

# WSJT-X Integration initialization
wsjtx_listener = None
wsjtx_status_label = None

# JS8Call Integration initialization
js8call_listener = None
js8call_status_label = None

# fldigi Integration initialization
fldigi_poller = None
fldigi_status_label = None

# N3FJP Integration initialization
n3fjp_client = None
n3fjp_server = None
n3fjp_status_label = None

# rigctld Integration initialization
rigctld_client = None
rigctld_status_label = None

if VOICE_AVAILABLE:
    print("Voice Keying support available (pyttsx3 found)")

    def voice_load_config():
        """Load voice configuration from globDb."""
        config = VoiceConfig()
        config.speed = int(globDb.get('voice_speed', '150'))
        config.volume = float(globDb.get('voice_volume', '1.0'))
        config.voice_id = globDb.get('voice_id', '')
        config.ptt_enabled = globDb.get('voice_ptt_enabled', '0') == '1'
        config.ptt_port = globDb.get('voice_ptt_port', '')
        config.ptt_line = globDb.get('voice_ptt_line', 'RTS')
        config.ptt_lead = int(globDb.get('voice_ptt_lead', '100'))
        config.ptt_tail = int(globDb.get('voice_ptt_tail', '100'))
        config.use_cw_port = globDb.get('voice_use_cw_port', '1') == '1'
        return config

    def voice_save_config(config):
        """Save voice configuration to globDb."""
        globDb.put('voice_speed', str(config.speed))
        globDb.put('voice_volume', str(config.volume))
        globDb.put('voice_id', config.voice_id)
        globDb.put('voice_ptt_enabled', '1' if config.ptt_enabled else '0')
        globDb.put('voice_ptt_port', config.ptt_port)
        globDb.put('voice_ptt_line', config.ptt_line)
        globDb.put('voice_ptt_lead', str(config.ptt_lead))
        globDb.put('voice_ptt_tail', str(config.ptt_tail))
        globDb.put('voice_use_cw_port', '1' if config.use_cw_port else '0')

    def voice_save_macros(macros, modes=None):
        """Save voice macros to globDb."""
        for key, value in macros.items():
            globDb.put(f'voice_macro_{key}', value)
        if modes:
            for key, value in modes.items():
                globDb.put(f'voice_mode_{key}', value)

    def voice_load_macros():
        """Load voice macros from globDb."""
        macros = {}
        for i in range(1, 13):
            key = f'F{i}'
            default = VoiceMacroManager.DEFAULT_MACROS.get(key, '')
            macros[key] = globDb.get(f'voice_macro_{key}', default)
        return macros

    def voice_load_modes():
        """Load voice macro modes from globDb."""
        modes = {}
        for i in range(1, 13):
            key = f'F{i}'
            modes[key] = globDb.get(f'voice_mode_{key}', 'tts')
        return modes

    def voice_status_update(status):
        """Update voice status display."""
        global voice_status_label
        if voice_status_label:
            hint = " [Hide]" if fkey_bar_visible else " [Show]"
            if str(voice_status_label.cget('state')) == 'disabled':
                hint = ""
            voice_status_label.config(text=f"Voice: {status}{hint}")

    def voice_settings_dialog():
        """Open voice settings dialog."""
        global voice_keyer
        if voice_keyer:
            def on_save(config):
                voice_save_config(config)
                voice_keyer.config = config
                print(f"Voice: Settings saved - Speed: {config.speed}, Volume: {config.volume}")
            VoiceSettingsDialog(root, voice_keyer.config, voice_keyer, on_save)

    def voice_macro_editor_dialog():
        """Open voice macro editor dialog."""
        global voice_keyer
        if voice_keyer:
            def on_save(macros, modes):
                voice_save_macros(macros, modes)
                print("Voice: Macros saved")
            VoiceMacroEditorDialog(root, voice_keyer.macro_manager, on_save)

    def voice_send_macro(key):
        """Send a voice macro."""
        global voice_keyer
        if voice_keyer:
            voice_keyer.play_macro(key)

    def voice_stop():
        """Stop voice playback."""
        global voice_keyer
        if voice_keyer:
            voice_keyer.stop()

else:
    print("Voice Keying support NOT available (pyttsx3 not found)")
    print("  Install with: pip install pyttsx3")

    def voice_settings_dialog():
        pass

    def voice_macro_editor_dialog():
        pass

    def voice_send_macro(key):
        pass

    def voice_stop():
        pass

# WSJT-X Integration functions
if WSJTX_AVAILABLE:
    print("WSJT-X Integration support available")

    def wsjtx_load_config():
        """Load WSJT-X configuration from globDb."""
        config = WSJTXConfig()
        config.enabled = globDb.get('wsjtx_enabled', '0') == '1'
        config.udp_port = int(globDb.get('wsjtx_udp_port', '2237'))
        config.udp_ip = globDb.get('wsjtx_udp_ip', '127.0.0.1')
        config.auto_log = globDb.get('wsjtx_auto_log', '1') == '1'
        config.auto_band = globDb.get('wsjtx_auto_band', '1') == '1'
        return config

    def wsjtx_save_config(config):
        """Save WSJT-X configuration to globDb."""
        globDb.put('wsjtx_enabled', '1' if config.enabled else '0')
        globDb.put('wsjtx_udp_port', str(config.udp_port))
        globDb.put('wsjtx_udp_ip', config.udp_ip)
        globDb.put('wsjtx_auto_log', '1' if config.auto_log else '0')
        globDb.put('wsjtx_auto_band', '1' if config.auto_band else '0')

    def wsjtx_status_update(status):
        """Update WSJT-X status display."""
        global wsjtx_status_label
        if wsjtx_status_label:
            if "Connected" in status and "Disconnected" not in status:
                wsjtx_status_label.config(text=f"WSJT-X: {status}",
                                          foreground='green')
            else:
                wsjtx_status_label.config(text=f"WSJT-X: {status}",
                                          foreground='gray')

    def wsjtx_on_qso_logged(call, band_mode, report, timestamp):
        """Called by WSJTXListener when WSJT-X logs a QSO. Runs on listener thread."""
        def _do_log():
            global band
            # Validate operator and logger are set
            if not gd.getv('ession'):
                print("WSJT-X: Cannot log QSO - no operator set")
                return
            # Dupe check
            if qdb.dupck(call, band_mode):
                print(f"WSJT-X: Dupe - {call} on {band_mode}")
                return
            # Auto-switch band if configured
            if wsjtx_listener and wsjtx_listener.config.auto_band:
                if band != band_mode:
                    bandset(band_mode)
            # Log the QSO
            qdb.qsl(timestamp, call, band_mode, report)
            print(f"WSJT-X: Logged {call} on {band_mode} - {report}")
        # Marshal to UI thread
        try:
            root.after(0, _do_log)
        except Exception:
            pass

    def wsjtx_settings_dialog():
        """Open WSJT-X settings dialog."""
        global wsjtx_listener
        if wsjtx_listener:
            def on_save(config):
                wsjtx_save_config(config)
                wsjtx_listener.config = config
                print(f"WSJT-X: Settings saved - Port: {config.udp_port}, Auto-log: {config.auto_log}")
            WSJTXSettingsDialog(root, wsjtx_listener.config, wsjtx_listener, on_save)

    def wsjtx_connect():
        """Start WSJT-X listener."""
        global wsjtx_listener
        if wsjtx_listener and not wsjtx_listener._running:
            wsjtx_listener.start()

    def wsjtx_disconnect():
        """Stop WSJT-X listener."""
        global wsjtx_listener
        if wsjtx_listener and wsjtx_listener._running:
            wsjtx_listener.stop()

else:
    print("WSJT-X Integration support NOT available")

    def wsjtx_settings_dialog():
        pass

    def wsjtx_connect():
        pass

    def wsjtx_disconnect():
        pass

# JS8Call Integration functions
if JS8CALL_AVAILABLE:
    print("JS8Call Integration support available")

    def js8call_load_config():
        """Load JS8Call configuration from globDb."""
        config = JS8CallConfig()
        config.enabled = globDb.get('js8call_enabled', '0') == '1'
        config.udp_port = int(globDb.get('js8call_udp_port', '2442'))
        config.udp_ip = globDb.get('js8call_udp_ip', '127.0.0.1')
        config.auto_log = globDb.get('js8call_auto_log', '1') == '1'
        config.auto_band = globDb.get('js8call_auto_band', '1') == '1'
        return config

    def js8call_save_config(config):
        """Save JS8Call configuration to globDb."""
        globDb.put('js8call_enabled', '1' if config.enabled else '0')
        globDb.put('js8call_udp_port', str(config.udp_port))
        globDb.put('js8call_udp_ip', config.udp_ip)
        globDb.put('js8call_auto_log', '1' if config.auto_log else '0')
        globDb.put('js8call_auto_band', '1' if config.auto_band else '0')

    def js8call_status_update(status):
        """Update JS8Call status display."""
        global js8call_status_label
        if js8call_status_label:
            if "Connected" in status and "Disconnected" not in status:
                js8call_status_label.config(text=f"JS8Call: {status}",
                                            foreground='green')
            else:
                js8call_status_label.config(text=f"JS8Call: {status}",
                                            foreground='gray')

    def js8call_on_qso_logged(call, band_mode, report, timestamp):
        """Called by JS8CallListener when JS8Call logs a QSO. Runs on listener thread."""
        def _do_log():
            global band
            # Validate operator and logger are set
            if not gd.getv('ession'):
                print("JS8Call: Cannot log QSO - no operator set")
                return
            # Dupe check
            if qdb.dupck(call, band_mode):
                print(f"JS8Call: Dupe - {call} on {band_mode}")
                return
            # Auto-switch band if configured
            if js8call_listener and js8call_listener.config.auto_band:
                if band != band_mode:
                    bandset(band_mode)
            # Log the QSO
            qdb.qsl(timestamp, call, band_mode, report)
            print(f"JS8Call: Logged {call} on {band_mode} - {report}")
        # Marshal to UI thread
        try:
            root.after(0, _do_log)
        except Exception:
            pass

    def js8call_settings_dialog():
        """Open JS8Call settings dialog."""
        global js8call_listener
        if js8call_listener:
            def on_save(config):
                js8call_save_config(config)
                js8call_listener.config = config
                print(f"JS8Call: Settings saved - Port: {config.udp_port}, Auto-log: {config.auto_log}")
            JS8CallSettingsDialog(root, js8call_listener.config, js8call_listener, on_save)

    def js8call_connect():
        """Start JS8Call listener."""
        global js8call_listener
        if js8call_listener and not js8call_listener._running:
            js8call_listener.start()

    def js8call_disconnect():
        """Stop JS8Call listener."""
        global js8call_listener
        if js8call_listener and js8call_listener._running:
            js8call_listener.stop()

else:
    print("JS8Call Integration support NOT available")

    def js8call_settings_dialog():
        pass

    def js8call_connect():
        pass

    def js8call_disconnect():
        pass

# fldigi Integration functions
if FLDIGI_AVAILABLE:
    print("fldigi Integration support available")

    def fldigi_load_config():
        """Load fldigi configuration from globDb."""
        config = FldigiConfig()
        config.enabled = globDb.get('fldigi_enabled', '0') == '1'
        config.xmlrpc_host = globDb.get('fldigi_xmlrpc_host', '127.0.0.1')
        config.xmlrpc_port = int(globDb.get('fldigi_xmlrpc_port', '7362'))
        config.poll_interval = float(globDb.get('fldigi_poll_interval', '1.5'))
        config.auto_log = globDb.get('fldigi_auto_log', '1') == '1'
        config.auto_band = globDb.get('fldigi_auto_band', '1') == '1'
        config.push_frequency = globDb.get('fldigi_push_frequency', '1') == '1'
        config.push_callsign = globDb.get('fldigi_push_callsign', '0') == '1'
        return config

    def fldigi_save_config(config):
        """Save fldigi configuration to globDb."""
        globDb.put('fldigi_enabled', '1' if config.enabled else '0')
        globDb.put('fldigi_xmlrpc_host', config.xmlrpc_host)
        globDb.put('fldigi_xmlrpc_port', str(config.xmlrpc_port))
        globDb.put('fldigi_poll_interval', str(config.poll_interval))
        globDb.put('fldigi_auto_log', '1' if config.auto_log else '0')
        globDb.put('fldigi_auto_band', '1' if config.auto_band else '0')
        globDb.put('fldigi_push_frequency', '1' if config.push_frequency else '0')
        globDb.put('fldigi_push_callsign', '1' if config.push_callsign else '0')

    def fldigi_status_update(status):
        """Update fldigi status display."""
        global fldigi_status_label
        if fldigi_status_label:
            if "Connected" in status and "Disconnected" not in status:
                fldigi_status_label.config(text=f"fldigi: {status}",
                                           foreground='green')
            else:
                fldigi_status_label.config(text=f"fldigi: {status}",
                                           foreground='gray')

    def fldigi_on_qso_logged(call, band_mode, report, timestamp):
        """Called by FldigiPoller when fldigi logs a QSO. Runs on poller thread."""
        def _do_log():
            global band
            # Validate operator and logger are set
            if not gd.getv('ession'):
                print("fldigi: Cannot log QSO - no operator set")
                return
            # Dupe check
            if qdb.dupck(call, band_mode):
                print(f"fldigi: Dupe - {call} on {band_mode}")
                return
            # Auto-switch band if configured
            if fldigi_poller and fldigi_poller.config.auto_band:
                if band != band_mode:
                    bandset(band_mode)
            # Log the QSO
            qdb.qsl(timestamp, call, band_mode, report)
            print(f"fldigi: Logged {call} on {band_mode} - {report}")
        # Marshal to UI thread
        try:
            root.after(0, _do_log)
        except Exception:
            pass

    def fldigi_on_band_change(new_band):
        """Called by FldigiPoller when fldigi frequency changes band."""
        def _do_band():
            global band
            if band != new_band:
                bandset(new_band)
        try:
            root.after(0, _do_band)
        except Exception:
            pass

    def fldigi_settings_dialog():
        """Open fldigi settings dialog."""
        global fldigi_poller
        if fldigi_poller:
            def on_save(config):
                fldigi_save_config(config)
                fldigi_poller.config = config
                print(f"fldigi: Settings saved - Port: {config.xmlrpc_port}, Auto-log: {config.auto_log}")
            FldigiSettingsDialog(root, fldigi_poller.config, fldigi_poller, on_save)

    def fldigi_connect():
        """Start fldigi poller."""
        global fldigi_poller
        if fldigi_poller and not fldigi_poller._running:
            fldigi_poller.start()

    def fldigi_disconnect():
        """Stop fldigi poller."""
        global fldigi_poller
        if fldigi_poller and fldigi_poller._running:
            fldigi_poller.stop()

else:
    print("fldigi Integration support NOT available")

    def fldigi_settings_dialog():
        pass

    def fldigi_connect():
        pass

    def fldigi_disconnect():
        pass

# N3FJP Integration functions
if N3FJP_AVAILABLE:
    print("N3FJP Integration support available")

    def n3fjp_load_config():
        """Load N3FJP configuration from globDb."""
        config = N3FJPConfig()
        config.client_enabled = globDb.get('n3fjp_client_enabled', '0') == '1'
        config.server_enabled = globDb.get('n3fjp_server_enabled', '0') == '1'
        config.host = globDb.get('n3fjp_host', '127.0.0.1')
        config.client_port = int(globDb.get('n3fjp_client_port', '1100'))
        config.server_port = int(globDb.get('n3fjp_server_port', '1100'))
        config.auto_log = globDb.get('n3fjp_auto_log', '1') == '1'
        config.auto_band = globDb.get('n3fjp_auto_band', '1') == '1'
        return config

    def n3fjp_save_config(config):
        """Save N3FJP configuration to globDb."""
        globDb.put('n3fjp_client_enabled', '1' if config.client_enabled else '0')
        globDb.put('n3fjp_server_enabled', '1' if config.server_enabled else '0')
        globDb.put('n3fjp_host', config.host)
        globDb.put('n3fjp_client_port', str(config.client_port))
        globDb.put('n3fjp_server_port', str(config.server_port))
        globDb.put('n3fjp_auto_log', '1' if config.auto_log else '0')
        globDb.put('n3fjp_auto_band', '1' if config.auto_band else '0')

    def n3fjp_status_update(status):
        """Update N3FJP status display."""
        global n3fjp_status_label
        if n3fjp_status_label:
            if status in ("Disconnected", "Off", "Error"):
                n3fjp_status_label.config(text=f"N3FJP: {status}", foreground='gray')
            else:
                n3fjp_status_label.config(text=f"N3FJP: {status}", foreground='green')

    def n3fjp_on_qso_logged(call, band_mode, report, timestamp):
        """Called when N3FJP logs a QSO. Runs on network thread."""
        def _do_log():
            global band
            if not gd.getv('ession'):
                print("N3FJP: Cannot log QSO - no operator set")
                return
            if qdb.dupck(call, band_mode):
                print(f"N3FJP: Dupe - {call} on {band_mode}")
                return
            if (n3fjp_client and n3fjp_client.config.auto_band) or \
               (n3fjp_server and n3fjp_server.config.auto_band):
                if band != band_mode:
                    bandset(band_mode)
            qdb.qsl(timestamp, call, band_mode, report)
            print(f"N3FJP: Logged {call} on {band_mode} - {report}")
        try:
            root.after(0, _do_log)
        except Exception:
            pass

    def n3fjp_on_band_change(new_band):
        """Called when N3FJP frequency changes band."""
        def _do_band():
            global band
            if band != new_band:
                bandset(new_band)
        try:
            root.after(0, _do_band)
        except Exception:
            pass

    def n3fjp_get_current_info():
        """Return current band/mode/freq for server responses."""
        global band
        freq = N3FJP_BAND_FREQ_MAP.get(band, 0)
        mode = 'CW' if band.endswith('c') else ('DIG' if band.endswith('d') else 'SSB')
        b = band[:-1] if band != 'off' else ''
        return {'band': f"{b}m" if b else '', 'mode': mode, 'freq': str(freq)}

    def n3fjp_get_qso_count():
        """Return QSO count for server responses."""
        try:
            return qdb.qcount()
        except Exception:
            return 0

    def n3fjp_check_dupe(call, band_mode):
        """Dupe check for server responses."""
        return qdb.dupck(call, band_mode)

    def n3fjp_settings_dialog():
        """Open N3FJP settings dialog."""
        global n3fjp_client, n3fjp_server
        config = n3fjp_client.config if n3fjp_client else (n3fjp_server.config if n3fjp_server else n3fjp_load_config())
        def on_save(cfg):
            global n3fjp_client, n3fjp_server
            n3fjp_save_config(cfg)
            if n3fjp_client:
                n3fjp_client.config = cfg
            if n3fjp_server:
                n3fjp_server.config = cfg
            print(f"N3FJP: Settings saved")
        N3FJPSettingsDialog(root, config, n3fjp_client, n3fjp_server, on_save)

    def n3fjp_connect_client():
        """Start N3FJP client."""
        global n3fjp_client
        if n3fjp_client and not n3fjp_client._running:
            n3fjp_client.start()

    def n3fjp_disconnect_client():
        """Stop N3FJP client."""
        global n3fjp_client
        if n3fjp_client and n3fjp_client._running:
            n3fjp_client.stop()

    def n3fjp_start_server():
        """Start N3FJP server."""
        global n3fjp_server
        if n3fjp_server and not n3fjp_server._serving:
            n3fjp_server.start()

    def n3fjp_stop_server():
        """Stop N3FJP server."""
        global n3fjp_server
        if n3fjp_server and n3fjp_server._serving:
            n3fjp_server.stop()

else:
    print("N3FJP Integration support NOT available")

    def n3fjp_settings_dialog():
        pass

    def n3fjp_connect_client():
        pass

    def n3fjp_disconnect_client():
        pass

    def n3fjp_start_server():
        pass

    def n3fjp_stop_server():
        pass

# rigctld Integration functions
if RIGCTLD_AVAILABLE:
    print("rigctld Integration support available")

    def rigctld_load_config():
        """Load rigctld configuration from globDb."""
        config = RigctldConfig()
        config.enabled = globDb.get('rigctld_enabled', '0') == '1'
        config.host = globDb.get('rigctld_host', '127.0.0.1')
        config.port = int(globDb.get('rigctld_port', '4532'))
        config.poll_interval = float(globDb.get('rigctld_poll_interval', '2.0'))
        config.auto_band = globDb.get('rigctld_auto_band', '1') == '1'
        config.push_frequency = globDb.get('rigctld_push_frequency', '1') == '1'
        return config

    def rigctld_save_config(config):
        """Save rigctld configuration to globDb."""
        globDb.put('rigctld_enabled', '1' if config.enabled else '0')
        globDb.put('rigctld_host', config.host)
        globDb.put('rigctld_port', str(config.port))
        globDb.put('rigctld_poll_interval', str(config.poll_interval))
        globDb.put('rigctld_auto_band', '1' if config.auto_band else '0')
        globDb.put('rigctld_push_frequency', '1' if config.push_frequency else '0')

    def rigctld_status_update(status):
        """Update rigctld status display."""
        global rigctld_status_label
        if rigctld_status_label:
            if "Connected" in status and "Disconnected" not in status:
                rigctld_status_label.config(text=f"Rig: {status}",
                                            foreground='green')
            else:
                rigctld_status_label.config(text=f"Rig: {status}",
                                            foreground='gray')

    def rigctld_on_band_change(new_band):
        """Called by RigctldClient when rig frequency changes band."""
        def _do_band():
            global band
            if band != new_band:
                bandset(new_band)
        try:
            root.after(0, _do_band)
        except Exception:
            pass

    def rigctld_settings_dialog():
        """Open rigctld settings dialog."""
        global rigctld_client
        if rigctld_client:
            def on_save(config):
                rigctld_save_config(config)
                rigctld_client.config = config
                print(f"rigctld: Settings saved - Host: {config.host}:{config.port}")
            RigctldSettingsDialog(root, rigctld_client.config, rigctld_client, on_save)

    def rigctld_connect():
        """Start rigctld client."""
        global rigctld_client
        if rigctld_client and not rigctld_client._running:
            rigctld_client.start()

    def rigctld_disconnect():
        """Stop rigctld client."""
        global rigctld_client
        if rigctld_client and rigctld_client._running:
            rigctld_client.stop()

else:
    print("rigctld Integration support NOT available")

    def rigctld_settings_dialog():
        pass

    def rigctld_connect():
        pass

    def rigctld_disconnect():
        pass

print("Starting GUI setup")

#     ****************** GUI START **************************

root = Tk()  # setup Tk GUI

# Set application icon (cross-platform)
try:
    _icon_dir = os.path.dirname(os.path.abspath(__file__))
    if sys.platform == 'win32':
        root.iconbitmap(os.path.join(_icon_dir, 'FDLog Icon.ico'))
    else:
        _icon_img = PhotoImage(file=os.path.join(_icon_dir, 'FDLog Icon.png'))
        root.iconphoto(True, _icon_img)
except Exception:
    pass  # icon not found, use default

# Initialize CW Controller after root is created
if CW_AVAILABLE:
    cw_config = cw_load_config()
    cw_controller = CWController(cw_config, root, cw_status_update)
    cw_controller.set_variable_getter(get_macro_variable)
    # Load saved macros
    saved_macros = cw_load_macros()
    cw_controller.macro_manager.load_from_dict(saved_macros)
    print(f"CW: Initialized - Port: {cw_config.port}, Method: {cw_config.method}, WPM: {cw_config.wpm}")

# Initialize Voice Keyer after root is created
if VOICE_AVAILABLE:
    voice_config = voice_load_config()
    voice_keyer = VoiceKeyer(voice_config, root, voice_status_update)
    voice_keyer.set_variable_getter(get_macro_variable)
    # Load saved macros and modes
    saved_voice_macros = voice_load_macros()
    voice_keyer.macro_manager.load_from_dict(saved_voice_macros)
    saved_voice_modes = voice_load_modes()
    voice_keyer.macro_manager.load_modes_from_dict(saved_voice_modes)
    # Wire up CW PTT reuse if both are available
    if CW_AVAILABLE and cw_controller:
        def _voice_cw_ptt_on():
            if cw_controller.keyer and hasattr(cw_controller.keyer, 'ptt_on'):
                cw_controller.keyer.ptt_on()
        def _voice_cw_ptt_off():
            if cw_controller.keyer and hasattr(cw_controller.keyer, 'ptt_off'):
                cw_controller.keyer.ptt_off()
        voice_keyer.set_cw_ptt(_voice_cw_ptt_on, _voice_cw_ptt_off)
    print(f"Voice: Initialized - Speed: {voice_config.speed}, Volume: {voice_config.volume}")

# Initialize WSJT-X Integration after root is created
if WSJTX_AVAILABLE:
    wsjtx_config = wsjtx_load_config()
    wsjtx_listener = WSJTXListener(wsjtx_config, wsjtx_on_qso_logged, wsjtx_status_update)
    if wsjtx_config.enabled:
        wsjtx_listener.start()
    print(f"WSJT-X: Initialized - Port: {wsjtx_config.udp_port}, Enabled: {wsjtx_config.enabled}")

# Initialize JS8Call Integration after root is created
if JS8CALL_AVAILABLE:
    js8call_config = js8call_load_config()
    js8call_listener = JS8CallListener(js8call_config, js8call_on_qso_logged, js8call_status_update)
    if js8call_config.enabled:
        js8call_listener.start()
    print(f"JS8Call: Initialized - Port: {js8call_config.udp_port}, Enabled: {js8call_config.enabled}")

# Initialize fldigi Integration after root is created
if FLDIGI_AVAILABLE:
    fldigi_config = fldigi_load_config()
    fldigi_poller = FldigiPoller(fldigi_config, fldigi_on_qso_logged, fldigi_status_update, fldigi_on_band_change)
    if fldigi_config.enabled:
        fldigi_poller.start()
    print(f"fldigi: Initialized - Port: {fldigi_config.xmlrpc_port}, Enabled: {fldigi_config.enabled}")

# Initialize N3FJP Integration after root is created
if N3FJP_AVAILABLE:
    n3fjp_config = n3fjp_load_config()
    n3fjp_client = N3FJPClient(n3fjp_config, n3fjp_on_qso_logged, n3fjp_status_update, n3fjp_on_band_change)
    n3fjp_server = N3FJPServer(n3fjp_config, n3fjp_on_qso_logged, n3fjp_status_update, n3fjp_on_band_change,
                                get_current_info=n3fjp_get_current_info,
                                get_qso_count=n3fjp_get_qso_count,
                                check_dupe=n3fjp_check_dupe)
    if n3fjp_config.client_enabled:
        n3fjp_client.start()
    if n3fjp_config.server_enabled:
        n3fjp_server.start()
    print(f"N3FJP: Initialized - Client port: {n3fjp_config.client_port}, Server port: {n3fjp_config.server_port}")

# Initialize rigctld Integration after root is created
if RIGCTLD_AVAILABLE:
    rigctld_config = rigctld_load_config()
    rigctld_client = RigctldClient(rigctld_config, rigctld_status_update, rigctld_on_band_change)
    if rigctld_config.enabled:
        rigctld_client.start()
    print(f"rigctld: Initialized - Host: {rigctld_config.host}:{rigctld_config.port}, Enabled: {rigctld_config.enabled}")

menu = Menu(root)
root.config(menu=menu)
filemenu = Menu(menu, tearoff=0)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="Save Entry File", command=lambda: contestlog(1))
filemenu.add_command(label="PreView Saved Entry File",
                     command=lambda: viewtextf('fdlog.log'))
filemenu.add_command(label="View Log Data File",
                     command=lambda: viewtextf(logdbf))
filemenu.add_command(label="Exit", command=root.quit)
propmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Properties", menu=propmenu)
propmenu.add_command(label="Set Node ID", command=noddiag)
propmenu.add_command(label="Add Participants", command=newpart.dialog)
propmenu.add_command(label="Edit Participant", command=editpart.dialog)
propmenu.add_command(label="Time Functions", command=gpssync.dialog)
logmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Logs", menu=logmenu)
logmenu.add_command(label='Full Log', command=lambda: viewlogf(""))
logmenu.add_command(label='QSTs', command=lambda: viewlogf(r"[*]QST"))
logmenu.add_command(label='GOTA', command=lambda: viewlogfs("gota"))
logmenu.add_command(label='WAS', command=viewwasrpt)
logmenu.add_command(label='Sections', command=viewsectionsrpt)
for j in modes:
    lab = StringVar
    m = Menu(logmenu, tearoff=0)
    if j == 'c':
        lab = 'CW'
        xa = j
        m.add_command(label="All CW", command=lambda: (viewlogfm("c")))
    elif j == 'd':
        lab = 'Digital'
        xb = j
        m.add_command(label="All Digital", command=lambda: (viewlogfm("d")))
    elif j == 'p':
        lab = 'Phone'
        xc = j
        m.add_command(label="All Phone", command=lambda: (viewlogfm("p")))
    logmenu.add_cascade(label=lab, menu=m)
    for i in bands:
        if i == 'off':
            continue
        bm = "%s%s" % (i, j)
        m.add_command(label=bm, command=lambda x01=bm: (viewlogf(x01)))
#  Added Resources Menu Item to clean up the menu. - Apr/16/2014 Scott Hibbs
resourcemenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Resources", menu=resourcemenu)
# Changed this from fdrules to just Rules to get away from fd name in file folder - Scott Hibbs KD4SIR Mar/28/2017
# Cross-platform file opening via open_file() function - Jan 2026
resourcemenu.add_command(label="ARRL FD Rules (pdf)", command=lambda: open_file('Rules.pdf'))
# Changed this to a .dat file to remove the duplicate txt file - Scott Hibbs KD4SIR Mar/28/2017
resourcemenu.add_command(label="ARRL Sections", command=lambda: viewtextf('Arrl_sections_ref.txt', 'ARRL Sections'))
resourcemenu.add_command(label="ARRL Band Chart (pdf)", command=lambda: open_file('Bands.pdf'))
resourcemenu.add_command(label="ARRL Band Plan", command=lambda: viewtextf('ARRL_Band_Plans.txt', "ARRL Band Plan"))
# This is not needed with the band chart giving the same info - Scott Hibbs KD4SIR Mar/28/2017
# resourcemenu.add_command(label="FD Frequency List", command=lambda: viewtextf('frequencies.txt', "FD Frequency List"))
# Removed the propagation report. We don't use it. - Mar/29/2017 Scott Hibbs KD4SIR
# resourcemenu.add_command(label="Propagation Info", command=lambda: viewtextf('propagation.txt', "Propagation Info"))
# Created a W1AW menu - Scott Hibbs KD4SIR Mar/28/2017
W1AWmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="W1AW", menu=W1AWmenu)
# Changed this to a PDF file - Curtis E. Mills WE7U 20Jun2019
W1AWmenu.add_command(label="W1AW Schedule (pdf)", command=lambda: open_file('W1AW.pdf'))
W1AWmenu.add_command(label="NTS Message", command=lambda: open_file('NTS_eg.txt'))
#  Updated by Alan Biocca (W6AKB) FDLog v4-1-154c-dev during python 3 conversion. 15Jul2022 Scott Hibbs
# Time Zone Conversion Chart
# 000 0000 0000 0000 0000
# 000  -8   -7   -6   -5
tzchart = """
 UTC       PDT  MDT  CDT  EDT
 GMT  PST  MST  CST  EST

"""
for g in range(0, 2400, 100):
    p = g - 800
    if p < 0:
        p += 2400
    m = p + 100
    if m < 0:
        m += 2400
    c = m + 100
    if c < 0:
        c += 2400
    e = c + 100
    if e < 0:
        e += 2400
    x = e + 100
    if x < 0:
        x += 2400
    tzchart += "%04d %04d %04d %04d %04d %04d\n" % (g, p, m, c, e, x)
resourcemenu.add_command(label="Time Conversion Chart", command=lambda: viewtextv(tzchart, "Time Conversion Chart"))

# Font Menu - Scott Hibbs KD4SIR 09Aug2022
fontmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Font", menu=fontmenu)
fontmenu.add_command(label="Consolas - slash zero 10pt", command=lambda: set_font("Consolas", 10))
fontmenu.add_command(label="Consolas - 11pt", command=lambda: set_font("Consolas", 11))
fontmenu.add_command(label="Consolas - 12pt", command=lambda: set_font("Consolas", 12))
fontmenu.add_command(label="Consolas - 13pt", command=lambda: set_font("Consolas", 13))
fontmenu.add_command(label="Consolas - 14pt", command=lambda: set_font("Consolas", 14))
fontmenu.add_command(label="Courier - normal type 10pt", command=lambda: set_font("Courier", 10))
fontmenu.add_command(label="Courier - 11pt", command=lambda: set_font("Courier", 11))
fontmenu.add_command(label="Courier - 12pt", command=lambda: set_font("Courier", 12))
fontmenu.add_command(label="Courier - 13pt", command=lambda: set_font("Courier", 13))
fontmenu.add_command(label="Courier - 14pt", command=lambda: set_font("Courier", 14))

# Help menu
helpmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Help", menu=helpmenu)
# Basically reworked the whole menu section. - Scott A Hibbs KD4SIR 7/25/13
# Removed duplicate help sources and files. Rewrote documentation - Scott Hibbs Mar/31/2017
# Renamed fdlogman to Manual to give distance from name of program - Scott Hibbs KD4SIR Mar/29/2017
# Removed "getting started" from code to external text file. - Scott A Hibbs KD4SIR 7/25/13
# Removed Wireless Network as it is not needed - Scott Hibbs KD4SIR Mar/29/2017
helpmenu.add_command(label="Quick Help", command=lambda: viewtextf('Keyhelp.txt'))
helpmenu.add_command(label="Set Commands", command=gd.sethelp)
helpmenu.add_command(label="The Manual", command=lambda: viewtextf('Manual.txt', "Manual"))
helpmenu.add_command(label="Release Log", command=lambda: viewtextf('Releaselog.txt'))
helpmenu.add_command(label="GitHub ReadMe", command=lambda: viewtextf('readme.txt'))
helpmenu.add_command(label="About FDLOG_Enhanced", command=lambda: viewtextv(about, "About"))

# CW Keying menu - only shown if pyserial is available
if CW_AVAILABLE:
    cwmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="CW", menu=cwmenu)
    cwmenu.add_command(label="Settings...", command=cw_settings_dialog)
    cwmenu.add_command(label="Macro Editor...", command=cw_macro_editor_dialog)
    cwmenu.add_separator()
    cwmenu.add_command(label="Connect", command=cw_connect)
    cwmenu.add_command(label="Disconnect", command=cw_disconnect)
    cwmenu.add_separator()
    cwmenu.add_command(label="Speed Up (PgUp)", command=lambda: cw_adjust_speed(2))
    cwmenu.add_command(label="Speed Down (PgDn)", command=lambda: cw_adjust_speed(-2))

# Voice Keying menu - only shown if pyttsx3 is available
if VOICE_AVAILABLE:
    voicemenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="Voice", menu=voicemenu)
    voicemenu.add_command(label="Settings...", command=voice_settings_dialog)
    voicemenu.add_command(label="Macro Editor...", command=voice_macro_editor_dialog)

# WSJT-X Integration menu
if WSJTX_AVAILABLE:
    wsjtxmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="WSJT-X", menu=wsjtxmenu)
    wsjtxmenu.add_command(label="Settings...", command=wsjtx_settings_dialog)
    wsjtxmenu.add_separator()
    wsjtxmenu.add_command(label="Connect", command=wsjtx_connect)
    wsjtxmenu.add_command(label="Disconnect", command=wsjtx_disconnect)

# JS8Call Integration menu
if JS8CALL_AVAILABLE:
    js8callmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="JS8Call", menu=js8callmenu)
    js8callmenu.add_command(label="Settings...", command=js8call_settings_dialog)
    js8callmenu.add_separator()
    js8callmenu.add_command(label="Connect", command=js8call_connect)
    js8callmenu.add_command(label="Disconnect", command=js8call_disconnect)

# fldigi Integration menu
if FLDIGI_AVAILABLE:
    fldigimenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="fldigi", menu=fldigimenu)
    fldigimenu.add_command(label="Settings...", command=fldigi_settings_dialog)
    fldigimenu.add_separator()
    fldigimenu.add_command(label="Connect", command=fldigi_connect)
    fldigimenu.add_command(label="Disconnect", command=fldigi_disconnect)

# N3FJP Integration menu
if N3FJP_AVAILABLE:
    n3fjpmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="N3FJP", menu=n3fjpmenu)
    n3fjpmenu.add_command(label="Settings...", command=n3fjp_settings_dialog)
    n3fjpmenu.add_separator()
    n3fjpmenu.add_command(label="Connect Client", command=n3fjp_connect_client)
    n3fjpmenu.add_command(label="Disconnect Client", command=n3fjp_disconnect_client)
    n3fjpmenu.add_separator()
    n3fjpmenu.add_command(label="Start Server", command=n3fjp_start_server)
    n3fjpmenu.add_command(label="Stop Server", command=n3fjp_stop_server)

# rigctld Integration menu
if RIGCTLD_AVAILABLE:
    rigmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="Rig", menu=rigmenu)
    rigmenu.add_command(label="Settings...", command=rigctld_settings_dialog)
    rigmenu.add_separator()
    rigmenu.add_command(label="Connect", command=rigctld_connect)
    rigmenu.add_command(label="Disconnect", command=rigctld_disconnect)

# Network bar moved to the top - Scott Hibbs KD4SIR 05Aug2022
frn1 = Frame(root, bd=1)
# Row 0 sub-frame: Network, Time on Band, Node
_frn1_row0 = Frame(frn1)
_frn1_row0.pack(fill='x')
# Row 1 sub-frame: CW, Voice, WSJT-X, JS8Call status labels
_frn1_row1 = Frame(frn1)
_frn1_row1.pack(fill='x')
# Row 2 sub-frame: fldigi, N3FJP, rigctld status labels
_frn1_row2 = Frame(frn1)
_frn1_row2.pack(fill='x')
# Network label
lblnet = Label(_frn1_row0, text="Waiting for Network", font=fdfont, relief='raised', foreground='blue', background='gold')
# Time on Band label
lbltimeonband = Label(_frn1_row0, text=" ", font=fdfont, relief='raised', foreground='blue', background='light gray')
# Node label
lblnode = Label(_frn1_row0, text=" Node: %s Port: %s " % (node, port_base), font=fdfont, relief='raised',
                foreground='black', background='light gray')

# CW Status label (always visible, greyed out if CW module unavailable)
cw_status_label = Label(_frn1_row1, text="CW: Ready", font=fdfont, relief='raised',
                        foreground='gray', background='light gray',
                        width=20, anchor='w', state='disabled')

# Voice Status label (always visible, greyed out if voice module unavailable)
voice_status_label = Label(_frn1_row1, text="Voice: Ready", font=fdfont, relief='raised',
                           foreground='gray', background='light gray',
                           width=20, anchor='w', state='disabled')

# WSJT-X Status label
if WSJTX_AVAILABLE:
    wsjtx_status_label = Label(_frn1_row1, text="WSJT-X: Off", font=fdfont, relief='raised',
                               foreground='gray', background='light gray',
                               width=22, anchor='w')
else:
    wsjtx_status_label = None

# JS8Call Status label
if JS8CALL_AVAILABLE:
    js8call_status_label = Label(_frn1_row1, text="JS8Call: Off", font=fdfont, relief='raised',
                                 foreground='gray', background='light gray',
                                 width=22, anchor='w')
else:
    js8call_status_label = None

# fldigi Status label
if FLDIGI_AVAILABLE:
    fldigi_status_label = Label(_frn1_row2, text="fldigi: Off", font=fdfont, relief='raised',
                                foreground='gray', background='light gray',
                                width=22, anchor='w')
else:
    fldigi_status_label = None

# N3FJP Status label
if N3FJP_AVAILABLE:
    n3fjp_status_label = Label(_frn1_row2, text="N3FJP: Off", font=fdfont, relief='raised',
                                foreground='gray', background='light gray',
                                width=22, anchor='w')
else:
    n3fjp_status_label = None

# rigctld Status label
if RIGCTLD_AVAILABLE:
    rigctld_status_label = Label(_frn1_row2, text="Rig: Off", font=fdfont, relief='raised',
                                foreground='gray', background='light gray',
                                width=22, anchor='w')
else:
    rigctld_status_label = None

# Band Buttons
f1 = Frame(root, bd=1)
bandbuttons(f1)

# oper logger power and network windows
f1b = Frame(root, bd=0)
#  Changed the color of the user buttons to red until assigned - KD4SIR Scott Hibbs 7/14/2013
#  Changed colors to be less garish: Yellow to gold, orange to dark orange, green to pale green,
#  gray to light gray. - Curtis E. Mills WE7U 21Jun2019
ocolor = 'red'
lcolor = 'red'
pcolor = 'red'

# Operator
opmb = Menubutton(f1b, text='Contestant', font=fdfont, relief='raised', background=ocolor)
opmu = Menu(opmb, tearoff=0)
opmb.config(menu=opmu, direction='below')
opmu.add_command(label="Add New Contestant", command=newpart.dialog)
opds = Menubutton(f1b, text='<select Contestant>', font=fdfont, relief='raised', background=ocolor)
opdsu = Menu(opds, tearoff=0)
opds.config(menu=opdsu, direction='below')

# Logger
logmb = Menubutton(f1b, text="Logger", font=fdfont, relief='raised', background=lcolor)
logmu = Menu(logmb, tearoff=0)
logmb.config(menu=logmu, direction='below')
logmu.add_command(label="Add New Logger", command=newpart.dialog)
logds = Menubutton(f1b, text='<Select Logger>', font=fdfont, relief='raised', background=lcolor)
logdsu = Menu(logds, tearoff=0)
logds.config(menu=logdsu, direction='below')
logdsu.add_command(label="Add New Logger", command=newpart.dialog)

# Power buttons
pwrmb = Menubutton(f1b, text="Power", font=fdfont, relief='raised', background=pcolor)
pwrmu = Menu(pwrmb, tearoff=0)
pwrmb.config(menu=pwrmu, direction='below')
#  rearranged this menu - Scott Hibbs Mar/23/2017
#  Power limits enforced by class: A/B/C=500W, D/E/F=100W, QRP=5W - Jan 2026
#  Alt/Nat power countdown now shows in UI next to Natural checkbox - Jan 2026
pwrmu.add_command(label='     0 Watts', command=lambda: (setpwr('0')))
pwrmu.add_command(label='     5 Watts (QRP)', command=lambda: (setpwr('5')))
pwrmu.add_command(label='  100 Watts (Class D/E/F max)', command=lambda: (setpwr('100')))
pwrmu.add_command(label='  500 Watts (Class A/B/C max)', command=lambda: (setpwr('500')))
pwrmu.add_separator()
pwrmu.add_command(label='     5W Alt/Nat rule 7.3.8', command=lambda: (setpwr('5n')))
pwrmu.add_command(label=' 100W Alt/Nat rule 7.3.8', command=lambda: (setpwr('100n')))
pwrmu.add_command(label=' 500W Alt/Nat rule 7.3.8', command=lambda: (setpwr('500n')))
pwrnt = Entry(f1b, width=4, font=fdfont, background=pcolor, validate='focusout', validatecommand=ckpowr)
powlbl = Label(f1b, text="W", font=fdfont, background=pcolor)
natv = IntVar()
powcb = Checkbutton(f1b, text="Natural", variable=natv, command=ckpowr,
                    font=fdfont, relief='raised', background=pcolor)
setpwr(power)

# Natural/Alternate power countdown label - shows progress toward 100pt bonus (5 QSOs needed)
natpwr_countdown = Label(f1b, text="Nat: 0/5", font=fdfont, background='light gray')

# Sound notifications toggle - off by default for digital mode compatibility
sound_enabled = IntVar(value=0)
sound_cb = Checkbutton(f1b, text="Sound", variable=sound_enabled,
                       font=fdfont, relief='raised', background='light gray')

# Added Network label - KD4SIR Scott Hibbs Oct 4, 2013
# Added Node label - KD4SIR Scott Hibbs Oct/13/2013
# Added wof label - KD4SIR Scott Hibbs Jan/19/2017
# Added port label - KD4SIR Scott Hibbs Jan/19/2017

# Function buttons
redrawbutton = Button(f1b, text="Redraw Log", font=fdfont, relief='raised', foreground='blue', command=logwredraw,
                      background='light gray')
opsonlinebutton = Button(f1b, text="Contestants Working", font=fdfont, relief='raised', foreground='blue',
                         command=showoperatorsonline, background='light gray')
mapbutton = Button(f1b, text="WAS Map", font=fdfont, relief='raised', foreground='blue',
                   command=generate_map, background='light gray')
sectionmapbutton = Button(f1b, text="Section Map", font=fdfont, relief='raised', foreground='blue',
                          command=generate_section_map, background='light gray')
phonetic_visible = False  # Track phonetic display visibility (hidden by default)
phonetic_toggle_btn = Button(f1b, text="Show Phonetic", font=fdfont, relief='raised', foreground='blue',
                             command=toggle_phonetic_display, background='light gray')

# Who's on First Window to display operators on bands
# lblwof = Label(f1b, text="", font=fdfont, foreground='blue', background='light gray')
# lblwof.grid(row=2, column=0, columnspan=9, sticky=NSEW)
# Port window
# lblport = Label(f1b, text="Port: %s" % port_base, font=fdfont, foreground='blue', background='light gray')
# lblport.grid(row=3, column=9, columnspan=1, sticky=NSEW)

# log window
logw = Text(root, takefocus=0, height=11, width=80, font=fdfont,
            background='light gray', wrap="none", setgrid=True)
scroll = Scrollbar(root, command=logw.yview, background='light gray')
logw.config(yscrollcommand=scroll.set)
scroll.grid(row=3, column=1, sticky=NS)
logw.tag_config("b", foreground="blue")
logw.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", "b")
logw.insert(END, "                            DATABASE DISPLAY WINDOW\n", "b")
logw.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", "b")
logw.insert(END, "%s\n" % prog, "b")

# Text Billboard - our entry window.
txtbillb = Text(root, takefocus=1, height=10, width=80, font=fdfont,
                wrap="none", setgrid=True, background='light gray')
scrollt = Scrollbar(root, command=txtbillb.yview)
txtbillb.config(yscrollcommand=scrollt.set)
txtbillb.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n", "b")
txtbillb.insert(END, "                              Dialogue Window\n", "b")
txtbillb.insert(END, "          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n", "b")
txtbillb.insert(END, "Use space to check a prefix, suffix, or a call. \n")
txtbillb.insert(END, "Paste contacts in call class section format for ex: 'kd4sir 1d in'  \n")
txtbillb.insert(END, "To begin select a Contestant, a Logger, Power and Band/Mode in red above.\n\n")
if authk == "tst":
    txtbillb.insert(END, "-Call-Class-Sect-  (.testq <n> to generate test QSOs)\n")
else:
    txtbillb.insert(END, "-Call-Class-Sect- \n")
txtbillb.config(insertwidth=3)
txtbillb.focus_set()

# Phonetic alphabet display frame - Added by Scott Hibbs KD4SIR
phonetic_frame = Frame(root, bd=1, background='light gray')
phonetic_mode = StringVar(value='answer')  # Default to Answer mode

# Radio buttons for phonetic mode selection (Callsign first as default)
phonetic_rb_answer = Radiobutton(phonetic_frame, text="Callsign", font=fdfont,
                                  variable=phonetic_mode, value='answer',
                                  background='light gray', selectcolor='gold',
                                  command=update_phonetic_display)
phonetic_rb_cq = Radiobutton(phonetic_frame, text="CQ", font=fdfont,
                              variable=phonetic_mode, value='cq',
                              background='light gray', selectcolor='gold',
                              command=update_phonetic_display)
phonetic_rb_qrz = Radiobutton(phonetic_frame, text="QRZ", font=fdfont,
                               variable=phonetic_mode, value='qrz',
                               background='light gray', selectcolor='gold',
                               command=update_phonetic_display)

# Label for phonetic mode
phonetic_mode_label = Label(phonetic_frame, text="Phonetic:", font=fdfont,
                            background='light gray', foreground='blue')

# Label for displaying the phonetic callsign response
phonetic_label = Label(phonetic_frame, text="", font=fdfont,
                       background='light gray', foreground='black',
                       anchor='w', justify='left')

# startup

contestlog(0)  # define globals
buildmenus()
sms = SynchMessage()  # setup sync message service
qdb = QsoDb()  # init qso database
qdb.loadfile()  # read log file
print("Showing GUI")
print()
if node == gd.getv('tmast'):
    print("This Node is the DESIGNATED TIME MASTER (GPS-locked)")
    print("THIS COMPUTER'S CLOCK BETTER BE RIGHT (preferably GPS locked)")
    print("User should Insure that system time is within 1 second of the")
    print("  correct time and that the CORRECT TIMEZONE is selected (in the OS)")
    print()
else:
    print("Time sync: NTP (automatic) > Designated master > Auto-election")
    print("User should Insure that System Time is within a few seconds of the")
    print("  correct time and that the CORRECT TIMEZONE is selected (in the OS)")
print("To change system time, stop FDLog, change the time or zone, then restart")
print()
net.start()  # start threads

# Check if this is an Information Table node
if node == "infotable":
    print("Starting Information Table display mode...")
    print("This node will display contest status for visitors.")
    print()

    # Create dummy widgets and functions needed by NewParticipantDialog
    txtbillb = Text(root)  # Hidden text widget for compatibility
    opdsu = Menu(root)  # Dummy menu for buildmenus()
    logdsu = Menu(root)  # Dummy menu for buildmenus()

    # Override topper() to do nothing in infotable mode
    def topper():
        pass

    # Override buildmenus() to do nothing in infotable mode
    def buildmenus():
        pass

    # Launch Info Table interface instead of normal UI
    info_table = InfoTableWindow(root, qdb, gd, net)
    root.mainloop()
    print("\nShutting down Information Table")
    band = 'off'
    net.bcast_now()
    time.sleep(0.2)
    saveglob()
    print("  globals saved")
    print("\n\n FDLog_Enhanced Information Table has shut down.")
    time.sleep(0.5)
    exit(0)

renew_title()
secName = {}
readsections()
updatect = 0

#  #### GUI GRIDS #####
# Grid for Network Row
frn1.grid(row=0, column=0, columnspan=2, sticky=NSEW)
# Row 0: Node (right), Time on Band (right), Network (fills remaining space)
lblnode.pack(in_=_frn1_row0, side='right')
lbltimeonband.pack(in_=_frn1_row0, side='right')
lblnet.pack(in_=_frn1_row0, side='left', fill='x', expand=True)
# Row 1: Integration status labels packed left
cw_status_label.pack(in_=_frn1_row1, side='left', fill='x', expand=True)
if CW_AVAILABLE:
    cw_status_label.config(cursor='hand2')
    cw_status_label.bind('<Button-1>', lambda e: toggle_fkey_bar() if str(cw_status_label.cget('state')) != 'disabled' else None)
voice_status_label.pack(in_=_frn1_row1, side='left', fill='x', expand=True)
if VOICE_AVAILABLE:
    voice_status_label.config(cursor='hand2')
    voice_status_label.bind('<Button-1>', lambda e: toggle_fkey_bar() if str(voice_status_label.cget('state')) != 'disabled' else None)
if WSJTX_AVAILABLE and wsjtx_status_label:
    wsjtx_status_label.pack(in_=_frn1_row1, side='left', fill='x', expand=True)
if JS8CALL_AVAILABLE and js8call_status_label:
    js8call_status_label.pack(in_=_frn1_row1, side='left', fill='x', expand=True)
if FLDIGI_AVAILABLE and fldigi_status_label:
    fldigi_status_label.pack(in_=_frn1_row2, side='left', fill='x', expand=True)
if N3FJP_AVAILABLE and n3fjp_status_label:
    n3fjp_status_label.pack(in_=_frn1_row2, side='left', fill='x', expand=True)
if RIGCTLD_AVAILABLE and rigctld_status_label:
    rigctld_status_label.pack(in_=_frn1_row2, side='left', fill='x', expand=True)
# Grid for band buttons
f1.grid(row=1, column=0, columnspan=2, sticky=NSEW)
# Grid for Contestant, Logger and Power buttons
f1b.grid(row=2, column=0, columnspan=2, sticky=NSEW)
opds.grid(row=0, column=0, sticky=NSEW)
opmb.grid(row=0, column=1, sticky=NSEW)
f1b.grid_columnconfigure(0, weight=1, minsize=150)
logds.grid(row=0, column=2, sticky=NSEW)
logmb.grid(row=0, column=3, sticky=NSEW)
f1b.grid_columnconfigure(1, weight=1)
f1b.grid_columnconfigure(2, weight=1, minsize=150)
f1b.grid_columnconfigure(3, weight=1)
f1b.grid_columnconfigure(4, weight=1)
f1b.grid_columnconfigure(5, weight=1)
f1b.grid_columnconfigure(6, weight=1)
f1b.grid_columnconfigure(7, weight=1)
f1b.grid_columnconfigure(8, weight=1)
f1b.grid_columnconfigure(9, weight=1)
pwrmb.grid(row=0, column=4, sticky=NSEW)
pwrnt.grid(row=0, column=5, sticky=NSEW)
powlbl.grid(row=0, column=6, sticky=NSEW)
powcb.grid(row=0, column=7, sticky=NSEW)
natpwr_countdown.grid(row=0, column=8, sticky=NSEW)
sound_cb.grid(row=0, column=9, sticky=NSEW)
# Grid for functionbuttons
redrawbutton.grid(row=1, column=0, columnspan=2, sticky=NSEW)
opsonlinebutton.grid(row=1, column=2, columnspan=2, sticky=NSEW)
mapbutton.grid(row=1, column=4, columnspan=2, sticky=NSEW)
sectionmapbutton.grid(row=1, column=6, columnspan=2, sticky=NSEW)
phonetic_toggle_btn.grid(row=1, column=8, columnspan=2, sticky=NSEW)
# Grid for log window
root.grid_rowconfigure(2, weight=1)
logw.grid(row=3, column=0, sticky=NSEW)
root.grid_columnconfigure(0, weight=1)
# Grid for text billboard
root.grid_rowconfigure(3, weight=1)
txtbillb.grid(row=4, column=0, sticky=NSEW)
scrollt.grid(row=4, column=1, sticky=NSEW)
# Grid for phonetic alphabet display (hidden by default, toggle with button)
# phonetic_frame.grid(row=5, column=0, columnspan=2, sticky=NSEW)
phonetic_mode_label.grid(row=0, column=0, padx=5, sticky=NSEW)
phonetic_rb_answer.grid(row=0, column=1, padx=5, sticky=NSEW)
phonetic_rb_cq.grid(row=0, column=2, padx=5, sticky=NSEW)
phonetic_rb_qrz.grid(row=0, column=3, padx=5, sticky=NSEW)
phonetic_label.grid(row=0, column=4, padx=10, sticky=NSEW)
phonetic_frame.grid_columnconfigure(4, weight=1)

# F-key button bar
def toggle_fkey_bar():
    global fkey_bar_visible
    if fkey_bar_visible:
        fkey_frame.grid_remove()
        fkey_bar_visible = False
    else:
        fkey_frame.grid(row=6, column=0, columnspan=2, sticky=NSEW)
        fkey_bar_visible = True
    _update_fkey_label_hints()

def _update_fkey_label_hints():
    """Refresh the [Show]/[Hide] hint on CW and Voice status labels."""
    hint = " [Hide]" if fkey_bar_visible else " [Show]"
    if CW_AVAILABLE and cw_status_label and str(cw_status_label.cget('state')) != 'disabled':
        txt = cw_status_label.cget('text')
        # Strip existing hint and re-add
        for suffix in (' [Show]', ' [Hide]'):
            if txt.endswith(suffix):
                txt = txt[:-len(suffix)]
                break
        cw_status_label.config(text=f"{txt}{hint}")
    if VOICE_AVAILABLE and voice_status_label and str(voice_status_label.cget('state')) != 'disabled':
        txt = voice_status_label.cget('text')
        for suffix in (' [Show]', ' [Hide]'):
            if txt.endswith(suffix):
                txt = txt[:-len(suffix)]
                break
        voice_status_label.config(text=f"{txt}{hint}")

def fkey_button_press(fkey):
    """Dispatch F-key press from button click (same routing as kevent)."""
    current_mode = band[-1:] if band != 'off' else ''
    if current_mode == 'p' and VOICE_AVAILABLE:
        voice_send_macro(fkey)
    elif current_mode in ('c', 'd') and CW_AVAILABLE:
        cw_send_macro(fkey)
    elif CW_AVAILABLE:
        cw_send_macro(fkey)

fkey_frame = Frame(root, bd=1, background='light gray')
fkey_btn_width = 8  # wider to fit two-line labels
fkey_buttons = {}  # dict to access buttons for label updates

# Default F-key labels (N1MM-style for Field Day)
FKEY_DEFAULT_LABELS = {
    'F1': 'CQ',
    'F2': 'Exch',
    'F3': 'Exch Only',
    'F4': 'QSL TU',
    'F5': 'His Call',
    'F6': 'QSL Exch',
    'F7': 'Class',
    'F8': 'Section',
    'F9': '73',
    'F10': 'QRZ?',
    'F11': 'Again?',
    'F12': 'TU QRZ?',
}

def fkey_get_labels():
    """Load F-key labels from globDb, falling back to defaults."""
    labels = {}
    for i in range(1, 13):
        key = f'F{i}'
        labels[key] = globDb.get(f'fkey_label_{key}', FKEY_DEFAULT_LABELS.get(key, ''))
    return labels

def fkey_save_labels(labels):
    """Save F-key labels to globDb."""
    for key, lbl in labels.items():
        qdb.globalshare(f'fkey_label_{key}', lbl)

def fkey_edit_labels():
    """Open dialog to edit F-key button labels."""
    dlg = Toplevel(root)
    dlg.title("Edit F-Key Labels")
    dlg.transient(root)
    dlg.grab_set()
    labels = fkey_get_labels()
    entries = {}
    for i in range(1, 13):
        key = f'F{i}'
        Label(dlg, text=f"{key}:", font=fdfont).grid(row=i-1, column=0, padx=5, pady=2, sticky='e')
        e = Entry(dlg, font=fdfont, width=20)
        e.insert(0, labels[key])
        e.grid(row=i-1, column=1, padx=5, pady=2)
        entries[key] = e

    def save_and_close():
        new_labels = {k: e.get() for k, e in entries.items()}
        fkey_save_labels(new_labels)
        for k, btn in fkey_buttons.items():
            lbl = new_labels.get(k, '')
            btn.config(text=f"{k}\n{lbl}")
        dlg.destroy()

    def reset_defaults():
        for k, e in entries.items():
            e.delete(0, END)
            e.insert(0, FKEY_DEFAULT_LABELS.get(k, ''))

    btn_frame = Frame(dlg)
    btn_frame.grid(row=12, column=0, columnspan=2, pady=5)
    Button(btn_frame, text="Defaults", font=fdfont, command=reset_defaults).pack(side='left', padx=5)
    Button(btn_frame, text="Save", font=fdfont, command=save_and_close).pack(side='left', padx=5)
    Button(btn_frame, text="Cancel", font=fdfont, command=dlg.destroy).pack(side='left', padx=5)

fkey_labels = fkey_get_labels()
for i in range(1, 13):
    key = f'F{i}'
    lbl = fkey_labels[key]
    btn = Button(fkey_frame, text=f"{key}\n{lbl}", font=fdfont, width=fkey_btn_width, relief='raised',
                 foreground='black', background='light gray',
                 command=lambda k=key: fkey_button_press(k))
    btn.grid(row=0, column=i-1, padx=1, pady=2)
    btn.bind('<Button-3>', lambda e: fkey_edit_labels())
    fkey_frame.grid_columnconfigure(i-1, weight=1, uniform='fkey')
    fkey_buttons[key] = btn

# ESC / Stop button
def fkey_stop_all():
    """Stop CW or Voice playback based on current band mode."""
    current_mode = band[-1:] if band != 'off' else ''
    if current_mode == 'p' and VOICE_AVAILABLE:
        voice_stop()
    elif current_mode in ('c', 'd') and CW_AVAILABLE:
        cw_abort()

esc_btn = Button(fkey_frame, text="ESC\nStop", font=fdfont, width=fkey_btn_width, relief='raised',
                 foreground='white', background='#c00000',
                 command=fkey_stop_all)
esc_btn.grid(row=0, column=12, padx=1, pady=2)
fkey_frame.grid_columnconfigure(12, weight=1, uniform='fkey')

fkey_frame.grid(row=6, column=0, columnspan=2, sticky=NSEW)
fkey_frame.grid_remove()  # Hidden by default; toggle via CW/Voice status labels

#  Bindings
root.bind('<ButtonRelease-1>', focevent)
txtbillb.bind('<KeyPress>', kevent)
txtbillb.bind('<Button-3>', mouse_popup)  # Binds the right click function
logw.bind('<KeyPress>', kevent)  # use del key for?xx
logw.bind('<Button-1>', log_select)  # start of log edit
txtbillb.bind('<Control-Key-c>', copy)  # copy event for the copy function
txtbillb.bind('<Control-Key-v>', paste)  # paste event for the paste function

bandset('off')
update_phonetic_display()  # initial phonetic display update
root.after(1000, update)  # type: ignore  # 1 hz activity
root.mainloop()  # gui up
print("\nShutting down")
# Stop WSJT-X listener
if WSJTX_AVAILABLE and wsjtx_listener:
    wsjtx_listener.stop()
    print("  WSJT-X listener stopped")
# Stop JS8Call listener
if JS8CALL_AVAILABLE and js8call_listener:
    js8call_listener.stop()
    print("  JS8Call listener stopped")
# Stop fldigi poller
if FLDIGI_AVAILABLE and fldigi_poller:
    fldigi_poller.stop()
    print("  fldigi poller stopped")
# Stop N3FJP client and server
if N3FJP_AVAILABLE and n3fjp_client:
    n3fjp_client.stop()
    print("  N3FJP client stopped")
if N3FJP_AVAILABLE and n3fjp_server:
    n3fjp_server.stop()
    print("  N3FJP server stopped")
# Stop rigctld client
if RIGCTLD_AVAILABLE and rigctld_client:
    rigctld_client.stop()
    print("  rigctld client stopped")
# the end was updated from 152i
band = 'off'  # gui down, xmt band off, preparing to quit
net.bcast_now()  # push band out
time.sleep(0.2)
saveglob()  # save globals
print("  globals saved")
print("\n\n FDLog_Enhanced has shut down.")
time.sleep(0.5)
# os._exit(1)  # kill the process somehow?
exit(1)

# Suggestions/To Do:
#
#
#  add phonetic alphabet display (DONE: implemented Jan 2026) 2016 Field Day notes
#
#
# eof
